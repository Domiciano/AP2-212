package model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class RecipTest {
	
	private static Recipe rec;
	
	public void setupStage1() {
		Recipe rec= new Recipe();
	}

	public void setupStage2() {
		rec = new Recipe();
		Ingredient A= new Ingredient("Cebolla", 315);
		Ingredient B= new Ingredient("Ajo",58 );
		Ingredient C= new Ingredient("Arroz",520 );
		
		rec.addIngredient("Cebolla", 315);
		rec.addIngredient("Ajo",58);
		rec.addIngredient("Arroz",520);
	}

	@Test
	public void testAddIngredient() {
		setupStage1();
		//test 1
		Recipe recipe = new Recipe();
		Ingredient A= new Ingredient("Sal", 12);
		recipe.addIngredient("Sal", 12);
		
		assertEquals(recipe.getIngredient().size(), 1);
		assertEquals(A.getName(), "Sal");
		assertEquals(A.getWeight(), 12);
		
		setupStage2();
		//test 3
		Ingredient B= new Ingredient("Ajo", 58);
		double additionalW=21;
		B.addWeigth(additionalW); 
		
		assertEquals(rec.getIngredient().size(), 3);
		assertEquals(B.getWeight(), 79);
		
		//test 2
		Ingredient C= new Ingredient("Pimienta", 6);
		rec.addIngredient("Pimienta", 6);
		
		assertEquals(rec.getIngredient().size(), 4);
		assertEquals(C.getName(), "Pimienta");
		assertEquals(C.getWeight(), 6);
		
		
	}
	
	
}

