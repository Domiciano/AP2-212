package model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;

public class IngredienTest {
	
	private Ingredient ing;
	
	public void setupStage1() {
		 ing = new Ingredient("Tomate", 245);
	}
	
	@Test
	public void testAddWeigth() {
		setupStage1();
		
		Ingredient ing= new Ingredient("Tomate", 245);
		double additionalW=54;
		ing.addWeigth(additionalW); 
		
		assertEquals(ing.getWeight(), 299);
	}

}
