package model;

import java.util.ArrayList;

public class Recipe {
	
	ArrayList<Ingredient> list;
	
	public Recipe() {
		list=new ArrayList<>();
	}

	public void addIngredient(String n,double w) {
		
		Ingredient in= new Ingredient(n, w);
		list.add(in);
	}
	
	public ArrayList<Ingredient> getIngredient(){
		return list;
	}
}
