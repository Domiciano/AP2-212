package model;

import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class IngredientTest {

    private Ingredient ingredient;

    public void setupStage1(){
        ingredient = new Ingredient("Tomate", 245);
    }

    @Test
    public void testAddWeight(){
        setupStage1();
        ingredient.addWeight(54);

        assertThat(ingredient.getWeight(), is(299.0));
    }
}