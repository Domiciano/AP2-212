package model;

import org.hamcrest.CoreMatchers;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

public class RecipeTest {

    private Recipe recipe;

    @Before
    public void setUp() throws Exception {
        recipe = new Recipe();
    }

    private void setupStage2(){
        recipe.addIngredient("Cebolla", 315);
        recipe.addIngredient("Ajo", 58);
        recipe.addIngredient("Arroz", 520);
    }

    @Test
    public void testAddIngredient(){
        recipe.addIngredient("Sal", 12);
        ArrayList<Ingredient> ingredients;
        ingredients = new ArrayList<Ingredient>(recipe.getIngredients());
        assertThat((ingredients.get(0).getName()+","+ingredients.get(0).getWeight()), is("Sal,12.0"));

        ingredients.clear();
        recipe.getIngredients().clear();

        setupStage2();
        recipe.addIngredient("Pimienta", 6);
        ingredients = new ArrayList<Ingredient>(recipe.getIngredients());
        assertThat((ingredients.get(ingredients.size()-1).getName()+","+ingredients.get(ingredients.size()-1).getWeight()), is("Pimienta,6.0"));

        ingredients.clear();
        recipe.getIngredients().clear();

        setupStage2();
        recipe.addIngredient("Ajo", 21);
        ingredients = new ArrayList<Ingredient>(recipe.getIngredients());
        assertThat((ingredients.get(1).getName()+","+ingredients.get(1).getWeight()), is("Ajo,79.0"));
    }
}