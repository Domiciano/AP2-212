package main;

import model.NameTree;
import model.NodeName;
import model.Player;


public class Main {

	public static void main(String...args) {
		Main p=new Main();
		p.NodeNameTree();
	}
	
	public void NodeNameTree() {
		NameTree t = new NameTree();
		Player p=new Player(100,  "carlos");
		
		t.add("n1", p);
		t.add("n2", p);
		t.add("n3", p);
		t.add("n4", p);
		t.add("n5", p);
		t.add("n6", p);
		t.add("n7", p);
		
		t.triggerInorder();
		NodeName node = t.triggerSearch("hola");
		if(node == null) {
			System.out.println("No se encontro nada");
		}else {
			System.out.println(node.getKey());
			System.out.println(node.getValue());
		}
		t.triggerMaxLevel();
	}

}
