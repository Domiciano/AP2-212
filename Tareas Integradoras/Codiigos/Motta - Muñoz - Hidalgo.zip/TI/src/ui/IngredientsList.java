package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Ingredients;
import model.IngredientsData;

public class IngredientsList extends Stage{
	
	private TableView<Ingredients> tableIngreTV;
	private TextField ingredientsTF;
	private TextField quantityTF;
	private Button addBtn;
	private Button logOutBtn;
	private Button goBackBtn;
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public IngredientsList() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("IngredientsList.fxml"));
            Parent parent = loader.load();

            tableIngreTV = (TableView) loader.getNamespace().get("tableIngreTV");
            ingredientsTF = (TextField) loader.getNamespace().get("ingredientsTF");
            quantityTF = (TextField) loader.getNamespace().get("quantityTF");
            logOutBtn = (Button) loader.getNamespace().get("logOutBtn");
            addBtn = (Button) loader.getNamespace().get("addBtn");
            goBackBtn = (Button) loader.getNamespace().get("goBackBtn");
            
            
            TableColumn<Ingredients, String> ingredientsCol = new TableColumn<>("Ingredients");
			TableColumn<Ingredients, Double> quantityCol = new TableColumn<>("Quantity");

			ingredientsCol.setCellValueFactory(new PropertyValueFactory<>("nameIngredient"));
			quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));
			
			tableIngreTV.getColumns().addAll(ingredientsCol, quantityCol);
			tableIngreTV.setItems(IngredientsData.getInstance().getData());
			
            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
            
            System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void init() {
		addBtn.setOnAction(event ->{
			doAddBtn();
		});
		logOutBtn.setOnAction(event ->{
			System.exit(0);
    	});
		goBackBtn.setOnAction(event->{
			MainMenu mainMenu = new MainMenu();
			mainMenu.show();
		});
	}
	private void doAddBtn() {
				
		
		String nameIngredient = ingredientsTF.getText();
		Ingredients find= IngredientsData.getInstance().searchIngre(nameIngredient);			
		if(find==null) {
			double quantity = Double.parseDouble(quantityTF.getText());
			Ingredients ingred = new Ingredients(nameIngredient, quantity);
			IngredientsData.getInstance().getData().add(ingred);
			System.out.println("Datos:"+IngredientsData.getInstance().getData().size());
		}else if(find!=null){
			double quantity = Double.parseDouble(quantityTF.getText());
			find.addQuantity(quantity);
			tableIngreTV.refresh();
		}
	}
}