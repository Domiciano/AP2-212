package ui;

import java.io.File;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.User;

public class Register extends Stage{
	
	private TextField userNameTF;
	private PasswordField passwordPF;
	private TextField photoTF;
	private Button browseBtn;
	private RadioButton maleRB;
	private RadioButton femaleRB;
	private RadioButton otherRB;
	private DatePicker birthdayDP;
	private Button createBtn;
	
	public Register() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Register.fxml"));
            Parent parent = loader.load();
            
            userNameTF = (TextField) loader.getNamespace().get("userNameTF");
            passwordPF = (PasswordField) loader.getNamespace().get("passwordPF");
            photoTF = (TextField) loader.getNamespace().get("photoTF");
            browseBtn = (Button) loader.getNamespace().get("browseBtn");
            maleRB = (RadioButton) loader.getNamespace().get("maleRB");
            femaleRB = (RadioButton) loader.getNamespace().get("femaleRB");
            otherRB = (RadioButton) loader.getNamespace().get("otherRB");
            birthdayDP = (DatePicker) loader.getNamespace().get("birthdayDP");
            createBtn = (Button) loader.getNamespace().get("createBtn");

            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void init() {
		browseBtn.setOnAction(event ->{
			doBrowseBtn();
    	});
		createBtn.setOnAction(event ->{
			String userName = userNameTF.getText();
			String password = passwordPF.getText();
			String profilePhoto = photoTF.getText();
			String gender = "";
			if(maleRB.isSelected()) {
				gender = "Male";
			}
			else if(femaleRB.isSelected()) {
				gender = "Female";
			}
			else if(otherRB.isSelected()) {
				gender = "Other";
			}
			String birthday = birthdayDP.getValue().toString();
			User accounts = Main.user.searchUser(userName);
			if(accounts!=null) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Error");
				alert.setHeaderText(null);
				alert.setContentText("The account already exits.");
				alert.showAndWait();
			}
			else if(accounts ==null){
				User account = new User(userName, password, profilePhoto, gender, birthday, false);
				Main.user.getData().add(account);
				Login Login = new Login();
				Login.show();
			}
		});
	}
	private String doBrowseBtn() {
		
		String image="";
		FileChooser fc = new FileChooser();
		fc.setTitle("Abrir imagen");
		fc.getExtensionFilters().addAll(
			new FileChooser.ExtensionFilter("PNG", "*.png"),
			new FileChooser.ExtensionFilter("JPG", "*.jpg"),
			new FileChooser.ExtensionFilter("JPEG", "*.jpeg")	
		);
		File file = fc.showOpenDialog(this);
		System.out.println(file.exists());
		
		if(file != null) {
			image= file.getAbsolutePath();
			photoTF.setText(image);
		}
		return image;
	}
}