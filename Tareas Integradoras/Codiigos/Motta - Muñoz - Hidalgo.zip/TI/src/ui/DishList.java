package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Dish;
import model.DishData;

public class DishList extends Stage{
	
	private TableView<Dish> tableTV;
	private Button goBackBtn;
	private Button logOutBtn;
	
	public DishList() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("DishList.fxml"));
            Parent parent = loader.load();
			
            tableTV = (TableView) loader.getNamespace().get("tableTV");
            goBackBtn = (Button) loader.getNamespace().get("goBackBtn");
            logOutBtn = (Button) loader.getNamespace().get("logOutBtn");
            
            TableColumn<Dish, String> idCol = new TableColumn<>("Id");
            TableColumn<Dish, String> dishCol = new TableColumn<>("Dish");
			TableColumn<Dish, Double> quantityCol = new TableColumn<>("Quantity");
			TableColumn<Dish, String> stateCol = new TableColumn<>("State");
			TableColumn<Dish, String> dateCol = new TableColumn<>("Date");

			idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
			dishCol.setCellValueFactory(new PropertyValueFactory<>("dish"));
			quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));
			stateCol.setCellValueFactory(new PropertyValueFactory<>("state"));
			dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
			
			tableTV.getColumns().addAll(idCol, dishCol, quantityCol, stateCol, dateCol);
			tableTV.setItems(DishData.getInstance().getData());
            
            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
            
            System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void init() {
		goBackBtn.setOnAction(event->{
			MainMenu mainMenu = new MainMenu();
			mainMenu.show();
		});
		logOutBtn.setOnAction(event ->{
			System.exit(0);
    	});
		logOutBtn.setOnAction(event ->{
			System.exit(0);
    	});
	}
}