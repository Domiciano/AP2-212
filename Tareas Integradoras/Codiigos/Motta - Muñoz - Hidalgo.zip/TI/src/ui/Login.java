package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import model.User;

public class Login extends Stage{
	private TextField userNameTF;
	private PasswordField passwordPF;
	private Button signUpBtn;
	private Button logInBtn;
	
	public Login() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent parent = loader.load();


            signUpBtn = (Button) loader.getNamespace().get("signUpBtn");
            passwordPF = (PasswordField) loader.getNamespace().get("passwordPF");

            logInBtn = (Button) loader.getNamespace().get("logInBtn");
            userNameTF = (TextField) loader.getNamespace().get("userNameTF");
            

            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
            
            System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void init() {
		signUpBtn.setOnAction(event ->{
			doSignUpBtn();
    	});
    	
		logInBtn.setOnAction(event ->{
			doLogInBtn();
    	});
	}
	private void doLogInBtn() {
		String userName = userNameTF.getText();
		String password = passwordPF.getText();
		boolean find = Main.user.searchAccount(userName, password);
		User account=Main.user.searchUser(userName);
		if(find) {
			MainMenu mainMenu = new MainMenu();
			mainMenu.setAccount(account);
			mainMenu.show();
		}
		else {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setTitle("Log in incorrect");
			alert.setContentText("The username and password given are incorrect");
			alert.showAndWait();
		}
	}
	private void doSignUpBtn() {
		Register register = new Register();
		register.show();
	}
}