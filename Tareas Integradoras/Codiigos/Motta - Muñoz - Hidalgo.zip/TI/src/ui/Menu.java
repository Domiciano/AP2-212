package ui;

import java.util.UUID;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.paint.LinearGradient;
import javafx.stage.Stage;
import model.Dish;
import model.Ingredients;
import model.IngredientsData;

public class Menu extends Stage{
	
	MenuButton menuIngredientes;
	TextField nameTF;
	TextField priceTF;
	TextField quantityTF;
	Button addBtn;
	TextArea outputTA;
	Button createComboBtn;
	private Button logOutBtn;
	private Button goBackBtn;
	
	public Menu() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Menu.fxml"));
            Parent parent = loader.load();
            
            menuIngredientes = (MenuButton) loader.getNamespace().get("menuIngredientes");
            nameTF = (TextField) loader.getNamespace().get("nameTF");
            priceTF = (TextField) loader.getNamespace().get("priceTF");
            quantityTF = (TextField) loader.getNamespace().get("quantityTF");
            addBtn = (Button) loader.getNamespace().get("addBtn");
            outputTA = (TextArea) loader.getNamespace().get("outputTA");
            createComboBtn = (Button) loader.getNamespace().get("createComboBtn");
            logOutBtn = (Button) loader.getNamespace().get("logOutBtn");
            goBackBtn = (Button) loader.getNamespace().get("goBackBtn");
            
            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
            
            System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void init() {
		
		outputTA.setEditable(false);
		
		addBtn.setOnAction(event->{
			String nombreIngrediente = menuIngredientes.getText();
			System.out.println(nombreIngrediente);
			outputTA.setText(outputTA.getText()+"\n"+ menuIngredientes.getText()+ " "+quantityTF.getText());
		});
		logOutBtn.setOnAction(event ->{
			System.exit(0);
    	});
		goBackBtn.setOnAction(event->{
			MainMenu mainMenu = new MainMenu();
			mainMenu.show();
		});
		for(Ingredients ingrediente : IngredientsData.getInstance().getData()) {
			MenuItem item = new MenuItem(ingrediente.getNameIngredient());
			item.setOnAction(event->{
				menuIngredientes.setText(item.getText());
			});
			menuIngredientes.getItems().add(item);
		}
		
		createComboBtn.setOnAction(event->{
			String uniqueID = UUID.randomUUID().toString();
			String name =nameTF.getText();
			String lineas = outputTA.getText();
			double price = Double.parseDouble(priceTF.getText());
			
			Dish dish = new Dish(uniqueID, name, price, "idk", "a", lineas);
			/*for(int i=0; i<lineas.length;i++) {
				System.out.println(lineas[i]);
				String[] columnas = lineas[i].split(" ");
				for(int o=0; o<columnas.length;o++) {
					System.out.println(columnas[o]);
					
				}
			}
			*/
		});
	}
}
