package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.User;
import model.UserData;

public class UserList extends Stage{
	
	private TableView<User> userListTV;
	private Button registerBtn;
	private Button logOutBtn;
	private Button goBackBtn;
	
	private UserData accounts;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public UserList() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("UserList.fxml"));
            Parent parent = loader.load();

            userListTV = (TableView) loader.getNamespace().get("userListTV");
            registerBtn = (Button) loader.getNamespace().get("registerBtn");
            logOutBtn = (Button) loader.getNamespace().get("logOutBtn");
            goBackBtn = (Button) loader.getNamespace().get("goBackBtn");
            
            accounts = Main.user;

            TableColumn<User, String> userNameCol = new TableColumn<>("Username");
            TableColumn<User, String> genderCol = new TableColumn<>("Gender");
            TableColumn<User, String> birthdayCol = new TableColumn<>("Birthday");


            userNameCol.setCellValueFactory(new PropertyValueFactory<>("userName"));
            genderCol.setCellValueFactory(new PropertyValueFactory<>("gender"));
            birthdayCol.setCellValueFactory(new PropertyValueFactory<>("birthday"));
			
			userListTV.getColumns().addAll(userNameCol, genderCol, birthdayCol);
			userListTV.setItems(accounts.getData());
			
            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
            
            System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void init() {
		registerBtn.setOnAction(event ->{
			Register register = new Register();
			register.show();
    	});
		logOutBtn.setOnAction(event ->{
			System.exit(0);
    	});
		goBackBtn.setOnAction(event->{
			MainMenu mainMenu = new MainMenu();
			mainMenu.show();
		});
	}

}
