package ui;

import javafx.application.Application;
import javafx.stage.Stage;
import model.User;
import model.UserData;

public class Main extends Application{
	public static UserData user = new UserData();
	User account = new User("admin01", "adminPass", "foto", "Other", "01/01/2000", true);
	

	public static void main(String[] args) {
		launch(args);
	}
	@Override
	public void start(Stage primaryStage) throws Exception {
		Login main = new Login();
		main.show();
		user.getData().add(account);
	}
}