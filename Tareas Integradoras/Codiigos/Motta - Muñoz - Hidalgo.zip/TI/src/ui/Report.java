package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Ingredients;
import model.IngredientsData;

public class Report extends Stage{

	private TableView<Ingredients> dishesSoldTV;
	private TableView<Ingredients> dishesListTV;
	private Button logOutBtn;
	private Button goBackBtn;
	
	public Report() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Report.fxml"));
            Parent parent = loader.load();

            dishesSoldTV = (TableView) loader.getNamespace().get("dishesSoldTV");
            dishesListTV = (TableView) loader.getNamespace().get("dishesListTV");
            logOutBtn = (Button) loader.getNamespace().get("logOutBtn");
            goBackBtn = (Button) loader.getNamespace().get("goBackBtn");
            
            //ingre = new IngredientsData();
            
            TableColumn<Ingredients, String> employeeCol = new TableColumn<>("EMPLOYEE");
			TableColumn<Ingredients, Integer> nDishesCol = new TableColumn<>("N#DISHES");
			TableColumn<Ingredients, Double> totalCol = new TableColumn<>("Total$");
			
			TableColumn<Ingredients, String> dishCol = new TableColumn<>("DISH");
			//TableColumn<Ingredients, Integer> nDishesCol = new TableColumn<>("N#DISHES");
			//TableColumn<Ingredients, Double> totalCol = new TableColumn<>("Total$");

			//ingredientsCol.setCellValueFactory(new PropertyValueFactory<>("nameIngredient"));
			//quantityCol.setCellValueFactory(new PropertyValueFactory<>("quantity"));
			
			//tableIngreTV.getColumns().addAll(ingredientsCol, quantityCol);
			//tableIngreTV.setItems(ingre.getData());
			
            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
            
            System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private void init() {
		logOutBtn.setOnAction(event ->{
			System.exit(0);
    	});
		goBackBtn.setOnAction(event->{
			MainMenu mainMenu = new MainMenu();
			mainMenu.show();
		});
	}
}
