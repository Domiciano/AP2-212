package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import model.User;

public class MainMenu extends Stage{
	
	private Button ingreListBtn;
	private Button userListBtn;
	private Button menuBtn;
	private Button orderBtn;
	private Button reportsBtn;
	private User account=null;
	private Button logOutBtn;
	
	public MainMenu() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("MainMenu.fxml"));
            Parent parent = loader.load();

            ingreListBtn = (Button) loader.getNamespace().get("ingreListBtn");
            userListBtn = (Button) loader.getNamespace().get("userListBtn");
            menuBtn = (Button) loader.getNamespace().get("menuBtn");
            orderBtn = (Button) loader.getNamespace().get("orderBtn");
            reportsBtn = (Button) loader.getNamespace().get("reportsBtn");
            logOutBtn = (Button) loader.getNamespace().get("logOutBtn");

            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
            
            System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setAccount(User account) {
		this.account=account;
	}

	private void init() {
		ingreListBtn.setOnAction(event ->{
			IngredientsList ingreList = new IngredientsList();
			ingreList.show();
			System.out.println(account.getUserName());
		});
		userListBtn.setOnAction(event ->{
			if(account.isAdmin()){
				UserList userList = new UserList();
				userList.show();
			}else {
				System.out.println("yu not admin bruh");
			}
		});
		
		menuBtn.setOnAction(event ->{
			Menu userList = new Menu();
			userList.show();
		});
		
		orderBtn.setOnAction(event ->{
			DishList userList = new DishList();
			userList.show();
		});
		reportsBtn.setOnAction(event ->{
			Report reports = new Report();
			reports.show();
		});
		logOutBtn.setOnAction(event ->{
			System.exit(0);
    	});
	}
	
}
