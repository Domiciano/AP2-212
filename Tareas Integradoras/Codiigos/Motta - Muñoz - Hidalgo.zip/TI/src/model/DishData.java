package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DishData{
	//Singleton
		private static DishData instance = null;
		
		public static DishData getInstance() {
			if(instance == null) {
				instance = new DishData();
			}
			return instance;
		}
		private ObservableList<Dish> dish;
		
		private DishData() {
			dish = FXCollections.observableArrayList();
		}
		public ObservableList<Dish> getData() {
			return dish;
		}
}