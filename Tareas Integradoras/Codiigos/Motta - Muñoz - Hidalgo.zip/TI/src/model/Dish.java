package model;

import java.util.ArrayList;

public class Dish {
	//Attributes
	private String id = "";
	private String dish = "";
	private double price;
	private double quantity;
	private String state = "";
	private String date;
	Ingredients ingredientes;
	//Constants
	public static final boolean PENDING = false;
	public static final boolean IN_PROCESS = false;
	public static final boolean DELIVERED = false;
	public Dish(String pId, String pDish,double price, String pState, String pDate, String data) {
		id = pId;
		dish = pDish;
		state = pState;
		date = pDate;
		this.price=price;
		String[] lineas=data.split("\\\n");
		for(int i=0; i<lineas.length;i++) {
			System.out.println(lineas[i]);
			String[] columnas = lineas[i].split(" ");
			for(int o=0; o<columnas.length;o++) {
				System.out.println(columnas[o]);
				ingredientes= IngredientsData.getInstance().searchIngre(columnas[0]);
				quantity= Double.parseDouble(columnas[1]);
			}
		}
	}
	public Ingredients getIngredientes() {
		return ingredientes;
	}
	public void setIngredientes(Ingredients ingredientes) {
		this.ingredientes = ingredientes;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDish() {
		return dish;
	}
	public void setDish(String dish) {
		this.dish = dish;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	//ArrayList<Double> cantidades;
}
