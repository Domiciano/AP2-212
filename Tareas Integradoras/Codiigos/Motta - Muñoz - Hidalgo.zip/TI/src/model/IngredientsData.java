package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class IngredientsData {
	
	//Singleton
	private static IngredientsData instance = null;
	
	public static IngredientsData getInstance() {
		if(instance == null) {
			instance = new IngredientsData();
		}
		return instance;
	}
	
	private ObservableList<Ingredients> ingredient;
	
	private IngredientsData() {
		ingredient = FXCollections.observableArrayList();
	}
	public boolean searchIngredient(String nameIngredient) {
        boolean find=false;
        boolean continuar=true;
        for(int i=0; i<ingredient.size() && continuar; i++) {
            Ingredients a= ingredient.get(i);
            if(a!=null) {
                if(a.getNameIngredient().equals(nameIngredient)) {
                        find=true;
                        continuar=false;
                }else {
                    continuar=false;
                }
            }else {
                continuar=false;
            }
        }
        return find;
    }
	
	public Ingredients searchIngre(String nameIngredient) {
        Ingredients find=null;
        boolean continuar=true;
        for(int i=0; i<ingredient.size() && continuar; i++) {
            Ingredients a= ingredient.get(i);
            if(a!=null) {
                if(a.getNameIngredient().equalsIgnoreCase(nameIngredient)) {
                        find=a;
                        continuar=false;
                }
            }
        }
        return find;
    }
	public ObservableList<Ingredients> getData() {
		return ingredient;
	}
}