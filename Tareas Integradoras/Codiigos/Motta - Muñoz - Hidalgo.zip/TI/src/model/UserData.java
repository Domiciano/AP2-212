package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class UserData {
private ObservableList <User> usersAccount;
	
	public UserData() {
		usersAccount =  FXCollections.observableArrayList();
	}
	public boolean searchAccount(String user, String pass) {
        boolean logIn=false;
        boolean continuar=true;

        for(int i=0; i<usersAccount.size() && continuar; i++) {
            User a= usersAccount.get(i);
            if(a!=null) {
                if(a.getUserName().equals(user)) {
                    if(a.getPassword().equals(pass)) {
                        logIn=true;
                        continuar=false;
                    }
                }
            }
        }
        return logIn;
    }
	public User searchUser(String userName) {
		User search = null;
		boolean find = false;
		for(int i=0;i<usersAccount.size()&&!find;i++) {
			User user = usersAccount.get(i);
			if(user.getUserName().equals(userName)){
					search = usersAccount.get(i);
					find = true;
			}
		}
		return search;
	}
	public ObservableList<User> getData() {
		return usersAccount;
	}
}