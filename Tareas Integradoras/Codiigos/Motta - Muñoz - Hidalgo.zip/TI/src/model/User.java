package model;

public class User {
	//Attributes
		private String userName = "";
		private String password = "";
		private String profilePhoto = "";
		private String gender = "";
		private String birthday;
		private boolean admin;
		//Constants
		public static final String GENDER1 = "Male";
		public static final String GENDER2 = "Female";
		public static final String GENDER3 = "Other";
		//Methods
		public User(String pUserName, String pPassword, String pProfilePhoto, String pGender, String pBirthday, boolean admin){
			userName = pUserName;
			password = pPassword;
			profilePhoto = pProfilePhoto;
			gender = pGender;
			birthday = pBirthday;
			this.admin=admin;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getProfilePhoto() {
			return profilePhoto;
		}
		public void setProfilePhoto(String profilePhoto) {
			this.profilePhoto = profilePhoto;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getBirthday() {
			return birthday;
		}
		public void setBirthday(String birthday) {
			this.birthday = birthday;
		}
		public boolean isAdmin() {
			return admin;
		}
		public void setAdmin(boolean admin) {
			this.admin = admin;
		}
		
	}