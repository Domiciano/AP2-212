package model;

public class Ingredients {
	
	//Attributes
	private String nameIngredient;
	private double quantity;
	//Methods
	public Ingredients(String pNameIngredient, double pQuantity) {
		nameIngredient = pNameIngredient;
		quantity = pQuantity;
	}
	public String getNameIngredient() {
		return nameIngredient;
	}
	public void setNameIngredient(String nameIngredient) {
		this.nameIngredient = nameIngredient;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	public void addQuantity(double quantityAdd) {
		this.quantity = quantity + quantityAdd;
	}
}
