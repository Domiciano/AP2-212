package model;

public enum OrderStatus {
    PENDING,IN_PROCESS,DELIVERED;
}
