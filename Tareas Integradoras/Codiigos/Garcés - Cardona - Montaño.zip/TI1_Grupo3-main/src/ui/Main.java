package ui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import ui.Staff;

public class Main extends Application {
	
	private Staff staf;

	public static void main(String[] args) {
		launch(args);

	}
	
	public Main() {
		staf = new Staff();
	}

	@Override
	public void start(Stage primaryStage) throws Exception {		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("main-pane.fxml"));
		loader.setController(staf);
		Parent root = loader.load();
		
		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.show();

		staf.loadLogin();
	
		
	}

}
