package Ui;

import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class modulo_personal_DeleateEmployer extends Stage {
	 
	    private TextField tx_idEmployer;

	    
	    private PasswordField tx_passwordAdm;

	    
	    private Button bt_return;

	    
	    private Button bt_home;

	    
	    private Button bt_deleateEmployer;
}
