package Ui;

import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class modulo_personal_ChangeOfPassword extends Stage {
	
	
    private TextField tx_passwordActual;

    
    private PasswordField tx_paswordNew;

    
    private Button tb_return;

    
    private Button bt_home;

    
    private Button bt_actualicePassword;

    
    private PasswordField tx_paswordNewRepli;
    
}
