package model;

import java.util.ArrayList;

public class Control {

	public ArrayList<Employer>employer;
	public ArrayList<Ingredient> ingredients;
	public ArrayList<Oder>oder;
	public ArrayList<Dish>dish;
	
}
