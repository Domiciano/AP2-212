package model;

public class Node {
	
	//Key
	private String name;
	
	//Values
	private String phone;
	private String address;
	private String email;
	
	//Links
	private Node left, right;
	
	/* Node contructor
	 * <b> Pre:
	 * 	@param name
	 * 	@param phone
	 * 	@param address
	 * 	@param email
	 * </b>
	 */
	public Node(String name, String phone, String address, String email) {
		this.name = name;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	
	/* Insert a new node comparing the names alphabetically
	 * <b> Pre:
	 * 	@param newName
	 * 	@param newPhone
	 * 	@param newAddress
	 * 	@param newEmail
	 * </b>
	 */
	public void insert(String newName, String newPhone, String newAddress, String newEmail) {
		if(newName.compareTo(this.name)<0) {
			//Insert to the left
			if(this.left == null) {
				this.left = new Node(newName, newName, newName, newName);
			} else {
				this.left.insert(newName, newPhone, newAddress, newEmail);
			}
		} else if(newName.compareTo(this.name)>0){
			if(this.right == null) {
				this.right = new Node(newName, newPhone, newAddress, newEmail);
			} else {
				this.right.insert(newName, newPhone, newAddress, newEmail);
			}
		} else {
			System.out.println("�El usuario ya existe!.");
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Node getLeft() {
		return left;
	}

	public void setLeft(Node left) {
		this.left = left;
	}

	public Node getRight() {
		return right;
	}

	public void setRight(Node rigth) {
		this.right = rigth;
	}
	
}
