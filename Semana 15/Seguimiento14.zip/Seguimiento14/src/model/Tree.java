package model;

public class Tree {
	
	private Node root;
	
	//Activate InOrder
	public void triggerInOrder() {
		inOrder(root);
	}
	
	/* Order all the names alphabetically
	 * <b> Pre:
	 * 	@param node
	 * </b>
	 */
	public void inOrder(Node node) {
		//Base case
		if(node == null) {
			return;
		}
		//Recursive process
		inOrder(node.getLeft());
		System.out.println(node.getName());
		inOrder(node.getRight());
	}
	
	/* add a new node or programmer
	 * <b> Pre:
	 * 	@param name
	 * 	@param phone
	 * 	@param address
	 * 	@param email
	 * </b> 
	 */
	public void add(String name, String phone, String address, String email) {
		if(root == null) {
			root = new Node(name, phone, address, email);
		}else {
			root.insert(name, phone, address, email);
		}
	}
	
	//Activator of search
	public Node triggerSearch(String nameToSearch) {
		return search(root, nameToSearch);
	}

	/* In order to search the node
	 * <b> Pre:
	 * 	@param node
	 * 	@param nameToSearch
	 * </b>
	 */
	private Node search(Node node, String nameToSearch) {
		//Base case
		if(node == null) {
			return null;
		}
		if(nameToSearch == node.getName()) {
			return node;
		}
		//Recursive process
		if(nameToSearch.compareTo(node.getName())<0) {
			return search(node.getLeft(), nameToSearch);
		}else {
			return search(node.getRight(), nameToSearch);
		}
	}
	
	//gets the minimum from the left
	public Node getMin(Node current){
		if (current.getLeft() == null) {
			return current;
		} else {
			return getMin(current.getLeft());
		}
	}
	
	//Gets the maximum from the right
	public Node getMax(Node current) {
		if (current.getRight() == null) {
			return current;
		}else {
			return getMax(current.getRight());
		}
	}
	
	
	//Activator of delete
	public void triggerDelete(String name) {
		if (root != null){
			root = delete(root, name);
		}
	}
	
	/* Delete a node using the name
	 * <b> Pre:
	 * 	@param current
	 * 	@param name
	 * </b>
	 */
	public Node delete(Node current, String name){
		if (current.getName() == name){
			if (current.getLeft() == null && 
					current.getRight() == null){
				return null;
			} else if (current.getLeft() != null && 
					current.getRight() != null) {
				Node succesor = getMin(current.getRight());
				Node newRightTree = delete(current.getRight(), succesor.getName());
				
				succesor.setLeft(current.getLeft());
				succesor.setRight(newRightTree);

				return succesor;
			} else if (current.getLeft() != null) {
				return current.getLeft();
			} else {
				return current.getRight();
			}
			
		} else if (name.compareTo(current.getName()) < 0) {
			Node newLeftTree = delete(current.getLeft(), name);
			current.setLeft(newLeftTree);
		} else {
			Node newRightTree = delete(current.getRight(), name);
			current.setRight(newRightTree);
		}
		
		return current;
	}
	
	//Activator o maxLevelTree
	public void triggerHigthOfTree() {
		int level = getHigthOfTree(root, 1);
		System.out.println(level);
	}

	/*	Gets the higth of the tree
	 * @param node
	 * @param higth
	 */
	public int getHigthOfTree(Node node, int level) {

		if (node == null) {
			return level-1;
		} else {

			int A = getHigthOfTree(node.getLeft(), level + 1);
			int B = getHigthOfTree(node.getRight(), level + 1);

			return Math.max(A, B);
		}

	}
	
	
	
}
