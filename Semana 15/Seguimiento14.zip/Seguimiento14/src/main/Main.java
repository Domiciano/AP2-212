package main;

import java.util.Scanner;

import model.Node;
import model.Tree;

public class Main {
		
	private static Scanner in;
	private static Tree tree;
	
	public Main() {
		in = new Scanner(System.in);
		tree = new Tree();
	}
	
	public static void main(String[] args) {
		
		Main m = new Main();
		
		boolean exit = false;
		while(exit==false) {
			System.out.println("Maratones:"
					+"\n1. Agregar"
					+"\n2. Buscar"
					+"\n3. Eliminar"
					+"\n4. Listar"
					+"\n5. Ver altura del arbol."
					+"\n6. Salir");		
			String line = in.nextLine();
			int option = Integer.parseInt(line);
			
			switch(option) {
			case 1:
				System.out.println("�Ingrese los datos del programador! "
						+"\n1. Ingrese el nombre:");
				String name = in.nextLine();
				System.out.println("2. Telefono:");	
				String phone = in.nextLine();
				System.out.println("3. Direccion:");
				String address = in.nextLine();
				System.out.println("4. Email:");
				String email = in.nextLine();
				tree.add(name, phone, address, email);
				break;
			case 2: 
				System.out.println("Ingrese el nombre del programador a buscar: ");	
				String nameToSearch = in.nextLine();
				Node node = tree.triggerSearch(nameToSearch);
				if(node == null) {
					System.out.println("No se encontro el nombre");
				}else {
					System.out.println("Resultado de busqueda: ");
					System.out.println(node.getName());
					System.out.println(node.getPhone());
					System.out.println(node.getAddress());
					System.out.println(node.getEmail());
				}
				break;
			case 3:
				System.out.println("Ingrese el nombre del programador a eliminar: ");
				String nameToDelete = in.nextLine();
				tree.triggerDelete(nameToDelete);
				System.out.println("�Eliminado exitosamente!");
				break;
			case 4:
				tree.triggerInOrder();
				System.out.println("�Programadores ordenados!");
				break;
			case 5: 
				System.out.println("La altura del arbol es: ");
				tree.triggerHigthOfTree();
				break;
			case 6:
				exit = true;
				break;
			}
		}
		
		
	}

}
