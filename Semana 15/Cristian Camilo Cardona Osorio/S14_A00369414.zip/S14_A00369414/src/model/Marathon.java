package model;

public class Marathon {
	
	
	private Node root;
	
	public void addParticipant(String name, String phone, String address, String email) {
		
		if (root == null) {

			root = new Node(name, phone, address, email);
		} else {

			root.insert(name, phone, address, email);
		}
	}
	
	public void triggerInOrder() {

		inorder(root);

	}

	// Recursivo
	public void inorder(Node node) {
		// Caso base
		if (node == null) {
			return;
		}

		// Recursivo
		inorder(node.getLeft());

		System.out.println(node.getName());

		inorder(node.getRight());

	}
	
	public Node triggerSearch(String name) {

		return search(root, name);

	}

	public Node search(Node node, String name) {

		if (node == null) {

			return null;

		}

		if (node.getName().compareTo(name) == 0) {

			return node;
		}

		/////////// procedimientos

		if (name.compareTo(node.getName()) < 0) {

			return search(node.getLeft(), name);

		} else {

			return search(node.getRight(), name);
		}

	}
	
	public void triggerDelete(String name) {
		
		if (root != null) {
			root = delete(root, name);
		}

	}

	public Node delete(Node current, String name) {

		if (current.getName().compareTo(name) == 0) {

			if (current.getLeft() == null && current.getRight() == null) {
				return null;
			} else if (current.getLeft() != null && current.getRight() != null) {
				
				Node sucess = getMin(current.getRight());
				
				Node newRightTree = delete(current.getRight(), sucess.getName());
				
				sucess.setLeft(current.getLeft());
				sucess.setRight(newRightTree);
				
				return sucess;
				

			} else if (current.getLeft() != null) {

				return current.getLeft();
				
			} else  {

				return current.getRight();
			}

		} else if (name.compareTo(current.getAddress()) < 0) {

			Node newLeftTree = delete(current.getLeft(), name);
			current.setLeft(newLeftTree);

		} else {
			Node newRightTree = delete(current.getRight(), name);
			current.setRight(newRightTree);
		}

		return current;
	}
	
	public Node getMin(Node current) {

		if (current.getLeft() == null) {
			return current;
		} else {
			return getMin(current.getLeft());
		}
	}

	public Node getMax(Node current) {

		if (current.getRight() == null) {
			return current;
		} else {
			return getMin(current.getRight());
		}
	}
	
}
