package model;

public class Node {

	private String name;
	private String phone;
	private String address;
	private String email;

	private Node left;
	private Node right;

	public Node(String name, String phone, String address, String email) {

		this.name = name;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	
	public Node() {}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Node getLeft() {
		return left;
	}

	public void setLeft(Node left) {
		this.left = left;
	}

	public Node getRight() {
		return right;
	}

	public void setRight(Node right) {
		this.right = right;
	}

	public void insert(String newname, String phone, String address, String email) {

		if (newname.compareTo(this.name) < 0) {

			// Insertar a la izquierda

			if (this.left == null) {

				this.left = new Node(newname, phone, address, email);

			} else {

				this.left.insert(newname, phone, address, email);
			}

		} else if (newname.compareTo(this.name) > 0) {

			// Insertar a la derecha

			if (this.right == null) {

				this.right = new Node(newname, phone, address, email);

			} else {

				this.right.insert(newname, phone, address, email);
			}

		} else {

			// exception
		}

	}

	@Override
	public String toString() {
		
		return "Nombre: " + name + "\nTelefono: " + phone + "\nDireccion: " + address + "\nEmail: " + email;
	}
	
	
	

}
