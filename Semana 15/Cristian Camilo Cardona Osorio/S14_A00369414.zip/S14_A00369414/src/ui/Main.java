package ui;

import java.util.Scanner;

import model.Marathon;
import model.Node;

public class Main {

	private static Scanner sn = new Scanner(System.in);
	private Marathon m;

	public Main() {

		m = new Marathon();
	}

	public static void main(String[] args) {

		Main m = new Main();

		m.menu();
	}

	public void menu() {

		int num = -1;

		while (num == -1) {

			System.out.println(
					"\nMARATON DE PROGRAMACION" + "\n 1: Agregar un participante " + "\n 2: Eliminar un participante"
							+ "\n 3: Buscar un participante" + "\n 4: Lista de participantes actuales" + "\n 5: Salir");

			System.out.print("Escoga una de las opciones: ");
			int option = sn.nextInt();
			sn.nextLine();

			switch (option) {

			case 1:
				addParticipant();
				break;

			case 2:
				deleteParticipant();
				break;

			case 3:
				searchParticipant();
				break;

			case 4:
				System.out.println("Lista de participantes: ");
				listOfParticipants();
				break;

			case 5:
				System.exit(0);
				break;
				
			default:
				System.out.println("Opcion invalidad");
				break;
			}
			
		}

	}

	public void addParticipant() {

		System.out.print("Nombre del participante: ");
		String name = sn.nextLine();

		System.out.print("Telefono del participante: ");
		String phone = sn.nextLine();

		System.out.print("Direccion del participante: ");
		String address = sn.nextLine();

		System.out.print("Email del participante: ");
		String email = sn.nextLine();

		m.addParticipant(name, phone, address, email);

	}

	public void deleteParticipant() {
		
		System.out.println("Ingrese el nombre del participante que desea eliminar");
		String name = sn.nextLine();
		
		m.triggerDelete(name);

	}

	public void searchParticipant() {
		
		System.out.println("Ingrese el nombre del participante que desea buscar: ");
		String name = sn.nextLine();
		
		Node nd = new Node();
		
		nd = m.triggerSearch(name);
		
		if(nd == null) {
			 System.out.println("No existe este participante");
		}
		else{
			
			System.out.println("Datos del participante ingresado: ");
			
			System.out.println(nd.toString());
		}
	}

	public void listOfParticipants() {

		m.triggerInOrder();
	}

}
