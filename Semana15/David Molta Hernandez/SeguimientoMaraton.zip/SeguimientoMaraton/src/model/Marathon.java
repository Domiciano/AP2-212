package model;

public class Marathon {
	
	
	private Programmer root;
	
	public void addParticipant(String name, String phone, String address, String email) {
		if (root == null) {
			root = new Programmer(name, phone, address, email);
		} else {
			try {
				root.insert(name, phone, address, email);
			} catch (ProgrammerAlreadyExists e) {
				System.out.println(e);
			}
		}
	}
	public void triggerInOrder() {
		inOrder(root);
	}
	public Programmer triggerSearchProgrammer(String name) {
		return searchProgrammer(root, name);
	}
	public void triggerDelete(String name) {
		if (root != null) {
			root = deleteProgrammer(root, name);
		}
	}
	public void inOrder(Programmer node) {
		if (node == null) {
			return;
		}
		inOrder(node.getLeft());
		System.out.println(node.getName());
		inOrder(node.getRight());
	}
	public Programmer searchProgrammer(Programmer node, String name) {
		if (node == null) {
			return null;
		}
		if (node.getName().compareTo(name) == 0) {
			return node;
		}
		if (name.compareTo(node.getName()) < 0) {
			return searchProgrammer(node.getLeft(), name);
		} else {
			return searchProgrammer(node.getRight(), name);
		}
	}
	public Programmer deleteProgrammer(Programmer current, String name) {
		if (current.getName().compareTo(name) == 0) {
			if (current.getLeft() == null && current.getRight() == null) {
				return null;
			} else if (current.getLeft() != null && current.getRight() != null) {

				Programmer aux = getMin(current.getRight());
				Programmer rightT = deleteProgrammer(current.getRight(), aux.getName());
				aux.setLeft(current.getLeft());
				aux.setRight(rightT);
				return aux;

			} else if (current.getLeft() != null) {
				return current.getLeft();
			} else  {
				return current.getRight();
			}
		} else if (name.compareTo(current.getAddress()) < 0) {
			Programmer leftT = deleteProgrammer(current.getLeft(), name);
			current.setLeft(leftT);
		} else {
			Programmer newRightTree = deleteProgrammer(current.getRight(), name);
			current.setRight(newRightTree);
		}
		return current;
	}
	public Programmer getMin(Programmer current) {

		if (current.getLeft() == null) {
			return current;
		} else {
			return getMin(current.getLeft());
		}
	}


	
}
