package model;

public class Programmer {
	//Nodos de control
	private Programmer left;
	private Programmer right;
	// Atributos del usuario
	private String name;
	private String phone;
	private String address;
	private String email;


	public Programmer(String name, String phone, String address, String email) {

		this.name = name;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	
	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public Programmer getLeft() {
		return left;
	}

	public void setLeft(Programmer left) {
		this.left = left;
	}

	public Programmer getRight() {
		return right;
	}

	public void setRight(Programmer right) {
		this.right = right;
	}

	public void insert(String keyName, String phone, String address, String email) throws ProgrammerAlreadyExists {

		if (keyName.compareTo(this.name) < 0) {

			if (this.left == null) {
				this.left = new Programmer(keyName, phone, address, email);
			} else {
				this.left.insert(keyName, phone, address, email);
			}
		} else if (keyName.compareTo(this.name) > 0) {

			if (this.right == null) {
				this.right = new Programmer(keyName, phone, address, email);
			} else {
				this.right.insert(keyName, phone, address, email);
			}

		} else {

		throw new ProgrammerAlreadyExists();
		}

	}

	public String toString() {
		
		return "Name: " +
				name +
				"\nPhone: " + phone +
				"\nAddress: " + address +
				"\nEmail: " +
				email;
	}
	
	
	

}
