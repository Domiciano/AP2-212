package main;

import java.util.Scanner;

import model.Marathon;
import model.Programmer;

public class Main {

	private static Scanner scanner = new Scanner(System.in);
	private Marathon marathon = new Marathon();

	public Main() {

	}

	public static void main(String[] args) {
		Main main = new Main();
		main.mainMenu();
	}

	public void mainMenu() {

		int control = -1;

		while (control == -1) {

			System.out.println(
					"\nWELCOME TO THE MARATHON MENU" +
							"\n 1: Add a participant "
							+ "\n 2: Delete a participant"
							+ "\n 3: Search for a participant"
							+ "\n 4: Participant list"
							+ "\n 0: EXIT");

			System.out.print("Please select an option: ");
			int option = scanner.nextInt();
			scanner.nextLine();

			switch (option) {

			case 1:
				addParticipantToList();
				break;

			case 2:
				deleteParticipantOfTheList();
				break;

			case 3:
				searchParticipant();
				break;

			case 4:
				System.out.println("Participant list: ");
				showListOfParticipants();
				break;

			case 0:
				System.exit(0);
				break;
				

			}
			
		}

	}

	public void addParticipantToList() {

		System.out.print("Participant name: ");
		String name = scanner.nextLine();

		System.out.print("Participant phone number: ");
		String phone = scanner.nextLine();

		System.out.print("Participant address: ");
		String address = scanner.nextLine();

		System.out.print("Participant email: ");
		String email = scanner.nextLine();

		marathon.addParticipant(name, phone, address, email);

	}

	public void deleteParticipantOfTheList() {
		
		System.out.println("Name of the participant that you want to delete");
		String participantName = scanner.nextLine();
		
		marathon.triggerDelete(participantName);

	}

	public void searchParticipant() {
		
		System.out.println("Enter the name of the participant that you want to search");
		String name = scanner.nextLine();
		
			Programmer progm = marathon.triggerSearchProgrammer(name);
		
		if(progm == null) {
			 System.out.println("Verify the information that you registered");
		}
		else{
			
			System.out.println(">==Information==<");

			System.out.println(progm);
		}
	}

	public void showListOfParticipants() {
		marathon.triggerInOrder();
	}

}
