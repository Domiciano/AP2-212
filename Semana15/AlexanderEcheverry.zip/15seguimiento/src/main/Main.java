package main;

import java.util.Scanner;

import model.Marathon;
import model.Programmer;
import model.RepeatedProgrammerException;

public class Main {

	private static Scanner sc = new Scanner(System.in);
	private Marathon marathon;

	public Main() {
		marathon = new Marathon();
	}

	public static void main(String[] args) {
		Main principal = new Main();
		int option = 0;
		do {
			option = principal.menu();
			principal.execute(option);
		}while(option != -1);
	}

	public int menu() {
		System.out.println(
				" (programming marathon) \n" +
						"1. add competitor\n" +
						"2. delete competitor\n" +
						"3. search participant \n" +
						"4. list of actual participants\n" +
						"5. Get out");
		return Integer.parseInt(sc.nextLine());
	}

	public void execute(int option){
		switch (option) {
			case 1:
				addParticipant();
				break;
			case 2:
				deleteParticipant();
				break;
			case 3:
				searchParticipant();
				break;
			case 4:
				listOfParticipants();
				break;
			case 5:
				System.exit(0);
				break;
		}
	}

	public void addParticipant() {
		System.out.print("Participant name: ");
		String name = sc.nextLine();

		System.out.print("Participant phone: ");
		String phone = sc.nextLine();

		System.out.print("Participant address: ");
		String address = sc.nextLine();

		System.out.print("Participant email: ");
		String email = sc.nextLine();

		try {
			marathon.addParticipant(name, phone, address, email);
		} catch (RepeatedProgrammerException e) {
			System.out.println("This participant already exists");
		}
	}

	public void deleteParticipant() {
		System.out.println("Enter participant name");
		String name = sc.nextLine();
		
		marathon.triggerDelete(name);
	}

	public void searchParticipant() {
		System.out.println("Enter participant name: ");
		String name = sc.nextLine();
		
		Programmer programmer;
		
		programmer = marathon.triggerSearch(name);
		if(programmer == null) {
			 System.out.println("This participant doesn't exit ");
		}
		else{
			System.out.println("Participant data: ");
			System.out.println(programmer);
		}
	}

	public void listOfParticipants() {
		marathon.triggerInOrder();
	}
}
