package model;

public class Marathon {
	private Programmer rootProgrammer;
	
	public void addParticipant(String name, String phone, String address, String email) throws RepeatedProgrammerException{
		if (rootProgrammer == null){
			rootProgrammer = new Programmer(name, phone, address, email);
		} else {
			rootProgrammer.insert(name, phone, address, email);
		}
	}
	
	public void triggerInOrder(){
		inorder(rootProgrammer);
	}

	public void inorder(Programmer node) {
		if (node == null){
			return;
		}
		inorder(node.getLeft());
		System.out.println(node.getName());
		inorder(node.getRight());
	}
	
	public Programmer triggerSearch(String name) {
		return search(rootProgrammer, name);
	}

	public Programmer search(Programmer node, String name) {
		if (node == null){
			return null;
		}
		if (node.getName().compareTo(name) == 0){
			return node;
		}
		if (name.compareTo(node.getName()) < 0){
			return search(node.getLeft(), name);
		} else {
			return search(node.getRight(), name);
		}
	}
	
	public void triggerDelete(String name){
		if (rootProgrammer != null){
			rootProgrammer = delete(rootProgrammer, name);
		}
	}

	public Programmer delete(Programmer current, String name){
		if (current.getName().compareTo(name) == 0){
			if (current.getLeft() == null && current.getRight() == null) {
				return null;
			} else if (current.getLeft() != null && current.getRight() != null) {
				Programmer successor = getMin(current.getRight());
				
				Programmer newRightTree = delete(current.getRight(), successor.getName());
				
				successor.setLeft(current.getLeft());
				successor.setRight(newRightTree);
				
				return successor;
			} else if (current.getLeft() != null){
				return current.getLeft();
			} else  {
				return current.getRight();
			}
		} else if (name.compareTo(current.getAddress()) < 0) {
			Programmer newLeftTree = delete(current.getLeft(), name);
			current.setLeft(newLeftTree);
		} else {
			Programmer newRightTree = delete(current.getRight(), name);
			current.setRight(newRightTree);
		}
		return current;
	}
	
	public Programmer getMin(Programmer current) {
		if (current.getLeft() == null) {
			return current;
		} else {
			return getMin(current.getLeft());
		}
	}

	public Programmer getMax(Programmer current) {
		if (current.getRight() == null) {
			return current;
		} else {
			return getMin(current.getRight());
		}
	}
}
