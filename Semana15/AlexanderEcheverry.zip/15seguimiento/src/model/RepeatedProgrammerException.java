package model;

public class RepeatedProgrammerException extends Exception{

    public RepeatedProgrammerException() {
        super("The participant already exists");
    }
}
