package model;

public class Programmer {

	private String name;
	private String phone;
	private String address;
	private String email;

	private Programmer left;
	private Programmer right;

	public Programmer(String name, String phone, String address, String email) {

		this.name = name;
		this.phone = phone;
		this.address = address;
		this.email = email;
	}
	
	public Programmer() {}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Programmer getLeft() {
		return left;
	}

	public void setLeft(Programmer left) {
		this.left = left;
	}

	public Programmer getRight() {
		return right;
	}

	public void setRight(Programmer right) {
		this.right = right;
	}

	public void insert(String newname, String phone, String address, String email) throws RepeatedProgrammerException{
		if (newname.compareTo(this.name) < 0) {
			if (this.left == null) {
				this.left = new Programmer(newname, phone, address, email);
			} else {
				this.left.insert(newname, phone, address, email);
			}
		} else if (newname.compareTo(this.name) > 0) {
			if (this.right == null) {
				this.right = new Programmer(newname, phone, address, email);
			} else {
				this.right.insert(newname, phone, address, email);
			}
		} else {
			throw new RepeatedProgrammerException();
		}
	}

	@Override
	public String toString() {
		return "Programmer{" +
				"name='" + name + '\'' +
				", phone='" + phone + '\'' +
				", address='" + address + '\'' +
				", email='" + email + '\'' +
				", left=" + left +
				", right=" + right +
				'}';
	}
}
