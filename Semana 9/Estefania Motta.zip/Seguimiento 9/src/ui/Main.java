package ui;
import java.util.Scanner;

import exceptions.DiaDelMesException;
import exceptions.MenorDeEdadException;
import model.Minimarket;
import model.Person;
public class Main {
	//Attributes
	private Minimarket mainMinimarket;
	// global variables
	public static Scanner lector;
	
	public Main(){
		mainMinimarket = new Minimarket();
		lector = new Scanner(System.in);
	}	
	public static void main(String[] args) {
		Main objMain=new Main();
		
		boolean menu=true;
		int opcions = 0;
		while(menu){
			System.out.println("1.- Register Person");
            System.out.println("2.- Number of people");
            System.out.println("3.- Exit");        
            System.out.println("Enter the action to perform: ");
			opcions=Integer.parseInt(lector.nextLine());
			switch(opcions){
				case 1:
					objMain.addPerson();
				break;
				case 2:
					objMain.showTotalPeople();
				break;
				case 3:
					menu=false;
				break;
				default:
				System.out.println("Only numbers between 1 and 3.");
			break;
			}
		}

	}
	public void addPerson() {
		try {
			System.out.println("Inset Id.");
			String id = lector.nextLine();
			System.out.println("Inset type of document.");
			System.out.println("1.- TI");
			System.out.println("2.- CC");
			System.out.println("3.- PP");
			System.out.println("4.- CE");
			int types = Integer.parseInt(lector.nextLine());
			mainMinimarket.addPerson(id, types);
			mainMinimarket.validateDate(id);
		}catch(MenorDeEdadException ex) {
			System.out.println(ex.getMessage());
		} catch (DiaDelMesException e) {
			System.out.println(e.getMessage());
		} 
	}
	public void showTotalPeople() {
		mainMinimarket.total();
	}
}
