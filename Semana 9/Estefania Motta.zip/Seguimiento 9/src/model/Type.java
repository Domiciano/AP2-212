package model;
public enum Type {
	TI, CC, PP, CE;
}
