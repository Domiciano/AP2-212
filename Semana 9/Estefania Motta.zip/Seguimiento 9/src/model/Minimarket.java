package model;

import java.util.ArrayList;
import java.util.Date;
import exceptions.DiaDelMesException;
import exceptions.MenorDeEdadException;

public class Minimarket {

	private int totalPeople = 0;
	//Relations
	private ArrayList<Person> persons;
	
	public Minimarket(){
		persons = new ArrayList<Person>();
	}
	public void addPerson(String id, int types) throws MenorDeEdadException{
		totalPeople++;
		Person person = new Person(id, types);
		persons.add(person);
	}
	public void validateDate(String id) throws DiaDelMesException{
		char A = id.charAt(id.length()-2);
		int penultimo = Integer.parseInt(A+"");
		
		Date date = new Date();
		
		int day = date.getDay();
		
		if((day%2!= 0 && penultimo%2==1) || (day%2!= 1 && penultimo%2==0)) {
		}else {
			throw new DiaDelMesException();
		}
	}
	public void total() {
		System.out.println("The total number of people who have tried to enter is "+totalPeople+".");
	}
}