package exceptions;

public class MenorDeEdadException extends Exception{
	public MenorDeEdadException() {
		super("No esta disponible el ingreso a los menores de edad.");
	}
}
