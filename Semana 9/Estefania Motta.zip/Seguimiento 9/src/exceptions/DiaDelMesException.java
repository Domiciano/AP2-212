package exceptions;

public class DiaDelMesException extends Exception{
	public DiaDelMesException() {
		super("No esta disponible el ingeso para este dia.");
	}
}
