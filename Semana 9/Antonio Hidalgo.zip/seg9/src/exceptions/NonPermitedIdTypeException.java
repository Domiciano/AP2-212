package exceptions;

public class NonPermitedIdTypeException extends RuntimeException{
	
	public NonPermitedIdTypeException() {
		super("no se permite la entrada a menores de edad");
	}

}
