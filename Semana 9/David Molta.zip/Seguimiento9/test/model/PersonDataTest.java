package model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import exceptions.kidsCannotEnterTheMarketException;
import exceptions.personCannotGoOutException;

class PersonDataTest {
	
    private PersonData persons= new PersonData();

    
    public void setUpScenario(){

    }

    @Test
    public void testAddMethod() {
        setUpScenario();
        String idNumber = "1010062466";
        char[] chararray = idNumber.toCharArray();
        int day = 9;
        
        assertAll( () -> persons.verifyRegister(idNumber, chararray, day));
        
        
    }
    
    @Test
    public void testKidsCannotEnter() {
    	setUpScenario();
    	  assertThrows(kidsCannotEnterTheMarketException.class, () -> {
             persons.verifyKids(1);
          });
    	
    }
    
    @Test
    public void testIdOddCannotOdd (){
    	setUpScenario();
    	String idNumber = "1010062476";
        char[] chararray = idNumber.toCharArray();
        int day = 9;
    	  assertThrows(personCannotGoOutException.class, () -> {
    		  persons.verifyRegister(idNumber, chararray, day);
          });
    	
    }
    @Test
    public void testIdEvenCannotEven (){
    	setUpScenario();
    	String idNumber = "1010062486";
        char[] chararray = idNumber.toCharArray();
        int day = 8;
    	  assertThrows(personCannotGoOutException.class, () -> {
    		  persons.verifyRegister(idNumber, chararray, day);
          });
    	
    }

    
    
}
