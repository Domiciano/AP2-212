package main;

import java.util.Scanner;

import exceptions.kidsCannotEnterTheMarketException;
import exceptions.personCannotGoOutException;
import model.PersonData;


public class Main {
	PersonData personData = new PersonData();
	Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		Main m = new Main();
		m.menu();
		
	}
	
	
	public Main() {
		
	}
	
	
	
	public void menu() {
		int option =0;
		
		do {
			
			
			System.out.println("Select an option" + 
			"\n1.Register a new person" + 
					"\n2.Consult how many people tried to enter" + 
			"\n0.Close");
			option = Integer.parseInt(sc.nextLine());
			
			switch(option) {
			
			
			case 1:

				verifyRegister();

				break;
			case 2:
				System.out.println(personData.getTotalTry());
				break;
			
			
			}
			
			
		}while(option!=0);
		
		
		
		
		
		
	}
	
	public void verifyRegister(){
		
		System.out.println("Select your identification type: " + 
		"\n1.TI (Tarjeta de identidad) " + 
				"\n2.CC (C�dula de ciudadan�a) " + 
		"\n3.PP (Pasaporte)" + 
				"\n4.CE (C�dula de extranjer�a");
		
		int option = Integer.parseInt(sc.nextLine());
		try {
		register(personData.verifyKids(option));
		
		}catch(kidsCannotEnterTheMarketException e) {
			System.out.println("The kids cannot enter the market place");
		}
		
		
	}
	
	public void register(int dia){
		
		System.out.println("Enter your id number");
		String idnumber = sc.nextLine();
		char[] chararray = idnumber.toCharArray();
		
		try {
			System.out.println(personData.verifyRegister(idnumber, chararray, dia));
			
		
		
		}catch(personCannotGoOutException e) {
			System.out.println("The id number cannot go out this day");
		}
		
		
		
		
	}
	
	
	

}
