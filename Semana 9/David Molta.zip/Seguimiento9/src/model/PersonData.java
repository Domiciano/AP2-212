package model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import exceptions.kidsCannotEnterTheMarketException;
import exceptions.personCannotGoOutException;

public class PersonData {

	ArrayList<Person> persons;
	private int totalTry;
	
	public PersonData() {
		persons = new ArrayList<>();
		totalTry= 0;
	}


	public ArrayList<Person> getPersons() {
		return persons;
	}

	
	public int getTotalTry() {
		return totalTry;
	}


	public int verifyKids(int option) throws kidsCannotEnterTheMarketException  {
		totalTry++;
		if(option==1) {
			
			throw new kidsCannotEnterTheMarketException();
			
			
		}else {
			SimpleDateFormat format = new SimpleDateFormat("dd");
			Date date = new Date();
			int fecha = Integer.parseInt(format.format(date));

			return fecha;

			
		}
		
	}
	
	
	public String verifyRegister(String idnumber, char[]idChars,int dia)  throws personCannotGoOutException  {
		String msg="";
		if(idChars[idnumber.length()-2]%2==0) {
			if(!(dia%2==0)) {
				persons.add(new Person(idnumber));
				msg = "Succesfully added";
			}else {
				throw new personCannotGoOutException();
			}
			
		}else {
			
			if(dia%2==0) {
				persons.add(new Person(idnumber));
				msg = "Succesfully added";
			}else {
				throw new personCannotGoOutException();
			}
			
			
			
		}
		
		return msg;

	}
	
	
	
	
	
	
}
