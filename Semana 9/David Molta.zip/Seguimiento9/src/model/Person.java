package model;

public class Person {
	
	private String idNumber;
	
	
	
	public Person(String idNumber) {
		this.idNumber = idNumber;
	}
	
	
}
