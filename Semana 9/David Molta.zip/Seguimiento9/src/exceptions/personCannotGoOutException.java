package exceptions;

public class personCannotGoOutException extends Exception{

}
