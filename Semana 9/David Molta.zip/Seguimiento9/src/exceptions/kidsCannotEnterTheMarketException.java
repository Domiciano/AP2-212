package exceptions;

public class kidsCannotEnterTheMarketException extends Exception {
	

}
