package exceptions;

public class PicoYcedulaException extends RuntimeException{

	public PicoYcedulaException() {
		super("Hoy tiene pico y cedula");
	}
}
