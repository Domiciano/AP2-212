package model;

public class Usuario {
	
	private String id;
	private String idType;
	public Usuario(String id, int idType) {
		super();
		this.id = id;
		
		switch(idType) {
		
			case 1:
				this.idType="TI";
			break;
			
			case 2:
				this.idType="CC";
			break;
			
			case 3:
				this.idType="PP";
			break;
			
			case 4:
				this.idType="CE";
			break;
		}
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIdType() {
		return idType;
	}
	
	
}
