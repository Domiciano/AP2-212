package model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import exceptions.NonPermitedIdTypeException;
import exceptions.PicoYcedulaException;

public class Market {
	
	ArrayList<Usuario> cliente = new ArrayList<>();
	int clientesTotal=0;

	public String ingreso(String id, int idType) throws NonPermitedIdTypeException, PicoYcedulaException{
			
		clientesTotal++;
		Date date = new Date();

	    SimpleDateFormat format = new SimpleDateFormat("dd");
	    String fecha = format.format(date);
	    int dia = Integer.parseInt(fecha);
	    System.out.println(fecha);
	    
	    if(idType==1) {
	    	throw new NonPermitedIdTypeException();
	    }
	    int l = id.length();
	    System.out.println(id.charAt(l-1));
	    
	    if(dia%2==0) {
	    	if(id.charAt(l-2)%2==0) {
	    		throw new PicoYcedulaException();
	    	}else {
	    		Usuario d = new Usuario(id, idType);
	    		cliente.add(d);
	    	}
	    }else {
	    	if(id.charAt(l-2)%2!=0) {
	    		throw new PicoYcedulaException();
	    	}else {
	    		Usuario d = new Usuario(id, idType);
	    		cliente.add(d);
	    	}
	    }
	    String message="el usuario se ha agregado exitosamente";
	    return message;
	}
	
	public String list() {
		String m="intentos de ingreso: " + clientesTotal + "\n";
		for(int i=0; i<cliente.size(); i++) {
			m+="id: " + cliente.get(i).getId() + "\n" + "tipo de documento: " + cliente.get(i).getIdType() + "\n";
		}
		return  m;
	}
}
