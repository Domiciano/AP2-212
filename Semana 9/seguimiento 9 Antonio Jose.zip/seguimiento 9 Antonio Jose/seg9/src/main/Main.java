package main;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import model.Market;

public class Main {
	
	static Market market =new Market();
	private static Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		menu();
	}

	private static void menu() {
		int a=0;
		
		System.out.println("seleccione lo que quiere hacer:");
		
		System.out.println("1-ingresar persona");
		System.out.println("2-ver lista de ingresados");
		System.out.println("3-cerrar programa");
		
		a= scan.nextInt();
		scan.nextLine();
		switch(a) {
			
			case 1:
				ingreso();
			break;
			
			case 2:
				list();
			break;
			
			case 3:
				System.exit(0);
			break;
		}
	}

	private static void list() {
		
		System.out.println(market.list());
		
		menu();
		
	}

	private static void ingreso() {
		int tipoT = 0;
		String id = "";
		int i=0;
		
		while(i==0) {
			System.out.println("elija su tipo de identificacion:");
			System.out.println("1-TI");
			System.out.println("2-CC");
			System.out.println("3-PP");
			System.out.println("4-CE");
		
			tipoT = scan.nextInt();
			scan.nextLine();
		
			System.out.println("ingrese su identificacion:");
		
			id=scan.nextLine();
		
			if(tipoT>0 && tipoT<5) {
				market.ingreso(id, tipoT);
				i=1;
			}else {
				System.out.println("por favor ponga un tipo valido");
			}
		}
		menu();
	}

}
