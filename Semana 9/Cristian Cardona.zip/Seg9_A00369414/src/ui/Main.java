package ui;

import java.util.Scanner;

import exceptions.NotAgeAllowedException;
import exceptions.NotDaySafeToEnterException;
import model.DataPersons;
import model.DocumentType;


public class Main {

	public Scanner reader = new Scanner(System.in);
	
	private DataPersons persons;
	
	public static void main(String[] args) {
				
		Main main = new Main();
		main.menu();

	}
	
	public Main() {
		persons = new DataPersons();
	}

	public void menu() {

		int exit = 0;

		do {

			System.out.println("Minimercado Mi Barrio");

			System.out.print("1. Registrar una persona en el mini mercado\n");
			System.out.print("2. Cantidad de personas que han intentado entrar\n");
			System.out.print("3. Salir del programa\n");

			System.out.print("Escoge una opcion: ");
			int option = reader.nextInt();
			reader.nextLine();
			System.out.println();

			switch (option) {

			case 1:
				registerPerson();
				break;

			case 2:
				System.out.print("Se han registrado o intentado registrar "+persons.getAttemptsReg()+" personas\n");
				break;

			case 3:
				exit = -1;
				break;

			default:
				System.out.println("Opcion invalidad");
				break;
			}

		} while (exit != -1);
	}

	

	public void registerPerson() {
		
		System.out.println("Escoga su tipo de documento: "
				+ "\n1. TI (Tarjeta de idendidad)"
				+ "\n2. CC (Cedula de ciudadania)"
				+ "\n3. PP (Pasaporte)"
				+ "\n4. CE (Cedula de extranjeria)");
		
		System.out.print("Escoge una opcion: ");
		int option = reader.nextInt();
		reader.nextLine();
		
		System.out.print("Por favor ingrese su numero de documento: ");

		String numberDocument = reader.nextLine();

		persons.registerPerson(option, numberDocument);
					
	}


}
