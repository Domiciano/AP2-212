package model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import exceptions.NotAgeAllowedException;
import exceptions.NotDaySafeToEnterException;

public class DataPersons {

	private int attemptsReg;

	private static ArrayList<Persons> registerPersons;

	public DataPersons() {

		registerPersons = new ArrayList<>();
	}

	public ArrayList<Persons> getData() {

		return registerPersons;
	}

	public void registerPerson(int option, String numberDocument) {

		try {

			switch (option) {

			case 1:
				attemptsReg++;
				addPerson(DocumentType.TI, numberDocument);
				break;

			case 2:
				attemptsReg++;
				addPerson(DocumentType.CC, numberDocument);
				break;

			case 3:
				attemptsReg++;
				addPerson(DocumentType.PP, numberDocument);
				break;

			case 4:
				attemptsReg++;
				addPerson(DocumentType.CE, numberDocument);
				break;

			default:
				System.out.println("Opcion invalida");

			}

		} catch (NotDaySafeToEnterException e) {

			e.printStackTrace();

		} catch (NotAgeAllowedException e) {

			e.printStackTrace();

		}
	}

	public void addPerson(DocumentType document, String numberDocument)
			throws NotDaySafeToEnterException, NotAgeAllowedException {

		String aux = numberDocument;
		int penultimate = aux.charAt(aux.length() - 2);

		Date date = new Date();
		SimpleDateFormat format = new SimpleDateFormat("dd");
		String day = format.format(date);

		int day1 = Integer.parseInt(day);

		if (((penultimate % 2 != 0) && (day1 % 2 == 0)) || ((penultimate % 2 == 0) && (day1 % 2 != 0))
				|| ((penultimate % 2 == 0) && (day1 % 2 != 0)) || ((penultimate % 2 != 0) && (day1 % 2 == 0))) {

			throw new NotDaySafeToEnterException();
			
		} else if (document.equals(DocumentType.TI)) {

			throw new NotAgeAllowedException();

		} else {
			
			Persons p = new Persons(document, numberDocument);
			registerPersons.add(p);
		}

	}

	public int getAttemptsReg() {

		return attemptsReg;
	}
}
