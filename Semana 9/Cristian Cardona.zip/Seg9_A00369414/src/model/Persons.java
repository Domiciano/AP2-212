package model;

public class Persons {
	
	private DocumentType document;
	private String numberDocument;
	
	public Persons(DocumentType document, String numberDocument) {
		
		this.document = document;
		this.numberDocument = numberDocument;
	}

	public DocumentType getDocument() {
		return document;
	}

	public void setDocument(DocumentType document) {
		this.document = document;
	}

	public String getNumberDocument() {
		return numberDocument;
	}

	public void setNumberDocument(String numberDocument) {
		this.numberDocument = numberDocument;
	}
	
	
	
	

}
