package model;

public enum DocumentType {
	
	TI, CC, PP, CE;

}
