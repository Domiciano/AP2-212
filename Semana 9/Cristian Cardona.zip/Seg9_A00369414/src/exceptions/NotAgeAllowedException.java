package exceptions;

public class NotAgeAllowedException extends Exception {
	
	public NotAgeAllowedException() {
		
		System.out.println("No puede registrarse porque es menor de edad");
	}

}
