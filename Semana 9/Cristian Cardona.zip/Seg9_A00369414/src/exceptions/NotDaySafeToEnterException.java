package exceptions;

public class NotDaySafeToEnterException extends Exception {

	public NotDaySafeToEnterException() {
		
		System.out.println("No esta permitido que el usuario salga este dia");
	}
}
