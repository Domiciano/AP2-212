package model;

import exceptions.DayCannotEnterException;
import exceptions.TICannotEnterException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

public class PersonDataTest {

    @InjectMocks
    private PersonData personData;

    private Day day;

    @Before
    public void setUp() throws Exception {
        personData = new PersonData();
    }

    public void setUpStage1(){
        Person person = new Person("123456789", Person.TypeId.CC);
        personData.addPerson(person);
    }

    public void setUpStage2(){
        day = Mockito.mock(Day.class);
        when(day.getDay()).thenReturn(10);
    }

    public void setUpStage3(){
        day = Mockito.mock(Day.class);
        when(day.getDay()).thenReturn(27);
    }
    
    @Test
    public void add_a_person(){
        setUpStage1();
        assertEquals(new Person("123456789", Person.TypeId.CC), personData.getPeople().get(0));
    }

    @Test(expected = TICannotEnterException.class)
    public void when_a_person_cannot_enter_beacause_have_TI() throws TICannotEnterException, DayCannotEnterException {
        personData.verifyPerson("123456789", "ti");
    }

    @Test(expected = DayCannotEnterException.class)
    public void when_a_person_cannot_enter_beacause_his_id_and_the_day_are_pair() throws TICannotEnterException, DayCannotEnterException {
        setUpStage2();
        personData = new PersonData(day);
        personData.verifyPerson("123456789", "CC");
    }

    @Test(expected = DayCannotEnterException.class)
    public void when_a_person_cannot_enter_beacause_his_id_and_the_day_are_odd() throws TICannotEnterException, DayCannotEnterException {
        setUpStage3();
        personData = new PersonData(day);
        personData.verifyPerson("12345679", "CC");
    }

    @Test
    public void increase_the_number_of_people_try_enter() {
        try {
            personData.verifyPerson("123456789", "CE");
            personData.verifyPerson("123456789", "CC");
            personData.verifyPerson("123456789", "PP");
        } catch (TICannotEnterException e) {
            e.printStackTrace();
        } catch (DayCannotEnterException e) {
            e.printStackTrace();
        }

        assertEquals(3, personData.getNumOfPeopleTryEnter());
    }
}