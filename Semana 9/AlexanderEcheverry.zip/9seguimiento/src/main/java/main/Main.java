package main;

import exceptions.DayCannotEnterException;
import exceptions.TICannotEnterException;
import model.PersonData;

import java.util.Scanner;

public class Main {

    private Scanner sc;
    private PersonData personData;

    public Main() {
        sc = new Scanner(System.in);
        personData = new PersonData();
    }

    public static void main(String[] args) {
        Main principal = new Main();

        while(true){
            int option = principal.menu();
            principal.execute(option);
        }
    }

    private int menu(){
        System.out.println(" (Menu)  \n" +
                            "1. Agregar una persona\n" +
                            "2. Ver cuantas personas han intentado ingresar\n" +
                            "3. Salir");

        return Integer.parseInt(sc.nextLine());
    }

    private void execute(int option){
        switch(option){
            case 1:
                addPerson();
                break;
            case 2:
                showNumOfPeopleTryEnter();
                break;
            case 3:
                System.exit(0);
                break;
        }
    }

    private void addPerson(){
        try {
            String id, type;

            System.out.println("Enter id");
            id = sc.nextLine();

            System.out.println("Enter type");
            type = sc.nextLine();

            personData.verifyPerson(id, type);
        } catch (TICannotEnterException e) {
            System.out.println("The younger can't enter into marketplace");
        } catch (DayCannotEnterException e) {
            System.out.println("You can't enter in this day");
        }
    }

    private void showNumOfPeopleTryEnter(){
        System.out.println(personData.getNumOfPeopleTryEnter());
    }
}
