package model;

public interface Day {
    int getDay();
}
