package model;

import java.util.Objects;

public class Person{

    public enum TypeId{
        TI, CC, PP, CE
    }

    private String numId;
    private TypeId typeId;

    public Person(String numId, TypeId typeId) {
        this.numId = numId;
        this.typeId = typeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Person person = (Person) o;
        return Objects.equals(numId, person.numId) && typeId == person.typeId;
    }

    @Override
    public int hashCode() {
        return Objects.hash(numId, typeId);
    }
}
