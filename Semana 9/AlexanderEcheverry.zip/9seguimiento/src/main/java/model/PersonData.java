package model;

import exceptions.DayCannotEnterException;
import exceptions.TICannotEnterException;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class PersonData implements Day{

    private Day day;
    private ArrayList<Person> people;
    private int numOfPeopleTryEnter;

    public PersonData() {
        people = new ArrayList<Person>();
    }

    public PersonData(final Day day) {
        this.day = day;
    }

    public ArrayList<Person> getPeople() {
        return people;
    }

    public void addPerson(Person person){
        people.add(person);
    }

    public void verifyPerson(String id, String typeString) throws TICannotEnterException, DayCannotEnterException {
        numOfPeopleTryEnter++;
        char [] idChar = id.toCharArray();
        Person.TypeId type = Person.TypeId.valueOf(typeString.toUpperCase());
        int day;
        if(this.day == null) {
            day = getDay();
        } else {
            day = this.day.getDay();
        }
        if(type != Person.TypeId.TI){
            double RemainderId = idChar[id.length() - 2] % 2;
            if((RemainderId == 0 && day % 2 != 0) || (RemainderId != 0 && day % 2 == 0)){
                Person person = new Person(id, type);
                addPerson(person);
            } else {
                throw new DayCannotEnterException();
            }
        } else {
            throw new TICannotEnterException();
        }
    }

    public int getNumOfPeopleTryEnter() {
        return numOfPeopleTryEnter;
    }

    @Override
    public int getDay() {
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd");
        return Integer.parseInt(dateFormat.format(date));
    }
}
