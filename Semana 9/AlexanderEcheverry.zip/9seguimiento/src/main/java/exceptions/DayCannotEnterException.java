package exceptions;

public class DayCannotEnterException extends Exception{

    public DayCannotEnterException() {
    }
}
