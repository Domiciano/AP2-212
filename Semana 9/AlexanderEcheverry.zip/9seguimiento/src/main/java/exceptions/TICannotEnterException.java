package exceptions;

public class TICannotEnterException extends Exception{

    public TICannotEnterException() {
        super("The youngers can't enter in the marketplace");
    }

}
