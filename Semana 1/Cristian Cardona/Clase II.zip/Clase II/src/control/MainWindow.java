package control;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class MainWindow implements Initializable{

	@FXML Button n1,n2,n3,n4,n5,n6,n7,n8,n9;
	
	@FXML TextArea outputTA;
	
	@FXML Button nextBTN;
	
	private String pass = "";
	
	public static final String PASS = "123";


public Stage build() {
	try {
		Parent root = FXMLLoader.load(getClass().getResource("MainWindow.fxml"));
		Scene scene = new Scene(root,600,400);
		Stage stage = new Stage();
		stage.setScene(scene);
		return stage;
	}
	catch(IOException e) {
		e.printStackTrace();
		return null;
		
		}
	}

@FXML
public void nextWindow() {
	if(pass.equals(PASS)) {
		FormWindow form = new FormWindow();
		form.build().show();
	}else {
		outputTA.setText("Contrase�a incorrecta");
	}
	
}

@FXML
public void writeAlfa(ActionEvent event) {
	
	/*
	 * 
	 String beta = "14";
	 int betaInt = interger.parseInt beta;
	 
	 byte betaByte = (byte) betaInt;
	 Object betaObj = beta;//upcast
	 
	 Button betaAgainButton = (Button) beta;
	 */
	 
	
	Button b = (Button) event.getSource();
	
	pass += b.getText();
	
	outputTA.setText(pass);
			
	
	System.out.print(b.getText());
	
	/*
	if(event.getSource() == n1) {
		outputTA.setText("1");
		
	}
	else if(event.getSource() == n2) {
		outputTA.setText("2");
	}
	*/
}

@Override
public void initialize(URL location, ResourceBundle resources) {
	// TODO Auto-generated method stub
	pass = "";
}

	
	
}

