package control;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class MainWindow implements Initializable {

		@FXML Button n1, n2, n3, n4, n5, n6, n7 ,n8, n9;
		@FXML TextArea output;
		@FXML Button nextBtn; 
		private String pass;
		public static final String PASS = "1BF";
		
		
		public Stage build() {
			// TODO Auto-generated method stub
			try {
				Parent root = FXMLLoader.load(getClass().getResource("MainWindow.fxml"));
				Scene scene = new Scene(root, 600, 400 );
				Stage stage= new Stage();
				stage.setScene(scene);
				return stage;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return null;
			}
		}
	@FXML	
	public void nextWindow() {
		if(pass.equals(PASS)) {
		SecondWindow second = new SecondWindow();
		second.build().show();
		}else {
			output.setText("Contrase�a incorrecta");
		}
	}
	

    @FXML
    public void writeAlfa(ActionEvent event) {
    	
    Button b = (Button) event.getSource();
    pass += b.getText();
    output.setText(pass);
    }
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		pass= "";
	}
}
