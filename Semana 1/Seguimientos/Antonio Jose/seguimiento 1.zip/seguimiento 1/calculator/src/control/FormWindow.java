package control;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class FormWindow {
	
	 	@FXML
	    private Button n1, n2, n3, n4, n5, n6, n7, n8, n9, n0, equal, divide, multiply, substract, add, clear;
	    @FXML
	    private TextArea textField;
	    
	public Stage build() {
		
		try {
			
			Parent root = FXMLLoader.load(getClass().getResource("FormWindow.fxml"));
			Scene scene = new Scene(root, 720, 480);
			Stage stage = new Stage();
			stage.setScene(scene);
			return stage;
			
		} catch (IOException e) {
			
			e.printStackTrace();
			return null;
			
		}

	}
	@FXML
	public void numPress(ActionEvent event) {
		double numero1=0;
		double numero2=0;
		int operation=0;
		double resultado=0;
		
			if(event.getSource() == n1){
				textField.setText(textField.getText()+"1");
			}
			if(event.getSource() == n2){
				textField.setText(textField.getText()+"2");
			}
			if(event.getSource() == n3){
				textField.setText(textField.getText()+"3");
			}
			if(event.getSource() == n4){
				textField.setText(textField.getText()+"4");
			}
			if(event.getSource() == n5){
				textField.setText(textField.getText()+"5");
			}
			if(event.getSource() == n6){
				textField.setText(textField.getText()+"6");
			}
			if(event.getSource() == n7){
				textField.setText(textField.getText()+"7");
			}
			if(event.getSource() == n8){
				textField.setText(textField.getText()+"8");
			}
			if(event.getSource() == n9){
				textField.setText(textField.getText()+"9");
			}
			if(event.getSource() == n0){
				textField.setText(textField.getText()+"0");
			}
			
			
			if(event.getSource() == add){
				
				textField.setText(textField.getText()+"+");
				
			}
			if(event.getSource() == substract){
				
				textField.setText(textField.getText()+"-");
				
			}
			if(event.getSource() == divide){
				
				textField.setText(textField.getText()+"/");
		
			}
			if(event.getSource() == multiply){

				textField.setText(textField.getText()+"*");

			}
			
			
			if(event.getSource() == equal){
				
				if (textField.getText().contains("+")) {
					String[] arrOfStr = textField.getText().split("\\+", 2);
					
					numero1= Double.parseDouble(arrOfStr[0]);
					numero2= Double.parseDouble(arrOfStr[1]);
					
					operation=1;
					
					 for (String a : arrOfStr)
				            System.out.println(a);
				} else if (textField.getText().contains("-")) {
					String[] arrOfStr = textField.getText().split("\\-", 2);
					
					numero1= Double.parseDouble(arrOfStr[0]);
					numero2= Double.parseDouble(arrOfStr[1]);
					
					operation=2;
					
					 for (String a : arrOfStr)
				            System.out.println(a);
				} else if (textField.getText().contains("/")) {
					String[] arrOfStr = textField.getText().split("\\/", 2);
					
					numero1= Double.parseDouble(arrOfStr[0]);
					numero2= Double.parseDouble(arrOfStr[1]);
					
					operation=3;
					
					 for (String a : arrOfStr)
				            System.out.println(a);
				}else if (textField.getText().contains("*")) {
					String[] arrOfStr = textField.getText().split("\\*", 2);
					
					numero1= Double.parseDouble(arrOfStr[0]);
					numero2= Double.parseDouble(arrOfStr[1]);
					
					operation=4;
					
					 for (String a : arrOfStr)
				            System.out.println(a);
				}else {
			        throw new IllegalArgumentException("String " + textField.getText() + " does not contain symbols");
			    }
				
				System.out.println("numero 1 " + numero1);
				System.out.println("numero 2 " + numero2);
				
				switch(operation) {
				
		        	case 0:
		        		textField.setText("por favor escoja una operacion");
		        		break;
		        
		        	case 1:
		        		resultado=numero1 + numero2;
		        		break;
		        
		        	case 2:
		        		resultado=numero1 - numero2;
		        		break;
		            
		        	case 3:
		        		resultado=numero1 / numero2;
		        		break;
		            
		        	case 4:
		        		resultado=numero1 * numero2;
		        		break;
				}
				
				
				textField.setText("=" + resultado);
				
			}
			
			
			if(event.getSource() == clear){
				textField.setText("");
			}
	}
	
	

}
