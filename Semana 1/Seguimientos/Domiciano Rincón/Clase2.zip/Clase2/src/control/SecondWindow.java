package control;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SecondWindow {
	
	public Stage build() {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("SecondWindow.fxml"));
			Scene scene = new Scene(root, 600, 400);
			Stage stage = new Stage();
			stage.setScene(scene);
			return stage;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}	
	
	@FXML
	public void backWindow() {
		
	}
	
	
	
	
	
	
	
	

}
