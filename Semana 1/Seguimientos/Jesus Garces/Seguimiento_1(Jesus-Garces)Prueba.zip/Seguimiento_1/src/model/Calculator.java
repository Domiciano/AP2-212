package model;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Calculator {
	
	@FXML
	TextField primerNumero,segundoNumero;
	
	@FXML
	Label resultado;

	public Stage build() {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("Calculator.fxml"));
			Scene scene = new Scene(root, 600, 400);
			Stage stage = new Stage();
			stage.setScene(scene);
			return stage;

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public void multiplicar() {
		int a = primerNumero.;
	}
	
	public void multiplicar() {
		
	}
}
