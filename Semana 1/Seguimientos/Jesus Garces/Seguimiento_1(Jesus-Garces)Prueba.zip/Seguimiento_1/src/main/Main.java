package main;

import javafx.application.Application;
import javafx.stage.Stage;

import model.Calculator;

public class Main extends Application {

	public static void main(String[] args) {

		// Usar las ventanas
		launch(args);  // do initially  start method
	}

	@Override
	public void start(Stage arg0) throws Exception {
		Calculator operation = new Calculator();
		operation.build().show();
	}
}