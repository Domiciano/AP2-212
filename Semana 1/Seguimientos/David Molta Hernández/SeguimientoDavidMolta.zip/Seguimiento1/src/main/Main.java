package main;

import Control.Calculator;
import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {


	public static void main(String[] args) {
		
		//Paso 1
		launch(args);

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		Calculator calc = new Calculator();
		calc.build().show();
		
	}
	

	
}
