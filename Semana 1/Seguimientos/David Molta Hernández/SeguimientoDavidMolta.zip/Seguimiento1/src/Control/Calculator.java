package Control;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;

import javafx.stage.Stage;

public class Calculator {

	int tryy;
	private String nmbrAA = "";
	private String nmbrBB= "";

	// References

	@FXML
	Label nmbrA;
	@FXML
	Label nmbrB;
	@FXML
	Label operationtype;
	@FXML
	Label addition;
	@FXML
	Label substraction;
	@FXML
	Label multiplication;
	@FXML
	Label division;
	@FXML
	Label answer;
	@FXML
	Label sign;

	public Stage build() {
		tryy = 0;

		Parent root;
		try {
			root = FXMLLoader.load(getClass().getResource("Calculator.fxml"));
			Scene scene = new Scene(root, 600, 400);
			Stage stage = new Stage();
			stage.setScene(scene);
			return stage;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}

	}

	public void image00() {

	}

	public void image01() {

	}

	public void image02() {

	}

	public void image03() {

	}

	public void image04() {

	}

	public void image05() {

	}

	public void image06() {

	}

	public void image07() {

	}

	public void image08() {

	}

	public void image09() {

	}

	public void multiplication() {

	}

	public void substraction() {

	}

	public void addition() {

	}

	public void division() {

	}

	public void clear() {

	}
	
	public void equals0() {
		
	}

	public void cleareance() {

		tryy = 0;
		nmbrA.setText("-");
		nmbrB.setText("-");
		sign.setText("-");
		answer.setText("-");
		nmbrAA="";
		nmbrBB="";

	}

	@FXML
	public void clickzero() {

		if (tryy == 0) {
			nmbrAA += "0";
			nmbrA.setText(nmbrAA);
		} else if (tryy == 1) {
			nmbrBB += "0";
			nmbrB.setText(nmbrBB);
		}

	}

	@FXML
	public void clickone() {

		if (tryy == 0) {
			nmbrAA += "1";
			nmbrA.setText(nmbrAA);
		} else if (tryy == 1) {
			nmbrBB += "1";
			nmbrB.setText(nmbrBB);
		}
	}

	@FXML
	public void clicktwo() {

		if (tryy == 0) {
			nmbrAA += "2";
			nmbrA.setText(nmbrAA);
		} else if (tryy == 1) {
			nmbrBB += "2";
			nmbrB.setText(nmbrBB);
		}
	}

	@FXML
	public void clickthree() {

		if (tryy == 0) {
			nmbrAA += "3";
			nmbrA.setText(nmbrAA);
		} else if (tryy == 1) {
			nmbrBB += "3";
			nmbrB.setText(nmbrBB);
		}
	}

	@FXML
	public void clickfour() {

		if (tryy == 0) {
			nmbrAA += "4";
			nmbrA.setText(nmbrAA);
		} else if (tryy == 1) {
			nmbrBB += "4";
			nmbrB.setText(nmbrBB);
		}
	}

	@FXML
	public void clickfive() {

		if (tryy == 0) {
			nmbrAA += "5";
			nmbrA.setText(nmbrAA);
		} else if (tryy == 1) {
			nmbrBB += "5";
			nmbrB.setText(nmbrBB);
		}
	}

	@FXML
	public void clicksix() {

		if (tryy == 0) {
			nmbrAA += "6";
			nmbrA.setText(nmbrAA);
		} else if (tryy == 1) {
			nmbrBB += "6";
			nmbrB.setText(nmbrBB);
		}

	}

	@FXML
	public void clickseven() {

		if (tryy == 0) {
			nmbrAA += "7";
			nmbrA.setText(nmbrAA);
		} else if (tryy == 1) {
			nmbrBB += "7";
			nmbrB.setText(nmbrBB);
		}

	}

	@FXML
	public void clickeight() {

		if (tryy == 0) {
			nmbrAA += "8";
			nmbrA.setText(nmbrAA);
		} else if (tryy == 1) {
			nmbrBB += "8";
			nmbrB.setText(nmbrBB);
		}
	}

	@FXML
	public void clicknine() {
		
		if (tryy == 0) {
			nmbrAA += "9";
			nmbrA.setText(nmbrAA);
		} else if (tryy == 1) {
			nmbrBB += "9";
			nmbrB.setText(nmbrBB);
		}

	}

	public void mult() {
		tryy=1;
		sign.setText("X");

	}

	public void subs() {
		tryy=1;

		sign.setText("-");

	}

	public void div() {
		tryy=1;

		sign.setText("/");

	}

	public void add() {
		tryy=1;

		sign.setText("+");

	}

	public void equals() {
		
		if(sign.getText().equals("X")) {
			String numberA = nmbrA.getText();
			String numberB = nmbrB.getText();
			int A = Integer.parseInt(numberA);
			int B = Integer.parseInt(numberB);
			double result = A * B;
			String ans = "" + result;
			answer.setText(ans);
		}else if(sign.getText().equals("/")) {
			String numberA = nmbrA.getText();
			String numberB = nmbrB.getText();
			String ans = "";
			int A = Integer.parseInt(numberA);
			int B = Integer.parseInt(numberB);

			if (B != 0) {
				double result = (double) A / B;
				ans = "" + result;
			} else
				ans = "Cannot divide by 0";

			answer.setText(ans);
		}else if(sign.getText().equals("-")) {
			String numberA = nmbrA.getText();
			String numberB = nmbrB.getText();
			int A = Integer.parseInt(numberA);
			int B = Integer.parseInt(numberB);
			double result = A - B;
			String ans = "" + result;
			answer.setText(ans);
		}else if(sign.getText().equals("+")) {
			String numberA = nmbrA.getText();
			String numberB = nmbrB.getText();
			int A = Integer.parseInt(numberA);
			int B = Integer.parseInt(numberB);
			double result = A + B;
			String ans = "" + result;
			answer.setText(ans);
		}
		
		
		
		
		
	}
	
	
	
	
}
