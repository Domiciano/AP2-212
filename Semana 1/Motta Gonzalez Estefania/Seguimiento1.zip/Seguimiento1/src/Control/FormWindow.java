package Control;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FormWindow {
	
	@FXML
    TextField num1TF;
	@FXML
    TextField num2TF;
	@FXML
	Label output1;
	@FXML
	Label output2;
	
	public Stage build() {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("FormWindow.fxml"));
			Scene scene = new Scene(root,600,400);
			Stage stage = new Stage();
			stage.setScene(scene);
			return stage;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	public void multiplicar(){
		String numA = num1TF.getText();
		String numB = num2TF.getText();
		
		double a = Double.parseDouble(numA);
		double b = Double.parseDouble(numB);
		
		double multiplicar;
		multiplicar = a*b;
		
		output1.setText(multiplicar+"");
	}
	public void dividir(){
		String numA = num1TF.getText();
		String numB = num2TF.getText();
		double a = Double.parseDouble(numA);
		double b = Double.parseDouble(numB);
		double dividir;
		if(b==0) {
			output2.setText("Error...");
		}else {
			dividir = a/b;
			output2.setText(dividir+"");
		}
	}		
}
