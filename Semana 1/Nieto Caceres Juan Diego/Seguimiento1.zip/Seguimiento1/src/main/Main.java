package main;

import control.MainWindow;
import javafx.application.Application;
import javafx.stage.Stage;

public class Main extends Application {

	public static void main(String[] args) {
		launch(args);

	}
	
	@Override
	public void start(Stage args) throws Exception {
		MainWindow window = new MainWindow();
		window.build().show();
	}
		
}
