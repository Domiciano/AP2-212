package control;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MainWindow {
	
	 @FXML
	 TextField num1TF;

	 @FXML
	 Label multipResultL;

	 @FXML
	 Label divisionResultL;

	 @FXML
	 TextField num2TF;

	/**
	 * The class build its created to set the Stage an scene
	 * 
	 * @return stage or null
	 */
	public Stage build() {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("MainWindow.fxml"));
			Scene scene= new Scene(root, 600, 400);
			Stage stage = new Stage();
			stage.setScene(scene);
			return stage;
			
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 
	 * @throws Exception
	 */
	@FXML
    public void multiplication() throws Exception{
    	String num1 = num1TF.getText();
		String num2 = num2TF.getText();
		
		int A = Integer.parseInt(num1);  
		int B = Integer.parseInt(num2);
		int mult = (A * B);
		String resultMult = ("" + mult);
		multipResultL.setText(resultMult);
    }
	
	/**
	 * 
	 * @throws Exception
	 */
	@FXML
    public void division() throws Exception {
		String num1 = num1TF.getText();
		String num2 = num2TF.getText();
		
		double A = Integer.parseInt(num1);  
		double B = Integer.parseInt(num2);
		String resultDiv;
		if (B != 0) {
			double div = (A / B);
			resultDiv = ("" + div);
		} else {
			resultDiv = "Indeterminado";
		}
		
		divisionResultL.setText(resultDiv);
    }  

	@FXML
	public void sum() throws Exception {
		String num1 = num1TF.getText();
		String num2 = num2TF.getText();
		
		int A = Integer.parseInt(num1);  
		int B = Integer.parseInt(num2);
		int sum = (A + B);
		String resultSum = ("" + sum);
		multipResultL.setText(resultSum);
	}
	
	@FXML
	public void subtraction() throws Exception {
		String num1 = num1TF.getText();
		String num2 = num2TF.getText();
		
		int A = Integer.parseInt(num1);  
		int B = Integer.parseInt(num2);
		int subs = (A - B);
		String resultSubs = ("" + subs);
		divisionResultL.setText(resultSubs);
		
	}
}
