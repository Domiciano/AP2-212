package exception;

public class ProgramadorRepetidoException extends RuntimeException {

	public ProgramadorRepetidoException(String name) {
		super("El nombre "+ name+ " est� repetido");
	}

}
