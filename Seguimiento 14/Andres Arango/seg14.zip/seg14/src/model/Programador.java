package model;

import exception.ProgramadorRepetidoException;

public class Programador {
	//key
	private String nombre;
	
	//Value
	private String telefono;
	private String direccion;
	private String eMail;
	
	private Programador derecha;
	private Programador izquierda;
	
	
	public Programador(String nombre, String telefono, String direccion, String eMail) {
		
		this.nombre = nombre;
		this.telefono = telefono;
		this.direccion = direccion;
		this.eMail = eMail;
	}


	public Programador() {
		// TODO Auto-generated constructor stub
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getTelefono() {
		return telefono;
	}


	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}


	public String getDireccion() {
		return direccion;
	}


	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}


	public String geteMail() {
		return eMail;
	}


	public void seteMail(String eMail) {
		this.eMail = eMail;
	}
	
	public void insert(String name, String telefono, String direccion, String eMail) {
		// TODO Auto-generated method stub
		if(name.compareTo(this.nombre)<0) {
			if(this.izquierda==null) {
				this.izquierda= new Programador(name, telefono, direccion, eMail);
			
			}else {
				this.izquierda.insert(name, telefono, direccion, eMail);
			}
		}else if(name.compareTo(this.nombre)>0) {
			if(this.derecha==null) {
				this.derecha= new Programador(name, telefono, direccion, eMail);
				
				
			}else {
				this.derecha.insert(name,telefono,direccion, eMail);
			}
		}else {
			throw new ProgramadorRepetidoException(name);
		}
	}
	
	
	
	


	public Programador getDerecha() {
		return derecha;
	}


	public void setDerecha(Programador derecha) {
		this.derecha = derecha;
	}


	public Programador getIzquierda() {
		return izquierda;
	}


	public void setIzquierda(Programador izquierda) {
		this.izquierda = izquierda;
	}
	
	
	
	
}
