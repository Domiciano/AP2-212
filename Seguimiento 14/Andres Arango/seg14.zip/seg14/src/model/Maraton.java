package model;

public class Maraton {

	private int numProgramadores;
	
	private Programador programadorRaiz;
	
	public Maraton() {
		
	}
	
	public void agregarProgramador(String nombre, String telefono, String direccion, String email) {
		if(programadorRaiz==null) {
			programadorRaiz= new Programador(nombre, telefono, direccion, email);
			numProgramadores++;
		}else {
			programadorRaiz.insert(nombre, telefono, direccion, email);
			numProgramadores++;
		}
	}
	
	public void triggerInorder() {
		inOrder(programadorRaiz);
	}
	
	
	public void inOrder(Programador node) {
		
		//Caso base
		if(node==null) {
			return;
		}
		
		//Recusrcion
		inOrder(node.getIzquierda());
		System.out.println(node.getNombre());
		inOrder(node.getDerecha());
		
	}
	
	public Programador searchTrigger(String name) {
		return search(programadorRaiz, name );
	}
	
	public Programador search(Programador node,String name) {
		
		if(node==null) {
			return null;
		}
		if(name.equals(node.getNombre())) {
			return node;
			
		}
		
		
		if(name.compareTo(node.getNombre())<0) {
			return search(node.getIzquierda(), name);
		}else {
			return search(node.getDerecha(), name);
		}
	}
	
	public void triggerMaxLevel() {
		int level = getMaxLevel(programadorRaiz, 1);
		System.out.println(level);
	}

	private int getMaxLevel(Programador programadorRaiz2, int i) {
		// TODO Auto-generated method stub
		if (programadorRaiz2 == null) {
			return i-1;
		} else {

			int A = getMaxLevel(programadorRaiz2.getDerecha(), i + 1);
			int B = getMaxLevel(programadorRaiz2.getIzquierda(),i + 1);

			return Math.max(A, B);
		}

	}
	
	public void triggerDelete(String name) {
		if (programadorRaiz != null){
			programadorRaiz = delete(programadorRaiz, name);
		}
	}
	
		public Programador delete(Programador current, String name){
		
		if (current.getNombre().equals(name)){
			if (current.getIzquierda() == null && 
					current.getDerecha() == null){
				return null;
			} else if (current.getIzquierda() != null && 
					current.getDerecha() != null) {
				Programador succesor = getMin(current.getDerecha());
				Programador newRightTree = delete(current.getDerecha(), succesor.getNombre());
				
				succesor.setIzquierda(current.getIzquierda());
				succesor.setDerecha(newRightTree);

				return succesor;
			} else if (current.getIzquierda() != null) {
				return current.getIzquierda();
			} else {
				return current.getDerecha();
			}
			
		} else if (name.compareTo(current.getNombre())<0){
			Programador newLeftTree = delete(current.getIzquierda(), name);
			current.setIzquierda(newLeftTree);
		} else {
			Programador newRightTree = delete(current.getDerecha(), name);
			current.setDerecha(newRightTree);
		}
		
		return current;
	}
		
		public Programador getMin(Programador current){
			if (current.getIzquierda() == null) {
				return current;
			} else {
				return getMin(current.getIzquierda());
			}
		}
		
		public Programador getMax(Programador current) {
			if (current.getDerecha() == null) {
				return current;
			}else {
				return getMax(current.getDerecha());
			}
		}

		public int getNumProgramadores() {
			return numProgramadores;
		}

		public void setNumProgramadores(int numProgramadores) {
			this.numProgramadores = numProgramadores;
		}
	
}
