package main;

import java.util.Scanner;

import model.Maraton;
import model.Programador;



public class Main {

	private static Scanner scanner;
	private static Maraton maraton;
	private static Programador programador;
	private static Main main;
	
	public Main() {
		maraton= new Maraton();
		scanner=new Scanner(System.in);
		programador = new Programador();
	}
	public static void main(String[] args) {
		setMain(new Main());
		Main.menu();
	}
		
		
		
		
		private static void menu() {
		// TODO Auto-generated method stub
			System.out.println("Maratones\n"+
					"(1) agregar\n"+
					"(2) buscar\n"+
					"(3) Eliminar\n"+
					"(4) Listar\n"+
					"(5) Obtener profundidad\n"+
					"(6) Obtener n�mero de programadores\n"+
					"(0) Salir");
			String line= scanner.nextLine();
			int option= Integer.parseInt(line);
			
			switch(option) {
			case 1:
				agregarProgramador();
			break;
			case 3:
				eliminarProgramador();
			break;
			case 2:
			    buscarProgramador();
			break;
			case 4:
				listarProgramador();
			break;
			case 5:
				maraton.triggerMaxLevel();
				menu();
			break;
			case 0:
				System.exit(0);
			break;
			case 6:
				numeroProgramadores();
			break;	
						
			}
	}

		
	

	private static void numeroProgramadores() {
			// TODO Auto-generated method stub
			System.out.println("El n�mero de programadores registrados es igual a "+ maraton.getNumProgramadores());
			menu();
		}
	private static void listarProgramador() {
		// TODO Auto-generated method stub
		maraton.triggerInorder();
		menu();
	}

	private static void buscarProgramador() {
		// TODO Auto-generated method stub
		System.out.println("Digita el nombre del programador");
		String name= scanner.nextLine();
		scanner.nextLine();
		programador = maraton.searchTrigger(name);
		if(programador==null) {
			System.out.println("El programador no existe");
		}else {
			System.out.println(programador.getNombre());
			System.out.println(programador.getTelefono());
			System.out.println(programador.getDireccion());
			System.out.println(programador.geteMail());
		}
		menu();
	}

	private static void eliminarProgramador() {
		// TODO Auto-generated method stub
		System.out.println("Digite el nombre");
		String name= scanner.nextLine();
		maraton.triggerDelete(name);
		System.out.println("Ha sido eliminado");
		menu();
	}

	private static void agregarProgramador() {
		// TODO Auto-generated method stub
		System.out.println("Digita el nombre");
		String nombre= scanner.nextLine();
		
		System.out.println("Digita el telefono");
		String telefono= scanner.nextLine();
		
		System.out.println("Digita la direccion ");
		String direccion= scanner.nextLine();
		
		System.out.println("Digita el email");
		String email= scanner.nextLine();
		
		maraton.agregarProgramador(nombre, telefono, direccion, email);
		menu();
		
	}
	public static Main getMain() {
		return main;
	}
	public static void setMain(Main main) {
		Main.main = main;
	}

}
