package ui;

import java.util.Scanner;
import model.Tree;

public class Main {
	
	private Tree mainTree;

	public static Scanner lector;
	
	public Main() {
		mainTree = new Tree();
	}

	public static void main(String[] args) {
		lector = new Scanner(System.in);

		Main objMain=new Main();
		boolean menu=true;
		int opcions = 0;
		while(menu){
			System.out.println("1.- Agregar.");
			System.out.println("2.- Eliminar.");
			System.out.println("3.- Buscar.");
			System.out.println("4.- Listar.");
			System.out.println("5.- Exit");

			System.out.println("Enter the action to perform: ");
			opcions=Integer.parseInt(lector.nextLine());
			switch(opcions){
			case 1:
				objMain.add();
				break;
			case 2:
				objMain.delete();
				break;
			case 3:
				objMain.search();
				break;
			case 4:
				objMain.show();
				break;
			case 5:
				menu=false;
				break;
			default:
				System.out.println("Only numbers between 1 and 5.");
				break;
			}
		}

	}
	public void add() {
		System.out.println("Ingrese el nombre.");
		String name = lector.nextLine();
		System.out.println("Ingrese el telefono.");
		String phone = lector.nextLine();
		System.out.println("Ingrese la direccion.");
		String address = lector.nextLine();
		System.out.println("Ingrese el correo.");
		String email = lector.nextLine();
		mainTree.addNode(name, phone, address, email);
	}
	public void delete() {
		System.out.println("Ingrese el nombre a eliminar.");
		String name = lector.nextLine();
		mainTree.triggerDelete(name);
	}
	public void search() {
		System.out.println("Ingrese el nombre.");
		String name = lector.nextLine();
		System.out.println(mainTree.triggerSearchToString(name));
		
	}
	public void show() {
		mainTree.triggerInOrder();
	}
}