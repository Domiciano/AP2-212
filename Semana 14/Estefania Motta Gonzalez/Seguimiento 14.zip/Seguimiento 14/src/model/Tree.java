package model;

public class Tree {
	
	private Node root;

	public void inOrder(Node node) {
		// Caso base
		if (node == null) {
			return;
		}
		// Recursivo
		inOrder(node.getLeft());
		System.out.println(node.getName());
		inOrder(node.getRight());
	}
	public void triggerInOrder() {
		inOrder(root);
	}
	private Node triggerSearch(String name) {
		 return search(root, name);
	}
	public String triggerSearchToString(String name){
		   return triggerSearch(name).getName();
	}	   
	public Node search(Node node, String name) {
		 if(node==null) {
			 return null;
		 }
		 if(name.compareTo(node.getName()) ==0) {
			 //System.out.println(node.getName());
			 return node;
		 }

		 if(name.compareTo(node.getName()) < 0) {
			 return search(node.getLeft(),name);
		 }else {
			 return search(node.getRight(),name);
		 }
	 }
	public void addNode(String name, String phone, String address, String email) {
		if(root==null) {
			root = new Node(name, phone, address, email);
		}else {
			root.insert(name, phone, address, email);	
		}
	}
	public Node getMin(Node current) {
		 if(current.getLeft()==null) {
			 return current;
		 }else {
			 return getMin(current.getLeft());
		 }
	 }
	public Node triggerDelete(String name) {
		return delete(root, name);
	}
	public Node delete(Node current, String name) {
		 if(name.compareTo(current.getName())==0) {
			 if(current.getLeft()==null&&
					 current.getRight()==null) {
				 return null;
			 }else if(current.getLeft()!=null&&
					 current.getRight()!=null) {
				 Node succesor = getMin(current.getRight());
				 Node newRightTree = delete(current.getRight(), succesor.getName());
				 succesor.setLeft(current.getLeft());
				 succesor.setRight(newRightTree);
			 }else if(current.getLeft()!=null) {
				 return current.getLeft();
			 }else {
				 return current.getRight();
			 }
		 }else if (name.compareTo(current.getName()) < 0){
			Node newLeftTree = delete(current.getLeft(),name);
			current.setLeft(newLeftTree);
		 }else {
			 Node newRightTree = delete(current.getRight(), name);
			 current.setRight(newRightTree);
		 }
		 
		 return null;
	 }
}
