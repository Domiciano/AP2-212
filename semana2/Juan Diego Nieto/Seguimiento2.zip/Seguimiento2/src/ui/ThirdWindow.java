package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import model.Password;

public class ThirdWindow extends Stage {
	
	private TextArea actualPasswordTA1, actualPasswordTA2, actualPasswordTA3, actualPasswordTA4,
	actualPasswordTA5, actualPasswordTA6, nextPasswordTA1, nextPasswordTA2, nextPasswordTA3,
	nextPasswordTA4, nextPasswordTA5, nextPasswordTA6;
	private Button changePassBtn;
	private Button closeBoxBtn;
	private Label passMess;
	private String actualPass;
	private String newPass;
	public boolean passChanged;
	
	public ThirdWindow() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SecondWindow.fxml"));
			Parent root = loader.load();
			actualPasswordTA1 = (TextArea) loader.getNamespace().get("actualPasswordTA1");
			actualPasswordTA2 = (TextArea) loader.getNamespace().get("actualPasswordTA2");
			actualPasswordTA3 = (TextArea) loader.getNamespace().get("actualPasswordTA3");
			actualPasswordTA4 = (TextArea) loader.getNamespace().get("actualPasswordTA4");
			actualPasswordTA5 = (TextArea) loader.getNamespace().get("actualPasswordTA5");
			actualPasswordTA6 = (TextArea) loader.getNamespace().get("actualPasswordTA6");
			nextPasswordTA1 = (TextArea) loader.getNamespace().get("nextPasswordTA1");
			nextPasswordTA2 = (TextArea) loader.getNamespace().get("nextPasswordTA2");
			nextPasswordTA3 = (TextArea) loader.getNamespace().get("nextPasswordTA3");
			nextPasswordTA4 = (TextArea) loader.getNamespace().get("nextPasswordTA4");
			nextPasswordTA5 = (TextArea) loader.getNamespace().get("nextPasswordTA5");
			nextPasswordTA6 = (TextArea) loader.getNamespace().get("nextPasswordTA6");
			changePassBtn = (Button) loader.getNamespace().get("changePassBtn");
			closeBoxBtn = (Button) loader.getNamespace().get("closeBoxBtn");
			passMess = (Label) loader.getNamespace().get("passMess");
			changePassword();
			closeBox();
			
			Scene scene = new Scene(root, 600, 400);
			setScene(scene);
			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void changePassword() {
		changePassBtn.setOnAction(event-> {
			Password password = new Password();
			actualPass = actualPasswordTA1.getText() + actualPasswordTA2.getText() + actualPasswordTA3.getText()
			+ actualPasswordTA4.getText() + actualPasswordTA5.getText() + actualPasswordTA6.getText();
			newPass = nextPasswordTA1.getText() + nextPasswordTA2.getText() + nextPasswordTA3.getText()
			+ nextPasswordTA4.getText() + nextPasswordTA5.getText() + nextPasswordTA6.getText();
			
			if(password.password != null) {
				if(actualPass.equals(password.password)) {
					password.passwordHasChanged = true;
					password.password = newPass;
					passMess.setText("Contrase�a cambiada");
				} else {
					passMess.setText("La contrase�a no se ha podido cambiar");
				}
			} else {
				if(actualPass.equals(password.DEFAULT_PASSWORD)) {
					password.passwordHasChanged = true;
					password.password = newPass;
					passMess.setText("Contrase�a cambiada");
				} else {
					passMess.setText("La contrase�a no se ha podido cambiar");
				}
			}		
		});
	}
	
	public void closeBox() {
		closeBoxBtn.setOnAction(event-> {
			MainWindow main = new MainWindow();
			main.show();
		});
	}
}
