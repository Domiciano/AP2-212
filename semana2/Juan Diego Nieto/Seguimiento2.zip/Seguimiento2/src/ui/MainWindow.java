package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import model.Password;

public class MainWindow extends Stage {
	
	private TextArea passwordTA1, passwordTA2, passwordTA3, passwordTA4, passwordTA5, passwordTA6;
	private Button openBoxBtn;
	private String pass;
	private boolean passChanged;
	private Label passMess;
	
	public MainWindow() {	
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("MainWindow.fxml"));
			Parent root = loader.load();
			passwordTA1 = (TextArea) loader.getNamespace().get("passwordTA1");
			passwordTA2 = (TextArea) loader.getNamespace().get("passwordTA2");
			passwordTA3 = (TextArea) loader.getNamespace().get("passwordTA3");
			passwordTA4 = (TextArea) loader.getNamespace().get("passwordTA4");
			passwordTA5 = (TextArea) loader.getNamespace().get("passwordTA5");
			passwordTA6 = (TextArea) loader.getNamespace().get("passwordTA6");
			openBoxBtn = (Button) loader.getNamespace().get("openBoxBtn");
			passMess = (Label) loader.getNamespace().get("passMess");
			
			Scene scene = new Scene(root, 600, 400);
			setScene(scene);
			intialice();
			openBox();
			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
	public void intialice() throws Exception {
		Password password = new Password();
		passChanged = password.passwordHasChanged;
		
	}

	public void openBox() {	
		openBoxBtn.setOnAction(event-> {
			SecondWindow second = new SecondWindow();
			Password password = new Password();
			pass = passwordTA1.getText() + passwordTA2.getText() + passwordTA3.getText()
			+ passwordTA4.getText() + passwordTA5.getText() + passwordTA6.getText();
			System.out.println(pass);
			
			if(passChanged == true) {
				if(pass.equals(password.password)) {
					second.show();
				} else {
					passMess.setText("Contrase�a equivocada");
				}
			} else {
				if(pass.equals(password.DEFAULT_PASSWORD)) {
					second.show();
				} else {
					passMess.setText("Contrase�a equivocada");
				}
			}
		});
	}
	
	
}
