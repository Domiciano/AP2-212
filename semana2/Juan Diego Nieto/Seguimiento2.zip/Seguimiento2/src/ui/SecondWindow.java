package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import model.Password;

public class SecondWindow extends Stage {
	
	private TextArea contentTA;
	private Button changePassBtn;
	private Button closeBoxBtn;
	
	public SecondWindow() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("SecondWindow.fxml"));
			Parent root = loader.load();
			contentTA = (TextArea) loader.getNamespace().get("contextTA");
			changePassBtn = (Button) loader.getNamespace().get("changePassBtn");
			closeBoxBtn = (Button) loader.getNamespace().get("closeBoxBtn");
			
			Scene scene = new Scene(root, 600, 400);
			setScene(scene);
			init();	
			changePass();
			closeBox();
			
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void init() {
		Password password = new Password();
		if(password.saved == true) {
			contentTA.setText(password.savedTA);
		} else {
			password.savedTA = "";
			contentTA.setText(password.savedTA);
		}
	}
	public void changePass() {
		changePassBtn.setOnAction(event-> {	
			ThirdWindow third = new ThirdWindow();
			third.show();
		});
	}
	
	public void closeBox() {
		closeBoxBtn.setOnAction(event-> {
			Password password = new Password();
			password.saved = true;
			password.savedTA = contentTA.getText();
			MainWindow main = new MainWindow();
			main.show();
		});
	}

}
