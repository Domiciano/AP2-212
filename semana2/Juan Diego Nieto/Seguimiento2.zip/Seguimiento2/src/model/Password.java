package model;

public class Password {
	public static String password;
	public static boolean passwordHasChanged = false;
	public static final String DEFAULT_PASSWORD = "000000";
	public static String savedTA;
	public static boolean saved;
}
