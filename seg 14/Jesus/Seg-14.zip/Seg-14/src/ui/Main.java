package ui;

import java.util.Scanner;

import model.Node;
import model.ProgramadorRepetidoException;
import model.Tree;


public class Main {

	public static Scanner sn = new Scanner(System.in);
	public static Tree t = new Tree();
	
	public static void main(String[] args) throws ProgramadorRepetidoException {
		
		int option=menu();
		
		if(option>4) {
			System.exit(0);
		}
		
		switch(option) {
		case 1:
			
			System.out.println("Ingrese el nombre del programador");
			String name=sn.nextLine();
			
			System.out.println("Ingrese el numero de telefono del programador");
			String phone=sn.nextLine();
			
			System.out.println("Ingrese la direccion del programador");
			String address=sn.nextLine();
			
			System.out.println("Ingrese el correo del programador");
			String email=sn.nextLine();
			
			t.add(name, phone, address, email);

			break;
		case 2:
			System.out.println("Ingrese el nombre del programador que desea eliminar");
			String nameee=sn.nextLine();
			
			t.trigerDelete(nameee);
			
			t.triggerInorder();
			break;
		case 3:
			System.out.println("Ingrese el nombre del programador que desea buscar");
			String namee=sn.nextLine();
			
			Node node = t.triggerSearch(namee);
			node.printInfo();
			
			
			break;
			
		case 4:
			t.triggerInorder();
			break;
		}
		
		main(null);
	}

	public static int menu() {
		int menu=0;
		System.out.println("                         MAIN  MENU                                                        ");
		System.out.println("-------------------------------------------------------------------------------------------");
		System.out.println("Enter (1) agregar");
		System.out.println("Enter (2) eliminar");
		System.out.println("Enter (3) buscar.");
		System.out.println("Enter (4) listar.");
		System.out.println("-------------------------------------------------------------------------------------------");
		System.out.println("Choose the option of your liking");
		menu=sn.nextInt(); sn.nextLine();
		
		return menu;
	}
}
