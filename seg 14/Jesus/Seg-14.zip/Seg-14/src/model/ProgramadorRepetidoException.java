package model;

public class ProgramadorRepetidoException extends Exception{
	public ProgramadorRepetidoException() {
		super("ERROR: EL NOMBRE ESTA REPETIDO ");
	}
}
