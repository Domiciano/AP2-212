package main;

import java.util.Scanner;

import model.Tree;

public class Main {
	
	Tree tree=new Tree();
	private static Scanner scan=new Scanner(System.in);

	public static void main(String[] args) {
		Main m = new Main();
		
		int option=0;
		int i=0;
		String j;
		
		while(i==0) {
			System.out.println("que quiere hacer?");
			option=scan.nextInt();
			scan.nextLine();
			
			
			switch(option) {
		
			case 1:	
				m.agregar();
			break;
		
			case 2:	
				j=scan.nextLine();
				m.eliminar(j);
			break;
		
			case 3:
				j=scan.nextLine();
				String message= m.buscar(j);
				System.out.println(message);
			break;
			
			case 4:
				m.lista();
			break;
		
			default:	
			break;
			}
		}

	}
	public void agregar() {
		System.out.println("nombre");
		String name=scan.nextLine();
		System.out.println("numero");
		String phone=scan.nextLine();
		System.out.println("direccion");
		String adress=scan.nextLine();
		System.out.println("mail");
		String email=scan.nextLine();
		
		tree.add(name, phone, adress, email);
		return;
	}
	public void eliminar(String j) {
		
	}
	public String buscar(String j) {
		String a= tree.triggerSearch(j);
		return a;
	}
	public void lista() {
		tree.triggerInOrder();
	}

}
