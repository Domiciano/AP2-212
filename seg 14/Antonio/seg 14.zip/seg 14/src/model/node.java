package model;

public class Node {
	
	private String name;
	private String phone;
	private String adress;
	private String email;
	private Node left, right;
	
	public Node(String name, String phone, String adress, String email) {
		super();
		this.name = name;
		this.phone = phone;
		this.adress = adress;
		this.email = email;
	}
	
	public void insert(String name, String phone, String adress, String email) {
		if(name.compareTo(this.name)<0) {
			if(this.left==null) {
				this.left=new Node(name, phone, adress, email);
			}else {
				this.left.insert(name, phone, adress, email);
			}
		}else if(name.compareTo(this.name)>0) {
			if(this.right==null) {
				this.right=new Node(name, phone, adress, email);
			}else {
				this.right.insert(name, phone, adress, email);
			}
		}
	}
	
	public Node getLeft() {
		return left;
	}

	public void setLeft(Node left) {
		this.left = left;
	}

	public Node getRight() {
		return right;
	}

	public void setRight(Node right) {
		this.right = right;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
