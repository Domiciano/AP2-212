package model;

import main.Main;

public class Tree {

	private Node root;
	
	public void inOrder(Node node) {
		if(node==null) {
			return;
		}
		
		inOrder(node.getLeft());
		System.out.println(node.getName());
		inOrder(node.getRight());
	}
	
	public void triggerInOrder() {
		inOrder(root);
	}
	

	public void add(String name, String phone, String adress, String email) {
		if(root == null) {
			root= new Node(name, phone, adress, email);
		}else {
			root.insert(name, phone, adress, email);
		}
		
	}
	
	public String search(String j, Node node) {
		String message="no hay gente agregada";
		if(node==null) {
			return message;
		}if(node.getName().equalsIgnoreCase(j)) {
			message= "nombre: "+ node.getName()+"\nphone: "+node.getPhone()+"\nadrees: "+node.getAdress()+"\nemail: "+node.getEmail();
			return message;
		}
		if(j.compareTo(node.getName())<0) {
			return search(j, node.getLeft());
		}
		if(j.compareTo(node.getName())>0) {
			return search(j, node.getRight());
		}
		return message;
	}
	
	public String triggerSearch(String j) {
		String a= search(j, root);
		return a;
	}
	
	public void delete(String j, Node node) {
		if(node==null) {
			return;
		}if(node.getName().equalsIgnoreCase(j)) {
			
			node=null;
			return;
		}
		if(j.compareTo(node.getName())<0) {
			delete(j, node.getLeft());
		}
		if(j.compareTo(node.getName())>0) {
			delete(j, node.getRight());
		}
		return ;
	}
	
	public void triggerDelete(String j) {
		search(j, root);
	}
}
