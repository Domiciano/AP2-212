package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.Serializable;

public class UserData implements Serializable {

    private static final long serialVersionUID = 1L;

    private ObservableList<UserAccount> users;

    public UserData() {
        users = FXCollections.observableArrayList();
    }

    public ObservableList<UserAccount> getData(){
        return users;
    }

    public void setUsers(ObservableList<UserAccount> users) {
        this.users = users;
    }
}
