package ui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import javafx.scene.control.TableView;
import model.UserAccount;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;

public class AccountList extends Stage {

    private TableView<UserAccount> table;

    public AccountList() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AccountList.fxml"));
            Parent root = loader.load();

            table = (TableView) loader.getNamespace().get("table");

            TableColumn<UserAccount, String> usernameColum = new TableColumn("Username");
            TableColumn<UserAccount, String> genderColum = new TableColumn("Gender");
            TableColumn<UserAccount, String> careerColum = new TableColumn("Career");
            TableColumn<UserAccount, String> birthdayColum = new TableColumn("Birthday");
            TableColumn<UserAccount, String> browserColum = new TableColumn("Browser");

            usernameColum.setCellValueFactory(new PropertyValueFactory<>("username"));
            genderColum.setCellValueFactory(new PropertyValueFactory<>("gender"));
            careerColum.setCellValueFactory(new PropertyValueFactory<>("career"));
            birthdayColum.setCellValueFactory(new PropertyValueFactory<>("birthday"));
            browserColum.setCellValueFactory(new PropertyValueFactory<>("browser"));

            table.getColumns().addAll(usernameColum, genderColum, careerColum, birthdayColum, browserColum);
            table.setItems(getDataUser());

            Scene scene = new Scene(root, 400, 500);
            setScene(scene);

            init();
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public void init() {

    }

    private ObservableList<UserAccount> getDataUser(){
        try {
            File file = new File("students.txt");
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            List<UserAccount> list = (List<UserAccount>) ois.readObject();
            ObservableList<UserAccount> userData = FXCollections.observableList(list);


            return userData;
        } catch (IOException | ClassNotFoundException ex){

            return null;
        }
    }
}
