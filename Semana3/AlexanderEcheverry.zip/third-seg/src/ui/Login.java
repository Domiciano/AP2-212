package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.UserAccount;

import java.io.*;
import java.util.ArrayList;

public class Login extends Stage {

    //Elements fx
    private Button loginBtn, singUpBtn;
    private TextField usernameTf;
    private PasswordField passwordPf;

    private Register register;
    private AccountList accountList;

    public Login() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Login.fxml"));
            Parent root = loader.load();


            Scene scene = new Scene(root, 600, 400);
            setScene(scene);


            loginBtn = (Button) loader.getNamespace().get("loginBtn");
            singUpBtn = (Button) loader.getNamespace().get("singUpBtn");
            passwordPf = (PasswordField) loader.getNamespace().get("passwordPf");
            usernameTf = (TextField) loader.getNamespace().get("usernameTf");

            init();
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public void init(){
        loginBtn.setOnAction(event -> {
            verification();
        });

        singUpBtn.setOnAction(event -> {
            register = new Register();
            register.show();

            this.close();
        });
    }

    private void verification() {
        try {
            File file = new File("students.txt");
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            ArrayList<UserAccount> users = (ArrayList<UserAccount>) ois.readObject();


            if(usernameVerification(users)){
                accountList = new AccountList();
                accountList.show();

                this.close();
            } else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information Dialog");
                alert.setHeaderText("The username or password is wrong");
                alert.setContentText("I have a great message for you!");

                alert.showAndWait();
            }
        } catch (IOException | ClassNotFoundException ex){
            ex.printStackTrace();
        }
    }

    private boolean usernameVerification(ArrayList<UserAccount> users){
        boolean value = false;

        for(int i = 0; i < users.size(); i++){
            if(users.get(i).getUsername().equals(usernameTf.getText())){
                if(users.get(i).getPassword().equals(passwordPf.getText())){
                    value = true;
                }
            }
        }

        return value;
    }
}
