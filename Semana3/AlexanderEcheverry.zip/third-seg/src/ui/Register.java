package ui;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.UserAccount;
import model.UserData;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Register extends Stage {

    //Elements fx
    private TextField usernameTf;
    private PasswordField passwordPf;
    private Button proPhotoBtn, createAccountBtn, signIn;
    private RadioButton genderMale, genderFemale, genderOther, careerSoft, careerTele, careerIndu;
    private DatePicker birthdayDp;
    private SplitMenuButton browserSmb;
    private MenuItem safariMi, chromeMi, edgeMi;

    //user's information
    private UserData userData;
    private String photoPerfilePath;
    private String browserSelected;
    private Login login;

    public Register() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Register.fxml"));
            Parent root = loader.load();

            usernameTf = (TextField) loader.getNamespace().get("usernameTf");
            passwordPf = (PasswordField) loader.getNamespace().get("passwordPf");
            proPhotoBtn = (Button) loader.getNamespace().get("proPhotoBtn");
            signIn = (Button) loader.getNamespace().get("signIn");
            createAccountBtn = (Button) loader.getNamespace().get("createAccountBtn");
            genderMale = (RadioButton) loader.getNamespace().get("genderMale");
            genderFemale = (RadioButton) loader.getNamespace().get("genderFemale");
            genderOther = (RadioButton) loader.getNamespace().get("genderOther");
            careerSoft = (RadioButton) loader.getNamespace().get("careerSoft");
            careerTele = (RadioButton) loader.getNamespace().get("careerTele");
            careerIndu = (RadioButton) loader.getNamespace().get("careerIndu");
            birthdayDp = (DatePicker) loader.getNamespace().get("birthdayDp");
            browserSmb = (SplitMenuButton) loader.getNamespace().get("browserSmb");
            safariMi = (MenuItem) loader.getNamespace().get("safariMi");
            chromeMi = (MenuItem) loader.getNamespace().get("chromeMi");
            edgeMi = (MenuItem) loader.getNamespace().get("edgeMi");

            userData = new UserData();

            Scene scene = new Scene(root, 400, 500);
            setScene(scene);

            init();
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }

    public void init() {
        signIn.setOnAction(e -> {
            login = new Login();
            login.show();

            this.close();
        });

        createAccountBtn.setOnAction(e -> {
            String username = usernameTf.getText();
            String password = passwordPf.getText();
            String gender = genderSelected();
            String career = careerSelected();
            String birthday = birthdayDp.getValue().toString();

            UserAccount user = new UserAccount(username, password, gender, career, birthday, browserSelected, photoPerfilePath);

            userData.setUsers(getDataUser());
            userData.getData().add(user);

            saveStudent(userData);

            AccountList list = new AccountList();
            list.show();

            this.close();
        });

        proPhotoBtn.setOnAction(e -> {
           getImage();
        });

        chromeMi.setOnAction(e -> {
            browserSelected = "chrome";
            browserSmb.setText("CHROME");
        });

        safariMi.setOnAction(e -> {
            browserSelected = "safari";
            browserSmb.setText("SAFARI");
        });

        edgeMi.setOnAction(e -> {
            browserSelected = "edge";
            browserSmb.setText("EDGE");
        });

        genderMale.setOnAction(e -> {
            genderFemale.selectedProperty().setValue(false);
            genderOther.selectedProperty().setValue(false);
        });

        genderFemale.setOnAction(e -> {
            genderMale.selectedProperty().setValue(false);
            genderOther.selectedProperty().setValue(false);
        });

        genderOther.setOnAction(e -> {
            genderFemale.selectedProperty().setValue(false);
            genderMale.selectedProperty().setValue(false);
        });

        careerSoft.setOnAction(e -> {
            careerIndu.selectedProperty().setValue(false);
            careerTele.selectedProperty().setValue(false);
        });

        careerIndu.setOnAction(e -> {
            careerSoft.selectedProperty().setValue(false);
            careerTele.selectedProperty().setValue(false);
        });

        careerTele.setOnAction(e -> {
            careerIndu.selectedProperty().setValue(false);
            careerSoft.selectedProperty().setValue(false);
        });
    }

    private void getImage(){
        FileChooser chooser = new FileChooser();
        chooser.setTitle("choose an image");
        chooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Png", "*.png"),
            new FileChooser.ExtensionFilter("Jpg", "*.jpg")
        );

        File file = chooser.showOpenDialog(this);

        if(file != null){
            photoPerfilePath = file.getAbsolutePath();
        }
    }

    private String genderSelected(){
        String gender = "";

        if(genderMale.selectedProperty().getValue()){
            gender = "male";
        } else if(genderFemale.selectedProperty().getValue()){
            gender = "female";
        } else if(genderOther.selectedProperty().getValue()){
            gender = "other";
        }

        return gender;
    }

    private String careerSelected(){
        String career = "";

        if(careerSoft.selectedProperty().getValue()){
            career = "software engineering";
        } else if (careerTele.selectedProperty().getValue()){
            career = "telematic engineering";
        } else if (careerIndu.selectedProperty().getValue()){
            career = "industrial engineering";
        }

        return career;
    }

    private void saveStudent(UserData user){
        try {
            File file = new File("students.txt");
            FileOutputStream out = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(out);
            oos.writeObject(new ArrayList<UserAccount>(user.getData()));
            oos.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private ObservableList<UserAccount> getDataUser(){
        try {
            File file = new File("students.txt");
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            List<UserAccount> list = (List<UserAccount>) ois.readObject();
            ObservableList<UserAccount> userData = FXCollections.observableList(list);


            return userData;
        } catch (IOException | ClassNotFoundException ex){

            return null;
        }
    }
}
