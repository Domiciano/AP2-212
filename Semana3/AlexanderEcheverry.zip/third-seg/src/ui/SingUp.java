package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.*;

public class SingUp extends Stage {

    private TextField usernameTf;
    private TextField passwordTf;
    private Button singUpBtn;

    public SingUp() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("SingUp.fxml"));
            Parent root = loader.load();

            singUpBtn = (Button) loader.getNamespace().get("singUpBtn");
            passwordTf = (TextField) loader.getNamespace().get("passwordTf");
            usernameTf = (TextField) loader.getNamespace().get("usernameTf");

            Scene scene = new Scene(root, 600, 400);
            setScene(scene);

            init();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void init(){
        singUpBtn.setOnAction(e -> {
            try {
                String account = getUsernames() + usernameTf.getText() + "," + passwordTf.getText() + ",";
                File file = new File("username.txt");
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(account.getBytes());
                fos.close();

                Login login = new Login();
                login.show();

                this.close();
            } catch (IOException ex) {

            }
        });
    }

    private String getUsernames() {
        try {
            File file = new File("username.txt");
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            byte [] buffer = new byte[2];
            int bytes = 0;

            while((bytes = fis.read(buffer)) != -1){
                baos.write(buffer, 0 , bytes);
            }

            fis.close();
            baos.close();

            String username = baos.toString();

            return username;
        } catch (IOException ex){
            ex.printStackTrace();

            return null;
        }
    }
}
