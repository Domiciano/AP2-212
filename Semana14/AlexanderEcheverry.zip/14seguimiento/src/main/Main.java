package main;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    private Scanner sc;

    private String message ="";
    private String TEST = "C:\\Users\\prestamo\\Documents\\icesi\\thirdSemester\\AP-2\\seguimientos\\14seguimiento\\src\\data\\pruebas";
    private String ANSWERS = "C:\\Users\\prestamo\\Documents\\icesi\\thirdSemester\\AP-2\\seguimientos\\14seguimiento\\src\\data\\respuestas";
    private int towerDiscA =0;
    private int towerDiscB =0;
    private int towerDiscC =0;

    public Main() {
        sc= new Scanner(System.in);
        try {
            importData();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            printAnswers();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void hanoi(int i, String origin, String destiny, String auxiliar) {
        if (i == 1) {
            if(origin.equalsIgnoreCase("A")){
                if(destiny.equalsIgnoreCase("B")){
                    towerDiscA--;
                    towerDiscB++;
                }
                else{
                    towerDiscA--;
                    towerDiscC++;
                }
            }
            else if(origin.equalsIgnoreCase("B")){

                if(destiny.equalsIgnoreCase("A")){
                    towerDiscB--;

                    towerDiscA++;
                }
                else{
                    towerDiscB--;

                    towerDiscC++;
                }
            }
            else{
                if(destiny.equalsIgnoreCase("A")){
                    towerDiscC--;

                    towerDiscA++;
                }
                else{
                    towerDiscC--;

                    towerDiscB++;
                }
            }
            message += towerDiscA +"-"+ towerDiscB +"-"+ towerDiscC +"\n";
            return;
        }
        hanoi(i - 1, origin, auxiliar, destiny);
        if(origin.equalsIgnoreCase("A")){
            if(destiny.equalsIgnoreCase("B")){
                towerDiscA--;
                towerDiscB++;
            }
            else{
                towerDiscA--;
                towerDiscC++;
            }
        }
        else if(origin.equalsIgnoreCase("B")){
            if(destiny.equalsIgnoreCase("A")){
                towerDiscB--;
                towerDiscA++;
            }
            else{
                towerDiscB--;
                towerDiscC++;
            }
        }
        else{
            if(destiny.equalsIgnoreCase("A")){
                towerDiscC--;
                towerDiscA++;
            }
            else{
                towerDiscC--;
                towerDiscB++;
            }
        }
        message += towerDiscA +"-"+ towerDiscB +"-"+ towerDiscC +"\n";
        hanoi(i - 1, auxiliar, destiny, origin);
    }
    public static void  main(String args[]) {
        Main m = new Main();
        m.message ="";
        m.joinText();
        System.out.println(m.message);
    }

    public void importData() throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(TEST));
        String line = br.readLine();
        while (line != null) {
            int discs = Integer.parseInt(line);
            testMethod(discs);
            line = br.readLine();
        }
        br.close();
    }
    public void printAnswers() throws IOException {
        FileWriter fw = new FileWriter(ANSWERS,false);
        fw.write(message);
        fw.close();
    }

    public void testMethod(int initDiscs){
        towerDiscA = initDiscs;
        towerDiscB =0;
        towerDiscC =0;
        message += towerDiscA + "-" + towerDiscB + "-" + towerDiscC + "\n";
        hanoi(initDiscs, "A", "C", "B");
        message +="\n\n";
    }

    public void joinText(){
        int numberOfCases=sc.nextInt();
        sc.nextLine();
        for(int i=0;i<numberOfCases;i++){
            int discNumber = sc.nextInt();
            sc.nextLine();
            towerDiscA = discNumber;
            towerDiscB =0;
            towerDiscC =0;
            message += towerDiscA + "-" + towerDiscB + "-" + towerDiscC + "\n";
            hanoi(discNumber, "A", "C", "B");
            message +="\n\n";
        }
    }
}
