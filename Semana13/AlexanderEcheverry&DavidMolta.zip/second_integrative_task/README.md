# second_integrative_task
This is the second integrative task of assignature Algoritmos y Programación 2
