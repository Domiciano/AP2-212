package edu.co.icesi.model;

public interface Movable {
    void movePlayer();
}
