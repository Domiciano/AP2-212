package edu.co.icesi.model;

public class Ladder {

    private Node start;
    private Node end;
}
