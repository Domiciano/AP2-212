package edu.co.icesi.model;

public class Snake {

    private Node start;
    private Node end;

    public Snake(Node start, Node end) {
        this.start = start;
        this.end = end;
    }
}
