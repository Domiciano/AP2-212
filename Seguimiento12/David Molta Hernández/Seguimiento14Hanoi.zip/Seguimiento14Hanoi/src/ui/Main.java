package ui;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    private Scanner sc;

    public String stringMessage ="";

    public String PATH_PRUEBAS = "data/pruebas";

    public String PATH_RESPUESTASPRUEBAS = "data/respuestaspruebas";

    public int amountTowerDiscA =0;

    public int amountTowerDiscB =0;

    public int amountTowerDiscC =0;


    public Main() {
        sc= new Scanner(System.in);
        try {
            importData();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            exportData();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void  main(String args[]) {
        Main m = new Main();
        m.stringMessage ="";
        m.joinText();
        System.out.println(m.stringMessage);
    }
    public void hanoi(int i, String origin, String destiny, String auxiliar) {
        if (i == 1) {
            if(origin.equalsIgnoreCase("A")){
                if(destiny.equalsIgnoreCase("B")){
                    amountTowerDiscA--;
                    amountTowerDiscB++;
                }
                else{
                    amountTowerDiscA--;
                    amountTowerDiscC++;
                }
            }
            else if(origin.equalsIgnoreCase("B")){

                if(destiny.equalsIgnoreCase("A")){
                    amountTowerDiscB--;

                    amountTowerDiscA++;
                }
                else{
                    amountTowerDiscB--;

                    amountTowerDiscC++;
                }
            }
            else{
                if(destiny.equalsIgnoreCase("A")){
                    amountTowerDiscC--;

                    amountTowerDiscA++;
                }
                else{
                    amountTowerDiscC--;

                    amountTowerDiscB++;
                }
            }
            stringMessage += amountTowerDiscA +"-"+ amountTowerDiscB +"-"+ amountTowerDiscC +"\n";
            return;
        }
        hanoi(i - 1, origin, auxiliar, destiny);
        if(origin.equalsIgnoreCase("A")){
            if(destiny.equalsIgnoreCase("B")){
                amountTowerDiscA--;
                amountTowerDiscB++;
            }
            else{
                amountTowerDiscA--;
                amountTowerDiscC++;
            }
        }
        else if(origin.equalsIgnoreCase("B")){
            if(destiny.equalsIgnoreCase("A")){
                amountTowerDiscB--;
                amountTowerDiscA++;
            }
            else{
                amountTowerDiscB--;
                amountTowerDiscC++;
            }
        }
        else{
            if(destiny.equalsIgnoreCase("A")){
                amountTowerDiscC--;
                amountTowerDiscA++;
            }
            else{
                amountTowerDiscC--;
                amountTowerDiscB++;
            }
        }
        stringMessage += amountTowerDiscA +"-"+ amountTowerDiscB +"-"+ amountTowerDiscC +"\n";
        hanoi(i - 1, auxiliar, destiny, origin);
    }
    public void importData() throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(PATH_PRUEBAS));
        String line = br.readLine();
        while (line != null) {
            int discs = Integer.parseInt(line);
            testMethod(discs);
            line = br.readLine();
        }
        br.close();
    }

    public void exportData() throws IOException {
        FileWriter fw = new FileWriter(PATH_RESPUESTASPRUEBAS,false);
        fw.write(stringMessage);
        fw.close();
    }

    public void testMethod(int initDiscs){
        amountTowerDiscA = initDiscs;
        amountTowerDiscB =0;
        amountTowerDiscC =0;
        stringMessage += amountTowerDiscA + "-" + amountTowerDiscB + "-" + amountTowerDiscC + "\n";
        hanoi(initDiscs, "A", "C", "B");
        stringMessage +="\n\n";
    }

    public void joinText(){
        int numberOfCases=sc.nextInt();
        sc.nextLine();
        for(int i=0;i<numberOfCases;i++){
            int discNumber = sc.nextInt();
            sc.nextLine();
            amountTowerDiscA = discNumber;
            amountTowerDiscB =0;
            amountTowerDiscC =0;
            stringMessage += amountTowerDiscA + "-" + amountTowerDiscB + "-" + amountTowerDiscC + "\n";
            hanoi(discNumber, "A", "C", "B");
            stringMessage +="\n\n";
        }
    }





}
