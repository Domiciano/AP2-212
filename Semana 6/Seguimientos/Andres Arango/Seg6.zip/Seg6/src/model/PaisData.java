package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class PaisData {
	
	private ObservableList<Pais> pais;
	private Pais paisR;

	public ObservableList<Pais> getPais() {
		return pais;
	}

	public void setPais(ObservableList<Pais> pais) {
		this.pais = pais;
	}

	public PaisData(ObservableList<Pais> pais) {
		
		this.pais = pais;
	}

	public PaisData() {
		
		pais= FXCollections.observableArrayList();
		// TODO Auto-generated constructor stub
	}
	
	public void addPais(Pais pai){
		pais.add(pai);
	}
	
	public void printData() {
		for(Pais pais: pais) {
			System.out.println(pais.toString());
		}
	}
	public void printData0() {
		for(Pais pais:pais) {
			System.out.println(pais.toString0());
		}
	}
	
	public void printData1() {
		for(Pais pais:pais) {
			System.out.println(pais.toString1());
		}
	}

	public void burbuja(ObservableList<Pais> pais) {
		for(int i=1; i< pais.size();i++) {
			for ( int j=0;j<pais.size();j++) {
				Pais a= pais.get(i);
				Pais b= pais.get(j);
				if(pais.get(j).getSumaOro()<pais.get(i).getSumaOro()) {
					pais.set(i, b);
					pais.set(j, a);
				}if(pais.get(j).getSumaOro()== pais.get(i).getSumaOro()) {
					Pais p= pais.get(i);
					Pais s= pais.get(j);
					if(pais.get(j).getSumaPlata()<pais.get(i).getSumaPlata()) {
						pais.set(i, s);
						pais.set(j, p);
						}if(pais.get(j).getSumaPlata()== pais.get(i).getSumaPlata()) {
							Pais y= pais.get(i);
							Pais z= pais.get(j);
							if(pais.get(j).getSumaBronce()<pais.get(i).getSumaBronce()) {
								pais.set(i, z);
								pais.set(j, y);
							}
							}
						}
				}
				
				
			}
		
		}
	public void insertionSort(ObservableList<Pais> pais) {
		for ( int rojo = 1; rojo < pais.size(); rojo++) {
			for ( int verde= 0; verde < rojo; verde++) {
				Pais a= pais.get(verde);
				Pais b= pais.get(rojo);
				if(a.getSumaOro() < b.getSumaOro() ) {
					pais.remove(rojo);
					pais.add(verde, b);
					break;
				}if(a.getSumaOro()==b.getSumaOro()) {
					Pais a1= pais.get(verde);
					Pais b1= pais.get(rojo);
					if(a1.getSumaPlata()<b1.getSumaPlata()) {
							pais.remove(rojo);
							pais.add(verde, b1);
							break;
					}if(a1.getSumaPlata()==b1.getSumaPlata()) {
						Pais a2= pais.get(verde);
						Pais b2= pais.get(rojo);
						if(a2.getSumaBronce()<b2.getSumaBronce()) {
							pais.remove(rojo);
							pais.add(verde, b2);
							break;
						}
					}
						
				}
			}
		}
	}
	public void insertionSort1(ObservableList<Pais> pais) {
		for ( int rojo = 1; rojo < pais.size(); rojo++) {
			for ( int verde= 0; verde < rojo; verde++) {
				Pais a= pais.get(verde);
				Pais b= pais.get(rojo);
				if(a.getSumaOro() > b.getSumaOro() ) {
					pais.remove(rojo);
					pais.add(verde, b);
					break;
				}if(a.getSumaOro()==b.getSumaOro()) {
					Pais a1= pais.get(verde);
					Pais b1= pais.get(rojo);
					if(a1.getSumaPlata()>b1.getSumaPlata()) {
							pais.remove(rojo);
							pais.add(verde, b1);
							break;
					}if(a1.getSumaPlata()==b1.getSumaPlata()) {
						Pais a2= pais.get(verde);
						Pais b2= pais.get(rojo);
						if(a2.getSumaBronce()>b2.getSumaBronce()) {
							pais.remove(rojo);
							pais.add(verde, b2);
							break;
						}
					}
						
				}
			}
		}
	}

	public Pais getPaisR() {
		return paisR;
	}

	public void setPaisR(Pais paisR) {
		this.paisR = paisR;
	}
	}
	
	
	
	
	


