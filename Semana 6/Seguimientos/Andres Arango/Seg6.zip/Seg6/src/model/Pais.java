package model;

public class Pais implements Comparable<Pais> {

	private String name;
	private String goldMenMedals;
	private String silverMenMedals;
	private String bronzeMenMedals;
	private String goldWomenMedals;
	private String silverWomenMedals;
	private String bronzeWomenMedals;
	
	private int sumaOro;
	private int sumaBronce;
	private int sumaPlata;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGoldMenMedals() {
		return goldMenMedals;
	}
	public void setGoldMenMedals(String goldMenMedals) {
		this.goldMenMedals = goldMenMedals;
	}
	public String getSilverMenMedals() {
		return silverMenMedals;
	}
	public void setSilverMenMedals(String silverMenMedals) {
		this.silverMenMedals = silverMenMedals;
	}
	public String getBronzeMenMedals() {
		return bronzeMenMedals;
	}
	public void setBronzeMenMedals(String bronzeMenMedals) {
		this.bronzeMenMedals = bronzeMenMedals;
	}
	public String getGoldWomenMedals() {
		return goldWomenMedals;
	}
	public void setGoldWomenMedals(String goldWomenMedals) {
		this.goldWomenMedals = goldWomenMedals;
	}
	public String getSilverWomenMedals() {
		return silverWomenMedals;
	}
	public void setSilverWomenMedals(String silverWomenMedals) {
		this.silverWomenMedals = silverWomenMedals;
	}
	public String getBronzeWomenMedals() {
		return bronzeWomenMedals;
	}
	public void setBronzeWomenMedals(String bronzeWomenMedals) {
		this.bronzeWomenMedals = bronzeWomenMedals;
	}
	
	public Pais(String name, String goldMenMedals, String silverMenMedals, String bronzeMenMedals,
			String goldWomenMedals, String silverWomenMedals, String bronzeWomenMedals, int sumaOro, int sumaBronce,
			int sumaPlata) {
		
		this.name = name;
		this.goldMenMedals = goldMenMedals;
		this.silverMenMedals = silverMenMedals;
		this.bronzeMenMedals = bronzeMenMedals;
		this.goldWomenMedals = goldWomenMedals;
		this.silverWomenMedals = silverWomenMedals;
		this.bronzeWomenMedals = bronzeWomenMedals;
		this.sumaOro = sumaOro;
		this.sumaBronce = sumaBronce;
		this.sumaPlata = sumaPlata;
	}
	
	public Pais() {
		
		// TODO Auto-generated constructor stub
	}
	@Override
	public int compareTo(Pais o) {
		
		int criterioB= this.goldWomenMedals.compareTo(o.goldWomenMedals);
			if(criterioB==0) {
				int criterioC= this.silverWomenMedals.compareTo(o.silverWomenMedals);
				if(criterioC==0) {
					int criterioD= this.bronzeWomenMedals.compareTo(bronzeWomenMedals);
					if(criterioD==0) {
						int criterioA= this.name.compareTo(o.name);
						return criterioA;
					}
					return criterioD;
				}
				return criterioC;
			}
			return criterioB;
		// TODO Auto-generated method stub
		
	}
	
	public String toString() {
		String output= name+" "+goldWomenMedals+" "+silverWomenMedals+" "+bronzeWomenMedals;
		return output;
	}
	
	public String toString0() {
		String output= name+" "+goldMenMedals+" "+silverMenMedals+" "+bronzeMenMedals;
		return output;
	}
	
	public String toString1() {
		String output= name+" "+sumaOro+" "+sumaPlata+" "+sumaBronce;
		return output;
	}
	public int getSumaOro() {
		return sumaOro;
	}
	public void setSumaOro(int sumaOro) {
		this.sumaOro = sumaOro;
	}
	public int getSumaPlata() {
		return sumaPlata;
	}
	public void setSumaPlata(int sumaPlata) {
		this.sumaPlata = sumaPlata;
	}
	public int getSumaBronce() {
		return sumaBronce;
	}
	public void setSumaBronce(int sumaBronce) {
		this.sumaBronce = sumaBronce;
	}
	
	
	
	
	
	
	
	
	
	
}
