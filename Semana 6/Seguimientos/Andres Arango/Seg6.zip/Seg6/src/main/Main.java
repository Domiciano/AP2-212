package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import model.Pais;
import model.PaisData;

public class Main {
	
	PaisData paises;
	private static Scanner scanner;
		public static void main(String[] args) {
		scanner = new Scanner(System.in);
		
		PaisData paises= new PaisData();
		
		System.out.println("Digita la cantidad de paises que vas a ordenar");
		String numLinsStr= scanner.nextLine();
		int numLines= Integer.parseInt(numLinsStr);
		
		for(int i=0; i<numLines;i++) {
		System.out.println("Listo, vamos a ordenar " +numLines+ " paises");
		int numPais=i+1;
		
		if(numLines != 1) {
		System.out.println("Digite el " + numPais + " pais");
		
		}else {
			System.out.println("Digite el "+ numLines + " pais");
		}
		if(i==0) {
		System.out.println("Recuerde el orden:\n"+
				"nombre del pa�s;cantidad de medallas de oro masculino;plata masculino;bronce masculino;oro femenino;plata femenino;bronce femenino");
		}String line= scanner.nextLine();
				
				ArrayList<String> division = new ArrayList<String>(Arrays.asList(line.split(";")));
				
		        
		        String name= division.get(0);
		        String goldMenMedals= division.get(1);
		        String silverMenMedals= division.get(2);
		        String bronzeMenMedals= division.get(3);
		        String goldWomneMedals= division.get(4);
		        String silverWomenMedals= division.get(5);
		        String bronzeWomenMedals= division.get(6);
		        int sumaOro= Integer.parseInt(division.get(1))+ Integer.parseInt(division.get(4));
		        int sumaPlata= Integer.parseInt(division.get(3))+ Integer.parseInt(division.get(6));
		        int sumaBronce= Integer.parseInt(division.get(2))+Integer.parseInt(division.get(5));
		        
		        Pais pais= new Pais(name, goldMenMedals,silverMenMedals,bronzeMenMedals,goldWomneMedals,silverWomenMedals,bronzeWomenMedals,sumaOro,sumaPlata,sumaBronce);
		        paises.addPais(pais);
		        
		        
		}      
		        
		        Collections.sort(paises.getPais(), (o1,o2)->{
		        	int value= Integer.parseInt(o1.getGoldMenMedals())- Integer.parseInt(o2.getGoldMenMedals());
		        	if(value==0) {
		        		value= o1.getSilverMenMedals().compareTo(o2.getSilverMenMedals());
		        		if(value==0) {
		        			value=o1.getBronzeMenMedals().compareTo(o2.getBronzeMenMedals());
		        			if(value==0) {
		        				value= o1.getName().compareTo(o2.getName());
		        				
		        			}
		        		}
		        	}
		        	return -value;
		        });
		        System.out.println("Hombres");
		        paises.printData0();
		        System.out.println("----------");
		        System.out.println("Femenino");
		        Collections.sort(paises.getPais());
				paises.printData();
				System.out.println("----------");
				System.out.println("Combinado");
				paises.burbuja(paises.getPais());
				paises.printData1();
				System.out.println("----------");
				System.out.println("Combinado");
				paises.insertionSort(paises.getPais());
				paises.printData1();
				System.out.println("----------");
				System.out.println("Combinado-Forma Ascendente");
				paises.insertionSort1(paises.getPais());
				paises.printData1();
		        
				
		        
		        
		        
	
        
		
		}

		
		
}



