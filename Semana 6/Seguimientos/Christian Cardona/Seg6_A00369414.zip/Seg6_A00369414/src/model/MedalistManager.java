package model;

import java.util.ArrayList;
import java.util.Scanner;

public class MedalistManager {

	private static ArrayList<Medalists> medalists;

	public MedalistManager() {

		medalists = new ArrayList<>();

	}

	public static ArrayList<Medalists> getData() {

		return medalists;
	}

	public void addMedalist(String country, int goldMC, int silverMC, int bronzeMC, int goldFM, int silverFM,
			int bronzeFM, int gold, int silver, int bronze) {

		Medalists medalist = new Medalists(country, goldMC, silverMC, bronzeMC, goldFM, silverFM, bronzeFM, gold,
				silver, bronze);

		getData().add(medalist);
	}

	public void printData() {

		for (Medalists med : medalists) {

			System.out.println(med.toString());
		}

	}

	public void printMCdata() {

		for (Medalists med : medalists) {

			System.out.println(med.mcData());
		}
	}

	public void printFMdata() {

		for (Medalists med : medalists) {

			System.out.println(med.fmData());
		}

	}

	public void printSort() {

		for (Medalists med : medalists) {

			System.out.println(med.bubleeData());
		}
	}

	public void showFM() {

		medalists.sort((o1, o2) -> {

			int criterioA = o1.getGoldFM() - o2.getGoldFM();

			if (criterioA == 0) {

				int criterioB = o1.getSilverFM() - o2.getSilverFM();

				if (criterioB == 0) {

					int criterioC = o1.getBronzeFM() - o2.getBronzeFM();
					return criterioC;
				} else {
					return criterioB;
				}

			} else {
				return criterioA;
			}
		});
	}

	public void bubbleSort(ArrayList<Medalists> medalists) {

		for (int i = 1; i < medalists.size(); i++) {
			for (int j = 0; j < medalists.size(); j++) {

				Medalists a = medalists.get(i);
				Medalists b = medalists.get(j);

				if (medalists.get(j).getGold() < medalists.get(i).getGold()) {

					medalists.set(i, b);
					medalists.set(j, a);

				} else if (medalists.get(j).getGold() == medalists.get(i).getGold()) {

					Medalists p = medalists.get(i);
					Medalists s = medalists.get(j);

					if (medalists.get(j).getSilver() < medalists.get(i).getSilver()) {

						medalists.set(i, s);
						medalists.set(j, p);
					} else if (medalists.get(j).getSilver() == medalists.get(i).getSilver()) {

						Medalists b1 = medalists.get(i);
						Medalists br = medalists.get(j);

						if (medalists.get(j).getBronze() < medalists.get(i).getBronze()) {

							medalists.set(i, br);
							medalists.set(j, b1);

						}

					}

				}

			}
		}
	}

	public void insertionSort(ArrayList<Medalists> medalists) {

		for (int rojo = 1; rojo < medalists.size(); rojo++) {
			for (int verde = 0; verde < rojo; verde++) {

				Medalists r = medalists.get(rojo);
				Medalists v = medalists.get(verde);

				if (r.getGold() > v.getGold()) {

					medalists.remove(rojo);
					medalists.add(verde, r);
					break;

				} else if (r.getGold() == v.getGold()) {

					Medalists p = medalists.get(rojo);
					Medalists s = medalists.get(verde);

					if (p.getSilver() > s.getSilver()) {

						medalists.remove(rojo);
						medalists.add(verde, p);
						break;

					} else if (p.getSilver() == s.getSilver()) {

						Medalists b1 = medalists.get(rojo);
						Medalists b2 = medalists.get(verde);

						if (b1.getBronze() > b2.getBronze()) {

							medalists.remove(rojo);
							medalists.add(verde, b1);
							break;

						}

					}

				}
			}
		}
	}

}
