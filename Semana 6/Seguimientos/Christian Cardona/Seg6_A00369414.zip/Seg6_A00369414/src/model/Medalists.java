package model;

public class Medalists implements Comparable<Medalists> {

	private String country;

	private int goldMC;
	private int silverMC;
	private int bronzeMC;

	private int goldFM;
	private int silverFM;
	private int bronzeFM;
	
	private int gold;
	private int silver;
	private int bronze;

	public Medalists(String country, int goldMC, int silverMC, int bronzeMC, int goldFM, int silverFM, int bronzeFM,
			int gold, int silver, int bronze) {

		this.country = country;
		this.goldMC = goldMC;
		this.silverMC = silverMC;
		this.bronzeMC = bronzeMC;
		this.goldFM = goldFM;
		this.silverFM = silverFM;
		this.bronzeFM = bronzeFM;
		
		this.gold = gold;
		this.silver = silver;
		this.bronze = bronze;
	}

	public int getGold() {
		return gold;
	}

	public void setGold(int gold) {
		this.gold = gold;
	}

	public int getSilver() {
		return silver;
	}

	public void setSilver(int silver) {
		this.silver = silver;
	}

	public int getBronze() {
		return bronze;
	}

	public void setBronze(int bronze) {
		this.bronze = bronze;
	}

	@Override
	public String toString() {
		return country + "; " + goldMC + "; " + silverMC + "; " + bronzeMC + "; " + goldFM + "; " + silverFM + "; "
				+ bronzeFM + "\n";
	}

	public String mcData() {

		return country + " " + goldMC + " " + silverMC + " " + bronzeMC;

	}

	public String fmData() {

		return country+" "+goldFM+" " +silverFM+" "+bronzeFM; 

	}
	
	public String bubleeData() {
		
		return country+" "+gold+" "+silver+" "+bronze;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getGoldMC() {
		return goldMC;
	}

	public void setGoldMC(int goldMC) {
		this.goldMC = goldMC;
	}

	public int getSilverMC() {
		return silverMC;
	}

	public void setSilverMC(int silverMC) {
		this.silverMC = silverMC;
	}

	public int getBronzeMC() {
		return bronzeMC;
	}

	public void setBronzeMC(int bronzeMC) {
		this.bronzeMC = bronzeMC;
	}

	public int getGoldFM() {
		return goldFM;
	}

	public void setGoldFM(int goldFM) {
		this.goldFM = goldFM;
	}

	public int getSilverFM() {
		return silverFM;
	}

	public void setSilverFM(int silverFM) {
		this.silverFM = silverFM;
	}

	public int getBronzeFM() {
		return bronzeFM;
	}

	public void setBronzeFM(int bronzeFM) {
		this.bronzeFM = bronzeFM;
	}

	@Override
	public int compareTo(Medalists obj) {

		int criterioA = -this.goldMC + obj.goldMC;

		if (criterioA == 0) {

			int criterioB = -this.silverMC + obj.silverMC;

			if (criterioB == 0) {

				int criterioC = -this.bronzeMC + obj.bronzeMC;

				if (criterioC == 0) {

					int criterioD = this.country.compareTo(obj.country);

					return criterioD;
				} else {
					return criterioC;
				}
			} else {
				return criterioB;
			}
		} else {
			return criterioA;
		}

	}

}
