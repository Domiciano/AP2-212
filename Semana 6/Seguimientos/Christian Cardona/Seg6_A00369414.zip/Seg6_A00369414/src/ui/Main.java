package ui;

import java.util.Collections;
import java.util.Scanner;

import model.MedalistManager;

public class Main {

	private Scanner reader = new Scanner(System.in);

	private MedalistManager medalistManager = new MedalistManager();

	public static void main(String[] args) {

		Main main = new Main();
		main.addMedalist();
		
		System.out.println("\n----------");
		
		main.showMC();
		
		System.out.println("\n----------");
		main.showFM();
		
		System.out.println("\n----------");
		main.methodMix();
		
		System.out.println("\n----------");
		main.orderByInsertion();
		
		
	}

	public void addMedalist(){
		
		System.out.print("Ingrese el numero de paises: ");

		int numCountries = reader.nextInt();
		reader.nextLine();

		for (int i = 0; i < numCountries; i++) {

			System.out.print("Pais: ");
			String country = reader.nextLine();
			
			System.out.print("Oro Masculino: ");
			int goldMC = reader.nextInt();

			System.out.print("Plata Masculino: ");
			int silverMC = reader.nextInt();
			
			System.out.print("Bronce Masculino: ");
			int bronzeMC = reader.nextInt();
			
			System.out.print("Oro Femenino: ");
			int goldFM = reader.nextInt();
			
			System.out.print("Plata Femenino: ");
			int silverFM = reader.nextInt();
			
			System.out.print("Bronce Femenino: ");
			int bronzeFM = reader.nextInt();
			reader.nextLine();
			
			int gold = goldMC + goldFM;
			
			int silver = silverMC + silverFM;
			
			int bronze = bronzeMC + bronzeFM;
			

			medalistManager.addMedalist(country, goldMC, silverMC, bronzeMC, goldFM, silverFM, bronzeFM, gold, silver, bronze);

		}

		medalistManager.printData();

	}
	
	public void showMC() {
		
		Collections.sort(medalistManager.getData());
		
		System.out.println("Masculino: ");
		
		medalistManager.printMCdata();
	}
	
	public void showFM() {
		
		System.out.println("Femenino: ");
		
		medalistManager.showFM();
		
		medalistManager.printFMdata();
		
	}
	
	public void methodMix() {
		
		System.out.println("Combinado: ");
		
		medalistManager.bubbleSort(medalistManager.getData());
		
		medalistManager.printSort();
	}
	
	public void orderByInsertion() {
		
		System.out.println("Combinado: ");
		
		medalistManager.insertionSort(medalistManager.getData());
		
		medalistManager.printSort();
		
		
	}
	

}
