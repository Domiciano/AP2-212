package Main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int countries = Integer.parseInt(scan.nextLine());
		String[] countryName = new String[countries];
		int[]medals = new int[6];
		String medalsraw = scan.nextLine();
		String[] parts = medalsraw.split(";");
		
		for(int i=0;i<countryName.length;i++) {
			for(int j=0;j<parts.length;j++) {
				medals[j] = Integer.parseInt(parts[j]);
			}
		}
		System.out.println(countries);
		System.out.println(countryName);
		for(int p:medals) {
			System.out.println(p+"");
		}	
	}
}