package ui;

import java.util.Scanner;

import model.InfrastructureDepartment;

public class Main
{
	// Relationships
	
	InfrastructureDepartment data;
	Scanner sc;
	
	public Main()
	{
		data = new InfrastructureDepartment();
		sc = new Scanner(System.in);
	}
	
	public static void main(String[] args)
	{
		Main window = new Main();
		
		int  option = 0;
	
		while(option != 5)
		{
			option = window.mainMenu();
			window.process(option);
		}
	}
	
	public int mainMenu()
	{
		int option;
		
		print("Welcome to the billboard management program!");
		print("Choose one of the following options:");
		print("1. Add a billboard");
		print("2. Show all billboards");
		print("3. Save all billboards so far");
		print("4. Show dangerous billboards");
		print("5. Exit");
		
		option = sc.nextInt();
		sc.nextLine();
		
		return option;
	}
	
	public void process(int opt)
	{
		switch(opt)
		{
			case 1: addBillboard();
			case 2: showBillboards();
			case 3: saveBillboards();
			case 4: showDangerous();
			default: System.exit(0);
		}
	}
	
	public void showDangerous()
	{
		
	}
	
	public void saveBillboards()
	{
		
	}
	
	public void showBillboards()
	{
		
	}
	
	public void addBillboard()
	{
		
	}
	
	public void print(String msg)
	{
		System.out.println(msg);
	}
}
