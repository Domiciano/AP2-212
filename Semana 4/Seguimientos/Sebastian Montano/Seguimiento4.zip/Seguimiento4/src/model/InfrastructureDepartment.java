package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class InfrastructureDepartment {
	// Attributes

	public static String BILLBOARD_FILE_NAME;
	
	public double dangerousArea = 160;

	// Relationships

	ArrayList<Billboard> billboards = new ArrayList<>();
	
	// Reader & Writer
	
	BufferedReader br;
	BufferedWriter wr;
	
	public InfrastructureDepartment()
	{
		BILLBOARD_FILE_NAME = "C:\\Users\\dierm\\Desktop\\workspace\\APO 2\\seguimiento4\\AP2-212\\Semana 4\\Seguimiento4\\BillboardDataExported.csv";
		
		try
		{
			br = new BufferedReader(new FileReader(BILLBOARD_FILE_NAME));
			wr = new BufferedWriter(new FileWriter(BILLBOARD_FILE_NAME));
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}

	public void addBillboard(double w, double h, boolean iu, String b)
	{
		Billboard newBillboard = new Billboard(w, h, iu, b);
		
		billboards.add(newBillboard);
	}
	
	public String exportDangerousBillboards()
	{
		String report = "===========================\n"
				+ "DANGEROUS BILLBOARD REPORT\n"
				+ "===========================\n"
				+ "\n"
				+ "The Dangerous billboards are:\n";
		
		int counter = 0;
		
		for(int i = 0 ; i < billboards.size() ; i++)
		{
			if(billboards.get(i).calculateArea() >= dangerousArea)
			{
				counter++;
				report += counter + ". Billboard" + billboards.get(i).getBrand() + " with area: " + billboards.get(i).calculateArea();
			}
		}
		
		return report;
	}
	
	public String importBillboards()
	{
		String allBillboards = "This are all the billboards:";
		
		
		for(int i = 0 ; i < billboards.size() ; i++)
		{
			allBillboards += i + ". " + billboards.get(i).toString();
		}
		
		return allBillboards;
	}
	
	public void saveBillboards()
	{
		
	}

}
