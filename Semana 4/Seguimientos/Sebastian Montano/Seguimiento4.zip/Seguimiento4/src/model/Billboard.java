package model;

import java.io.Serializable;

public class Billboard implements Serializable
{
	
	// Attributes
	
	private double width, height;
	private boolean inUse;
	private String brand;
	
	// Builder
	
	public Billboard(double w, double h, boolean use, String b)
	{
		
	}
	
	// Getters & Setters
	
	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public boolean isInUse() {
		return inUse;
	}

	public void setInUse(boolean inUse) {
		this.inUse = inUse;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	// Methods
	
	public double calculateArea()
	{
		double area = height*width;
		return area;
	}
	
	public String toString()
	{
		String billboard = "Brand: " + brand + "\nHeight: " + height + "\nIn use: " + inUse + "\n"; 
		return billboard;
	}
	
}
