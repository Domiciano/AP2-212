package model;

public class Billboard {
	
	//Attributes
	private double width = 0;
	private double height = 0;
	private boolean inUse = false;
	private String brand;
	//Methods
	public Billboard(double pWidth, double pHeight, boolean pInUse, String pBrand){
		width = pWidth;
		height = pHeight;
		inUse = pInUse;
		brand = pBrand;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public boolean isInUse() {
		return inUse;
	}
	public void setInUse(boolean inUse) {
		this.inUse = inUse;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public double calculateArea() {
		return 0;
		
	}
}