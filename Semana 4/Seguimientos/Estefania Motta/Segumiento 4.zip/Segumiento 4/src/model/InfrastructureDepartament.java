package model;

import java.util.ArrayList;

public class InfrastructureDepartament {
	
	//Constants
	public static final String BILLBOARD_FILE_NAME = "data/billboard.bbd";
	//Relations
	private ArrayList<Billboard> billboards;
	//Methods
	public InfrastructureDepartament() {
		billboards = new ArrayList<Billboard>();
	}
	public Billboard searchBillboard(String brand){
		Billboard search = null;
	    boolean find = false;
	    for (int i=0;i<billboards.size()&&!find==false;i++){
	    	Billboard board = billboards.get(i);
			if (board.getBrand().equals(brand)){
				search = billboards.get(i);
				find = true;
			}
		}
			return search;
	}
	public void addBillboard(double width, double height, boolean inUse, String brand ) {
		Billboard board = searchBillboard(brand);
		if(board==null) {
			board = new Billboard(width, height, inUse, brand);
			billboards.add(board);
		}
	}
	public void saveBillboad(String brand,double width, double height) {
		searchBillboard(brand);
		boolean find = false;
	    for (int i=0;i<billboards.size()&&!find==false;i++){
	    	if(width * height>=180) {
	    		billboards.get(i);
	    		find = true;
	    	}
	    }	
	}
	public void loadBillboad() {
		
	}
	public void exportDangerousBillboardReport(String fn) {
		
	}
	public void importData(String fn) {
		
	}
	public String showDangerousBillboard() {
		String message = ("===========================\n DANGEROUS BILLBOARD REPORT\n ===========================\n The dangerous billboard are:"+);
		message = "";
		return message;
	}
	public String showBillboards() {
		String message = "";
		message = "";
		return message;
	}
}