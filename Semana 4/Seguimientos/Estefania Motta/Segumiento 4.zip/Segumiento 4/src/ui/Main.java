package ui;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import model.InfrastructureDepartament;

public class Main {
	//Attributes
		private InfrastructureDepartament mainInfrastructure;
		// global variables
		public static Scanner lector;
	public Main() {
		lector = new Scanner(System.in);
		createBillboard();
	}
	public static void main(String[] args) {
		try {
			File file = new File("/Users/domicianorincon/Documents/GIT/BillboardDataExported.csv");
			FileInputStream fis = new FileInputStream(file);
			ByteArrayOutputStream baos = new ByteArrayOutputStream(); 

			int leidos = 0;
			byte[] buffer = new byte[1024];
			while(  (leidos = fis.read(buffer)) != -1  ) {
				baos.write(buffer, 0, leidos);
			}
			fis.close();
			baos.close();
			String csv = baos.toString();

			//Expresiones regulares

			String[] lines = csv.split("\\|");
			for(int i=0 ; i<lines.length ; i++) {
				System.out.println(lines[i]);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Main objMain=new Main();
		boolean menu=true;
		int opcions = 0;
		while(menu){
			System.out.println("1.- Add Billboard");
            System.out.println("2.- Show Billboard");
            System.out.println("3.- Hazard report");
            System.out.println("4.- Exit");
			
			System.out.println("Enter the action to perform: ");
			opcions=Integer.parseInt(lector.nextLine());
			switch(opcions){
			case 1:
				objMain.createBillboard();
				break;
				case 2:
				objMain.showBillboards();
				break;
				case 3:
				objMain.hazardReport();
				break;
				case 4:
					menu=false;
				break;
				default:
					System.out.println("Only numbers between 1 and 4.");
					break;
			}
		}
	}
	private void createBillboard() {
		System.out.println("Inser the width of the billboard");
		double width = Double.parseDouble(lector.nextLine());
		System.out.println("Inser the height of the billboard");
		double height = Double.parseDouble(lector.nextLine());
		System.out.println("Inser if the billboard is in use.");
		boolean inUse = Boolean.parseBoolean(lector.nextLine());
		System.out.println("Inser the brand of the billboard");
		String brand = lector.nextLine();
		mainInfrastructure.addBillboard(width, height, inUse, brand);
	}
	private void showBillboards() {
		String message = mainInfrastructure.showBillboards();
		System.out.println(message);
	}
	private void hazardReport() {
		String message = mainInfrastructure.showDangerousBillboard();
		System.out.println(message);
	}
}