package model;

import java.io.*;
import java.util.ArrayList;

public class InfrastructureDepartment {

    public static final int DANGEROUS_BILLBOARD = 160;
    private String [] billboards;

    public InfrastructureDepartment() {
    }

    public void addBillboard(String billboard){
        String [] aBillboard = billboard.split("\\+\\+");
        billboard = aBillboard[0] + "|" + aBillboard[1] + "|" + aBillboard[2] + "|" + aBillboard[3];
        String billboards = loadBillboards();
        billboards = billboards + "\n" + billboard;
        this.billboards = billboards.split("\\\n");
        saveBillboards(billboards);
        saveObjectBillboard();
    }

    public void saveBillboards(String billboards){
        try{
            File file = new File("BillboardDataExported.csv");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(billboards.getBytes());
            fos.close();
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }

    public String loadBillboards(){
        try{
            File file = new File("BillboardDataExported.csv");
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();

            byte[] buffer = new byte[128];
            int numBytes = 0;

            while ((numBytes = fis.read(buffer)) != -1){
                baos.write(buffer, 0, numBytes);
            }

            fis.close();
            baos.close();

            String lectura = baos.toString();
            billboards = lectura.split("\\\n");

            return lectura;
        } catch (Exception ex){
            ex.printStackTrace();

            return null;
        }
    }

    public String exportDangerousBillboardReport(){
        String dangerousBillboardReport = "";

        ArrayList<Billboard> billboards = loadBillboardObject();

        int num = 1;
        for(int i = 1; i < billboards.size(); i++){
            int area = isDangerous(billboards.get(i).getWidth(), billboards.get(i).getHeight());
            String brand = billboards.get(i).getBrand();
            brand.replaceAll("\n", " ");
            if(area > DANGEROUS_BILLBOARD){
                dangerousBillboardReport += num + " Billboard " + brand + " with area " + area + "\n";
                num++;
            }
        }

        createDangerousReport(dangerousBillboardReport);

        return dangerousBillboardReport;
    }

    private int isDangerous(String sWidth,String sHeight){
        int area = 0;

        Integer width = Integer.valueOf(sWidth);
        Integer height = Integer.valueOf(sHeight);

        area = width*height;

        return area;
    }

    private void createDangerousReport(String dangerousBillboards){
        try {
            File file = new File("report.txt");
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(dangerousBillboards.getBytes());
            fos.close();
        } catch (IOException ex){
            ex.printStackTrace();
        }
    }

    private ArrayList<Billboard> convertToObject(){
        ArrayList<Billboard> billboards = new ArrayList<Billboard>();
        String [] billboardString = this.billboards;
        Billboard billboard;
        String width = "";
        String height = "";
        String inUse = "";
        String brand = "";

        for(int i = 1; i < billboardString.length; i++){
            String [] contentBillboard = billboardString[i].split("\\|");

            width = contentBillboard[0];
            height = contentBillboard[1];
            inUse = contentBillboard[2];
            brand = contentBillboard[3];

            billboard = new Billboard(width,height,inUse,brand);
            billboards.add(billboard);
        }

        return billboards;
    }

    public void saveObjectBillboard(){
        ArrayList<Billboard> billboards = convertToObject();
        try{
            File file = new File("billboardsInObjects.csv");
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream out = new ObjectOutputStream(fos);
            out.writeObject(billboards);
            out.close();
        } catch (Exception ex){
            ex.printStackTrace();
        }
    }

    private ArrayList<Billboard> loadBillboardObject(){
        ArrayList<Billboard> billboards = new ArrayList<Billboard>();
        try{
            File file = new File("billboardsInObjects.csv");
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            billboards = (ArrayList<Billboard>) ois.readObject();

            return billboards;
        } catch (IOException | ClassNotFoundException ex){
            ex.printStackTrace();
            return null;
        }
    }

    public String[] getBillboards() {
        return billboards;
    }
}
