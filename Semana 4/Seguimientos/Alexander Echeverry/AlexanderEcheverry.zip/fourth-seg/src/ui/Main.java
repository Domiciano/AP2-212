package ui;

import model.InfrastructureDepartment;

import java.util.Scanner;

public class Main {

    private InfrastructureDepartment infrastructureDepartment;
    private Scanner sc;

    public Main() {
        infrastructureDepartment = new InfrastructureDepartment();
        sc = new Scanner(System.in);
    }

    public static void main(String[] args){
        Main principal = new Main();
        int option;

        String billboards = principal.infrastructureDepartment.loadBillboards();
        principal.infrastructureDepartment.saveBillboards(billboards);
        principal.infrastructureDepartment.saveObjectBillboard();

        do{
            option = principal.menu();
            principal.actions(option);
        }while(option != 4);
    }

    private int menu(){
        int option = 0;

        System.out.println("  (Main Menu)  \n" +
                           "1. Add fence\n" +
                           "2. Show fences\n" +
                           "3. generate hazard report\n" +
                           "4. get out" );

        option = sc.nextInt();
        sc.nextLine();

        return option;
    }

    private void actions(int option){
        switch(option){
            case 1:
                addBillboard();
                break;
            case 2:
                showBillboards();
                break;
            case 3:
                dangerousReport();
                break;
            case 4:
                System.exit(0);
                break;
        }
    }

    public void addBillboard() {
        System.out.println("Enter info billboard like this: \nwidth++height++inUse++brand \nnote: inUse must be true or false" );
        String billboard = sc.nextLine();

        infrastructureDepartment.addBillboard(billboard);
    }

    private void showBillboards(){
        String [] billboards = infrastructureDepartment.getBillboards();

        for(int i = 0; i < billboards.length; i++){
                System.out.println(billboards[i].replace("|", " "));
        }
    }

    private void dangerousReport(){
        String dangerousReport = infrastructureDepartment.exportDangerousBillboardReport();

        System.out.println(dangerousReport);
    }
}
