package ui;

import java.io.File;
import java.time.LocalDate;



import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SplitMenuButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Students;
import model.StudentsData;

public class RegisterWindow extends Stage {
	
	
	SplitMenuButton browsertext;
	MenuItem explorer,chrome,firefox;
	String browser;
	Image image;

	Button createAcc;
	TextField nameTF;
	TextField passTF;
	DatePicker birthdayTF;
	Button browseImage;
	TextField imageRute;
	RadioButton malecheck,femalecheck,othercheck,telematiccheck,industrialcheck,softwarecheck;
	private StudentsData students;

	public RegisterWindow() {

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("RegisterWindow.fxml"));
			Parent root = loader.load();
			
			explorer = (MenuItem) loader.getNamespace().get("explorer");
			chrome = (MenuItem) loader.getNamespace().get("chrome");
			firefox = (MenuItem) loader.getNamespace().get("firefox");
			browsertext = (SplitMenuButton) loader.getNamespace().get("browsertext");
	
			createAcc = (Button) loader.getNamespace().get("createAcc");
			nameTF = (TextField) loader.getNamespace().get("nameTF");
			passTF = (TextField) loader.getNamespace().get("passTF");
			birthdayTF= (DatePicker) loader.getNamespace().get("birthdayTF");
			malecheck = (RadioButton) loader.getNamespace().get("malecheck");
			femalecheck = (RadioButton) loader.getNamespace().get("femalecheck");
			othercheck = (RadioButton) loader.getNamespace().get("othercheck");
			telematiccheck = (RadioButton) loader.getNamespace().get("telematiccheck");
			industrialcheck = (RadioButton) loader.getNamespace().get("industrialcheck");
			softwarecheck = (RadioButton) loader.getNamespace().get("softwarecheck");
			imageRute = (TextField) loader.getNamespace().get("imageRute");
			browseImage = (Button) loader.getNamespace().get("browseImage");
			Scene scene = new Scene(root, 600, 618);
			setScene(scene);
			init();
			
		} catch (Exception ex) {
			ex.printStackTrace();

		}

	}

	public void init() {
		
		
		browseImage.setOnAction(event ->{
			
			doOpenImage();
					
		});
		

		
		explorer.setOnAction(event->{
			
			browsertext.setText("EXPLORER");
			browser="EXPLORER";
		});
		chrome.setOnAction(event->{
			
			browsertext.setText("CHROME");
			browser="CHROME";
			
		});
		firefox.setOnAction(event->{
			
			browsertext.setText("FIREFOX");
			browser="FIREFOX";
		});
		
		createAcc.setOnAction(event -> {
			LocalDate date= birthdayTF.getValue();
			String gender = genderGroup();
			String career = careerGroup();
			
			ShowInformation sIn = new ShowInformation();
			students.getData().add(new Students(nameTF.getText(),passTF.getText(),gender,career,date.toString(),browser,image));
			sIn.setData(students);
			sIn.init();

			sIn.show();
			
		});
		
	

	}

	private void doOpenImage() {
		
		FileChooser fc = new FileChooser();
		fc.setTitle("Select your image");
		fc.getExtensionFilters().addAll(
				new FileChooser.ExtensionFilter("PNG", "*.png"),
				new FileChooser.ExtensionFilter("JPG", "*.jpg")
				
				); 
	
		java.io.File file = fc.showOpenDialog(this);
		if(file!=null) {
			imageRute.setText(file.getAbsolutePath());
			image = new Image ("file:"+file.getAbsolutePath());
			
		}
		
		
	}

	public String genderGroup() {
		String gender="";
		if(malecheck.isSelected()) {
			gender="Male";
		}else if(femalecheck.isSelected()) {
			gender="Female";
		}else gender="Other";
		
		return gender;
	}
	public String careerGroup() {
		String career="";
		if(telematiccheck.isSelected()) {
			career= "Telematic engineer";
		}else if (industrialcheck.isSelected()) {
			career="Industrial engineer";
		}else career="Software engineer";
		return career;
	}
	
	public void setData(StudentsData studentss) {
		students=studentss;
	}
	
	



	
}
