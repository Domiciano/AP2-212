package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Students;
import model.StudentsData;

public class ShowInformation extends Stage {

	TableView<Students> information;
	private StudentsData students;
	Label nameTF;
	Button logoutL;
	ImageView imageView;
	
	public ShowInformation() {

		try {

			FXMLLoader loader = new FXMLLoader(getClass().getResource("ShowInformation.fxml"));
			Parent root = loader.load();
			Scene scene = new Scene(root, 824, 560);
			setScene(scene);
			nameTF = (Label) loader.getNamespace().get("nameTF");
			logoutL = (Button) loader.getNamespace().get("logoutL");
			information = (TableView) loader.getNamespace().get("information");
			imageView = (ImageView) loader.getNamespace().get("imageView");
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void init() {
		// Crear las columnas
		TableColumn<Students, String> usernameCol = new TableColumn<>("USERNAME");
		TableColumn<Students, Double> genderCol = new TableColumn<>("GENDER");
		TableColumn<Students, String> careerCol = new TableColumn<>("CAREER");
		TableColumn<Students, String> birthdayCol = new TableColumn<>("BIRTHDAY");
		TableColumn<Students, String> browserCol = new TableColumn<>("BROWSER");

		// Enlaces con los elementos de la tabla
		usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
		genderCol.setCellValueFactory(new PropertyValueFactory<>("gender"));
		careerCol.setCellValueFactory(new PropertyValueFactory<>("career"));
		birthdayCol.setCellValueFactory(new PropertyValueFactory<>("birthday"));
		browserCol.setCellValueFactory(new PropertyValueFactory<>("browser"));
		information.getColumns().addAll(usernameCol, genderCol, careerCol, birthdayCol, browserCol);
		information.setItems(students.getData());
		logoutL.setOnAction(event ->{
			
			close();
			
		});
		
	}

	public void setData(StudentsData studentss) {
		students = studentss;

	}
	public void setName(String name) {
		nameTF.setText(name);
	}

	public void setImage(Image image) {
		imageView.setImage(image);
	}

	
}
