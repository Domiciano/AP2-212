package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.StudentsData;

public class LoginWindow extends Stage {

	StudentsData students;
	Button loginBtn;
	Button registerBtn;
	TextField usernameTF;
	TextField passTF;


	public LoginWindow() {

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("LoginWindow.fxml"));
			Parent root = loader.load();
			Scene scene = new Scene(root, 600, 618);
			setScene(scene);
			loginBtn = (Button) loader.getNamespace().get("loginBtn");
			registerBtn = (Button) loader.getNamespace().get("registerBtn");
			passTF = (TextField) loader.getNamespace().get("passTF");
			usernameTF = (TextField) loader.getNamespace().get("usernameTF");

			action();

		} catch (Exception ex) {
			ex.printStackTrace();

		}

	}

	public void action() {

		loginBtn.setOnAction(event -> {
			
			
			String username = usernameTF.getText();
			String password = passTF.getText();
			int ind = students.verfData(username, password);
			if (ind!=-1) {

				ShowInformation showInformation = new ShowInformation();
				showInformation.setData(students);
	
				showInformation.init();
				showInformation.show();
				showInformation.setName(username);
				showInformation.setImage(students.getData().get(ind).getImage());
				
			} else {

				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("Validation Error");
				alert.setHeaderText(null);
				alert.setContentText("Incorrect username/Password or no user created");
				alert.showAndWait();
			}

		});

		registerBtn.setOnAction(event -> {
			RegisterWindow rg = new RegisterWindow();
			rg.setData(students);
			rg.show();

		});

	}

	public void setData(StudentsData studentss) {
		students = studentss;
	}
}
