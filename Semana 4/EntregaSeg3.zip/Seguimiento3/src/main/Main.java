package main;

import javafx.application.Application;
import javafx.stage.Stage;
import model.StudentsData;
import ui.LoginWindow;

public class Main extends Application {
StudentsData students;
	public static void main(String[] args) {
		
				
		launch(args);	

	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		students=new StudentsData();
		LoginWindow login = new LoginWindow();
		login.setData(students);
		login.show();
		
	
		
	}
	
	

}
