package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class StudentsData {
	
	
	
	private ObservableList<Students> students;
	
	
	
	public StudentsData() {
		students = FXCollections.observableArrayList();

	}
	
	public ObservableList<Students> getData() {

		return students;
	}

	public int verfData(String user,String password) {
		int ver = -1;

		
		for (int i=0;i<students.size();i++) {
			
			if(students.get(i).getUsername().equals(user) && students.get(i).getPassword().equals(password)) {
				ver=i;
				break;								
			}
			
		}
		
		
		
		return ver;
	}
	
	
}
