package model;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class InfrastructureDepartment {
	public static final double maxArea = 160;
	ArrayList<Billboard> arrayBillboard; // Array to save Billboards
	String allBillboard = ""; // String var to save the readable text
	String allBillboardWithLine = ""; // String var to save the readable text with the "|"
	int totalBillboard = 0; // Var to save the amount of Billboards that are available
	int totalDangerousReports = 0; // Var to save the amount of billboards that are dangerous

	public InfrastructureDepartment() {
		arrayBillboard = new ArrayList<>();
	}

	public String addBillboard(double width, double height, boolean usage, String brand) {
		String msg = "";
		String w = Double.toString(width);
		String h = Double.toString(height);
		String u = "";
		if (usage == true) {
			u = "true";
		} else
			u = "false";

		Billboard billBoard = new Billboard(width, height, usage, brand);
		arrayBillboard.add(billBoard);
		allBillboard += w + " " + h + " " + u + " " + brand + "\n";
		allBillboardWithLine += w + "|" + h + "|" + u + "|" + brand + "\n";
		totalBillboard++;
		msg = "BILLBOARD SUCCESFULLY ADDED";
		saveBytecode(arrayBillboard);
		return msg;

	}

	public String showBillboard() {
		String msg = "";
		String amountOfBillboard = "THERE ARE: " + String.valueOf(totalBillboard) + " BillBoards";
		msg = allBillboard + "\n" + amountOfBillboard;
		return msg;
	}

	public String exportDangerousBillboardReport() {

		String report = "";
		totalDangerousReports = 0;
		for (int i = 0; i < arrayBillboard.size(); i++) {
			double area = arrayBillboard.get(i).calculateArea(arrayBillboard.get(i).getHeight(),
					arrayBillboard.get(i).getWidth());
			if (area > maxArea) {

				report += "BillBoard: " + arrayBillboard.get(i).getBrand() + " with area: " + String.valueOf(area)
						+ "\n";
				totalDangerousReports++;
			}
		}
		report += String.valueOf(totalDangerousReports);

		try {
			File f = new File("report.txt");
			FileOutputStream fos = new FileOutputStream(f);
			fos.write(report.getBytes());
			fos.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}

		return report;

	}

	public void importData() {

		try {
			File f = new File("\\Users\\dmh18\\OneDrive\\Escritorio\\Java\\Seguimiento4\\BillboardDataExported.csv");
			FileInputStream fis = new FileInputStream(f);
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader reader = new BufferedReader(isr);

			String line = reader.readLine();
			String[] separatedElements;
			int count = 0;
			double height;
			double width;
			boolean usage;

			while (line != null) {

				count++;

				separatedElements = line.split("\\|");
				if (count == 1) {
					allBillboardWithLine += separatedElements[0] + "|" + separatedElements[1] + "|"
							+ separatedElements[2] + "|" + separatedElements[3] + "\n";
					allBillboard += separatedElements[0] + "  " + separatedElements[1] + "  " + separatedElements[2]
							+ "  " + separatedElements[3] + "\n";
				}

				if (count > 1) {

					width = Double.parseDouble(separatedElements[0]);
					height = Double.parseDouble(separatedElements[1]);

					if (separatedElements[2].equals("false")) {
						usage = false;
					} else {
						usage = true;
					}

					addBillboard(width, height, usage, separatedElements[3]);

				}
				line = reader.readLine();
			}

			reader.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void saveReadable() {
		try {
			File f = new File("\\Users\\dmh18\\OneDrive\\Escritorio\\Java\\Seguimiento4\\BillboardDataExported.csv");
			FileOutputStream fos = new FileOutputStream(f);
			fos.write(allBillboardWithLine.getBytes());
			fos.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}

	public void saveBytecode(ArrayList<Billboard> arrayBillboard) {

		try {

			File f = new File("javaByteCode.tmp");
			FileOutputStream fos = new FileOutputStream(f);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(arrayBillboard);
			oos.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}
}
