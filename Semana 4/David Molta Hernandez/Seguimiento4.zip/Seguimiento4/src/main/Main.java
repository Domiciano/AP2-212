package main;


import java.util.Scanner;

import model.InfrastructureDepartment;



public class Main {

	Scanner sc;
	InfrastructureDepartment department;

	public static void main(String[] args) {
		Main m = new Main();

		m.initialMenu();
	}

	public Main() {
		sc = new Scanner(System.in);
		department = new InfrastructureDepartment();
		department.importData();
	}

	public void initialMenu() {

		int option = 0;

		do {

			System.out.println("Select an option please: " + "\n" + "1. Add billboard" + "\n" + "2. Show billboards"
					+ "\n" + "3. Export dangerous report" + "\n" + "0. Exit");

			option = sc.nextInt();
			sc.nextLine();
			switch (option) {

			case 1:
				addBillboard();
				department.saveReadable();
				
				break;
			case 2:
				showBillboard();
				break;
			case 3:
				exportReport();
				break;
			case 0:
				break;

			}

		} while (option != 0);

	}

	public void addBillboard() {
		String billBoard = "";
		System.out.println(
				"Enter the width, height, true or false depending of it's usage and finally the name of the brad. Separate this with ++ "
						+ "\n" + "For example: " + "300++600++true++Netflix");
		billBoard = sc.nextLine();
		String [] array = billBoard.split("\\+\\+");
		double w = Double.parseDouble(array[0]);
		double h = Double.parseDouble(array[1]);
		boolean iU=true;
		if(array[2].equals("false")) {
			iU = false;
		}
		System.out.println(department.addBillboard(w, h, iU, array[3]));

	}

	public void showBillboard() {
		System.out.println(department.showBillboard());
	}

	public void exportReport() {
		System.out.println(department.exportDangerousBillboardReport());
	}

}