package ui;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		

		Scanner sc = new Scanner(System.in);
		
		int option = 0;
		while(option !=4){
			System.out.println("============");
			System.out.println("DANGEROUS BILLBOARD REPORT");
			System.out.println("============");
			System.out.println("1. Billboard <POSTOBON>");
			System.out.println("2. Billboard <RCN>");
			System.out.println("3. Billboard <CARACOL>");
			System.out.println("4. Exit");
			System.out.print("Enter the option: ");
		
			option = sc.nextInt();
			
			switch(option){
				case 1:
				break;
				case 2:
				break;
				case 3:
				break;

				case 4:
					System.out.println("Thank you for using this program. Good bye!");
				break;

				default:
					System.out.println("The option "+option+" there is not in the menu");
				break;
			}
		
		}

	}

}
