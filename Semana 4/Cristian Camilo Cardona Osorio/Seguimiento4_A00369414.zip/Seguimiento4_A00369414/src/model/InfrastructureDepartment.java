package model;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class InfrastructureDepartment {

	private Billboard billboard;
	
	private final double DANGERLIMIT = 160;

	public InfrastructureDepartment() {

	}

	public void addBillboard(double width, double height, boolean inUse, String brand) {

		Billboard billboard = new Billboard(width, height, inUse, brand);

		ListBillboard.getData().add(billboard);

	}
	
	private void saveBillboard() {
		
		try {
			Billboard board = new Billboard(ListBillboard.getData());
			
			File ref = new File("Jbc.temp");
			
			FileOutputStream fos = new FileOutputStream(ref);
			
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			
			oos.writeObject(board);
			
			oos.close();
			
			}catch(IOException ex) {
				ex.printStackTrace();
			}
	}
	
	private void loadBillboar() {
		
		try {
			File f = new File("jbc.txt");
			
			FileInputStream fis = new FileInputStream(f);
			ObjectInputStream ois = new ObjectInputStream(fis);
			Billboard billboard = (Billboard) ois.readObject();
			
					
		}catch(IOException ex) {
			ex.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	}

	public void exportDangerousBillboardReport() {
		
		try {
			
			String danger = "DANGEROUS BILLBOARD REPORT";

			for (int i = 0; i < ListBillboard.getData().size(); i++) {

				double area = ListBillboard.getData().get(i).calculateArea();

				if (area > DANGERLIMIT) {

					String b = ListBillboard.getData().get(i).getBrand();

					danger += "\nBildboard: " + b + " with area: " + area + "\n";

				}
			}


			File ref = new File("DangerReport.txt");
			
			FileOutputStream fos = new FileOutputStream(ref);
			
			fos.write(danger.getBytes());
			
			System.out.println(danger);
			
			fos.close();
			
			
			} catch(IOException ex) {
				ex.printStackTrace();
				
			}
	}

	public void importData() {
		try {
			File file = new File(
			"C:\\Users\\cardo\\OneDrive\\Escritorio\\ICESI Semestre III\\APOII\\Seguimiento4_A00369414\\BillboardDataExported.csv");
			FileInputStream fis = new FileInputStream(file);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			int leidos = 0;

			byte[] buffer = new byte[128];

			while ((leidos = fis.read(buffer)) != -1) {
				baos.write(buffer, 0, leidos);

			}

			fis.close();
			baos.close();

			String cvc = baos.toString();
			System.out.println(cvc);

		} catch (FileNotFoundException e) {
			e.printStackTrace();

		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

}
