package model;

import java.util.ArrayList;

public class ListBillboard {
	
	private static ArrayList<Billboard> billb = new ArrayList<>();
	
	public static ArrayList<Billboard> getData(){
		
		return billb;
	}
}
