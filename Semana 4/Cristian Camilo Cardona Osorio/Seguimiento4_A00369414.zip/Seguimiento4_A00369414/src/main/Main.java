package main;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import model.Billboard;
import model.InfrastructureDepartment;
import model.ListBillboard;

public class Main {

	private Scanner sc = new Scanner(System.in);

	private InfrastructureDepartment deparment;

	

	public Main() {

		deparment = new InfrastructureDepartment();
	}

	public static void main(String[] args) {

		Main main = new Main();
		main.menu();

	}

	public void menu() {

		int option = 0;
		int menuOption = 1;
		do {
			System.out.println(" MENU BILLBOARD");
			System.out.println("1. Add a billboard");
			System.out.println("2. Show billboards");
			System.out.println("3. Show dangerous billboard reports");
			System.out.println("0. Close");

			System.out.print(" Choose an option: ");
			option = sc.nextInt();
			sc.nextLine();
			System.out.println();

			switch (option) {

			case 1:
				System.out.println("___________________________________________________________________________");
				addedBillboard();
				break;

			case 2:
				System.out.println("___________________________________________________________________________");
				showBillboard();
				System.out.println("___________________________________________________________________________");
				break;

			case 3:
				System.out.println("___________________________________________________________________________");
				dangerousBillboard();

				break;

			}
		} while (menuOption != 0);

	}

	public void dangerousBillboard() {
		
		deparment.exportDangerousBillboardReport();
		
	}

	public void showBillboard() {
		
		deparment.importData();

		String show = "w        h        Use        Brand";

		for (int i = 0; i < ListBillboard.getData().size(); i++) {

			double w = ListBillboard.getData().get(i).getWidth();

			double h = ListBillboard.getData().get(i).getHeight();

			boolean us = ListBillboard.getData().get(i).isInUse();

			String b = ListBillboard.getData().get(i).getBrand();

			show += "\n" + w + "    " + h + "    " + us + "    " + b + "\n";

		}

		System.out.println(show);

	}

	public void addedBillboard() {

		System.out.println("Please enter the data of the billboard: ");

		System.out.print("width: ");
		double width = sc.nextDouble();
		sc.nextLine();

		System.out.print("height: ");
		double height = sc.nextDouble();
		sc.nextLine();

		boolean inUse = true;

		System.out.println("Is the billboar in use?");
		System.out.println("1. YES");
		System.out.println("2. NO");
		System.out.print("Choose an option: ");
		int option2 = sc.nextInt();
		sc.nextLine();

		switch (option2) {
		case 1:
			inUse = true;
			break;
		case 2:
			inUse = false;
			break;

		default:
			System.out.println("Error. invalid option");

		}

		System.out.print("Billboard brand: ");
		String brand = sc.nextLine();

		deparment.addBillboard(width, height, inUse, brand);

		System.out.println("Billboard added succesfully\n");

	}

}
