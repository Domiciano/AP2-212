package model;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class InfrastructureDepartment {
	
	ArrayList<Billboard> Billboard= new ArrayList<>();
	String mostrarBillboard;

	public InfrastructureDepartment() {
		
		// TODO Auto-generated constructor stub
	} 
	
	public void addBillboard(double width, double height, boolean inUse, String brand) {
		Billboard Billboard1= new Billboard(width,height,inUse,brand);
		Billboard.add(Billboard1);
		guardarBytecode(Billboard);
	}

	private void guardarBytecode(ArrayList<model.Billboard> Billboard) {
		// TODO Auto-generated method stub
		try {
		File file = new File("javaByteCode.tmp");
		FileOutputStream fis= new FileOutputStream(file);
		ObjectOutputStream baos= new ObjectOutputStream(fis);
		baos.writeObject(Billboard);
		baos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void guardarReadable(){
		try {
		File file= new File("C:\\Users\\Public\\Seguimiento4\\BillboardDataExported.csv");
		FileOutputStream fis= new FileOutputStream(file);
		fis.write(mostrarBillboard.getBytes());
		fis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void importData() {
		try {
			File file = new File("C:\\Users\\Public\\Seguimiento4\\BillboardDataExported.csv");
			FileInputStream fis = new FileInputStream(file);
			InputStreamReader fos= new InputStreamReader(fis);
			BufferedReader baos = new BufferedReader(fos); 
			
			String lineaLectura = baos.readLine();
			String[] estoSepara;
			double width=0;
			double height=0;
			boolean inUse;
			while (lineaLectura != null) {
				estoSepara= lineaLectura.split("\\|");
				mostrarBillboard+= estoSepara[0]+""+ estoSepara[1]+""+estoSepara[2]+""+estoSepara[3]+"\n";
				width=Double.parseDouble(estoSepara[0]);
				height= Double.parseDouble(estoSepara[1]);
				if(estoSepara[2].equals("true")) {
					inUse= true;
					
				}else {
					inUse=false;
				}
				
				addBillboard(width,height,inUse,estoSepara[3]);
				lineaLectura= baos.readLine();
				
			}
			baos.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public String export() {
	
	String finalReport="";
	for(int i=0; i< Billboard.size();i++) {
		double a= Billboard.get(i).getWidth();
		double b=Billboard.get(i).getHeight();
		double area = a*b;
		if(area >160) {
			finalReport += "=======Billboards con area mayor a 160 m2========\n"+
		"Billboard de "+ Billboard.get(i).getBrand()+ " Con area de "+ String.valueOf(area)+"\n";
		}
		try {
		File file= new File("report.txt");
		FileOutputStream fos= new FileOutputStream(file);
		fos.write(finalReport.getBytes());
		fos.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
		
				
	}
	return finalReport;
	}
	
	
	
	public String showBillboards() {
		String fina;
		fina= mostrarBillboard;
		return fina;
	}
}


