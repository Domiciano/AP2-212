import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import model.InfrastructureDepartment;

public class Main {

	Scanner reader;
	InfrastructureDepartment relationInfra;
	public static void main(String[] args) {
		Main a= new Main();
		a.menu();
	
	}
	public Main() {
		reader= new Scanner(System.in);
		relationInfra= new InfrastructureDepartment();
	}
	public void menu() {
		// TODO Auto-generated method stub
		int option =0; 
		System.out.println("Bienvenido al men� de vallas publicitarias\n"+
		"Selecciona una Opcci�n\n"+
		"(1) Agregar una valla publicitaria\n"+
		"(2) Mostrar vallas publicitarias\n"+
		"(3) Exportar reporte de vallas peligrosas\n"+
		"(4) Salir\n");
		option= reader.nextInt();
		switch(option) {
		case 1:
		add();
		
		break;
		case 2:
			System.out.println(relationInfra.showBillboards());
			menu();
		break;
		case 3:
			System.out.println(relationInfra.export());
			menu();
		break;
		case 4:
		System.out.println("Adios");	
		break; 
		}
	}
	public void add() {
		// TODO Auto-generated method stub
		double width= 0;
		double height=0;
		boolean inUse;
		String brand;
		System.out.println("Digita el ancho");
		width=reader.nextInt();
		reader.nextLine();
		System.out.println("Digita la altura");
		height= reader.nextInt();
		reader.nextLine();
		System.out.println("Digita la marca");
		brand= reader.nextLine();
		
		
		relationInfra.addBillboard(width,height,true,brand);
		System.out.println("La valla publicitaria ha sido registrada");
		menu();
	}
	

}
