package model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CountryData {

	ArrayList<Country> countries;
	ArrayList<Country> cloneCountriesBubble;

	public CountryData(){
		cloneCountriesBubble = new ArrayList<>();
		countries = new ArrayList<>();
	}

	public ArrayList<Country> getCountries() {
		return countries;
	}

	public ArrayList<Country> getCloneCountriesBubble() {
		return cloneCountriesBubble;
	}

	public void setCountries(ArrayList<Country> countries) {
		this.countries = countries;
	}

	public void printDataMale() {

		for(Country c: countries) {
			System.out.println(c.toStringMale());
		}

	}
	public void printDataFemale() {
		for(Country c : countries) {
			System.out.println(c.toStringFemale());
		}
	}

	public void compareCountry () {
		Comparator<Country> comparator = (o1,o2)->{
			int a = o1.getMaleGold()-o2.getMaleGold();
			if(a==0) {
				int b = o1.getMaleSilver() - o2.getMaleSilver();
				if(b==0) {
					int c = o1.getMaleSilver()- o2.getMaleSilver();
					return -c;
				} else return -b;
			}else return -a;

		};
		Collections.sort(countries,comparator);
	}

	public void sortWithBubble(){
		for(int i=0;i<countries.size();i++){
			String name = countries.get(i).getName();
			int maleGold = countries.get(i).getMaleGold();
			int maleSilver= countries.get(i).getMaleSilver();
			int maleBronze= countries.get(i).getMaleBronze();
			int femaleGold= countries.get(i).getFemaleGold();
			int femaleSilver= countries.get(i).getFemaleSilver();
			int femaleBronze= countries.get(i).getFemaleBronze();
			Country country = new Country(name,maleGold+femaleGold,maleSilver+femaleSilver,maleBronze+femaleBronze);
			cloneCountriesBubble.add(country);
		}

		for(int i=0; i<cloneCountriesBubble.size(); i++){
			for(int j=i + 1; j<cloneCountriesBubble.size(); j++){
				if((cloneCountriesBubble.get(i).getTotalGold() - cloneCountriesBubble.get(j).getTotalGold())<0){
					Country temp = cloneCountriesBubble.get(i);
					cloneCountriesBubble.set(i,cloneCountriesBubble.get(j));
					cloneCountriesBubble.set(j,temp);
				}else if((cloneCountriesBubble.get(i).getTotalGold() - cloneCountriesBubble.get(j).getTotalGold())==0){
					if((cloneCountriesBubble.get(i).getTotalSilver()-cloneCountriesBubble.get(j).getTotalSilver())<0){
						Country temp1 = cloneCountriesBubble.get(i);
						cloneCountriesBubble.set(i,cloneCountriesBubble.get(j));
						cloneCountriesBubble.set(j,temp1);
					}else if((cloneCountriesBubble.get(i).getTotalSilver()-cloneCountriesBubble.get(j).getTotalSilver())==0){
						if((cloneCountriesBubble.get(i).getTotalBronze()-cloneCountriesBubble.get(j).getFemaleBronze())<0){
							Country temp2 = cloneCountriesBubble.get(i);
							cloneCountriesBubble.set(i,cloneCountriesBubble.get(j));
							cloneCountriesBubble.set(j,temp2);
						}else if((cloneCountriesBubble.get(i).getTotalBronze()-cloneCountriesBubble.get(j).getFemaleBronze())==0){
							if((cloneCountriesBubble.get(i).getName().compareTo(cloneCountriesBubble.get(j).getName()))<0){
								Country temp3 = cloneCountriesBubble.get(i);
								cloneCountriesBubble.set(i,cloneCountriesBubble.get(j));
								cloneCountriesBubble.set(j,temp3);

							}
						}
					}
				}
			}
		}

		for(Country country : cloneCountriesBubble){
			System.out.println(country.toStringTotal());
		}
	}

	public void sortWithInsertion(){

		for(int a = 1; a< cloneCountriesBubble.size(); a++){
			for(int b=0;b<a;b++){
				Country vA = cloneCountriesBubble.get(a);
				Country vB = cloneCountriesBubble.get(b);
				if(vA.getTotalGold()>vB.getTotalGold()){
					cloneCountriesBubble.remove(a);
					cloneCountriesBubble.add(b,vA);
				}else if((vA.getTotalGold()- vB.getTotalGold())==0){

					if(vA.getTotalSilver()>vB.getTotalSilver()){
						cloneCountriesBubble.remove(a);
						cloneCountriesBubble.add(b,vA);

					}else if((vA.getTotalSilver()- vB.getTotalSilver())==0){

						if((vA.getTotalBronze()> vB.getTotalBronze())){

							cloneCountriesBubble.remove(a);
							cloneCountriesBubble.add(b,vA);

						}else if((vA.getName().compareTo(vB.getName()))<0){

							cloneCountriesBubble.remove(a);
							cloneCountriesBubble.add(b,vA);
						}
					}
				}
			}
		}
		for(Country country : cloneCountriesBubble){
			System.out.println(country.toStringTotal());
		}
	}
}