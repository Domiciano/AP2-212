package main;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

import model.Country;
import model.CountryData;

public class Main {
	
	Scanner sc;
	String [] infoString;
	CountryData countryData;

	public Main() {
		sc = new Scanner(System.in);
		countryData = new CountryData();
	}

	public static void main(String[] args) {
		Main principal = new Main();

		int option;

		do{
			option = principal.menu();
			principal.execute(option);
		}while(option != 0);
	}

	public int menu(){
		System.out.println("Choose a num\n" +
				"1. Enter data\n" +
				"2. Show test\n" +
				"0. Get out\n");
		int option = sc.nextInt();
		sc.nextLine();

		return option;
	}

	public void execute(int option){
		switch(option){
			case 1:
				enterData();
				break;
			case 2:
				showTest();
				break;
			case 0:
				System.exit(0);
				break;
		}
	}

	public void enterData() {
		System.out.println("Enter the number of countries that you will register: ");
		int op = sc.nextInt();
		sc.nextLine();
		
		for (int i =0; i<op;i++) {
			System.out.println("Countryname;GoldMaleMedals;SilverMaleMedal;BronzeMaleMedal;GoldFemaleMedals;SilverFemaleMedal;BronzeFemaleMedal");
			String information = sc.nextLine();
			infoString = information.split(";");
			Country object = new Country(infoString[0],Integer.parseInt(infoString[1]),Integer.parseInt(infoString[2]),Integer.parseInt(infoString[3]),Integer.parseInt(infoString[4]),Integer.parseInt(infoString[5]),Integer.parseInt(infoString[6]));
			countryData.getCountries().add(object);			
		}

		printDataMale();
		printDataFemale();
		printSumData();
	}

	public void showTest(){
		String [] firstSplit = readFile().split("-");

		for(String country: firstSplit){
			String [] secondSplit = country.split(";");
			Country obj = new Country(secondSplit[0], Integer.parseInt(secondSplit[1]), Integer.parseInt(secondSplit[2]), Integer.parseInt(secondSplit[3]), Integer.parseInt(secondSplit[4]), Integer.parseInt(secondSplit[5]), Integer.parseInt(secondSplit[6]));
			countryData.getCountries().add(obj);
		}

		printDataMale();
		printDataFemale();
		printSumData();
	}

	public String readFile(){
		try {
			File file = new File("src/data/test.txt");
			FileInputStream fis = new FileInputStream(file);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			byte[] buffer = new byte[120];
			int bytesQuePudeLeer = 0;

			while((bytesQuePudeLeer = fis.read(buffer)) != -1){
				baos.write(buffer, 0, bytesQuePudeLeer);
			}
			fis.close();
			baos.close();

			String lectura = baos.toString();

			return lectura;
		} catch(IOException ex) {
			ex.printStackTrace();

			return "";
		}
	}

	public void printDataMale() {
		System.out.print("Male" + "\n");
		countryData.compareCountry();
		countryData.printDataMale();
		System.out.println("----------");
	}
	
	public void printDataFemale() {
		System.out.println("Female");
		Collections.sort(countryData.getCountries());
		countryData.printDataFemale();
		System.out.println("----------");
	}

	private void printSumData() {
		System.out.println("Total medals");
		countryData.sortWithBubble();
		System.out.println("----------");
		System.out.println("Total medals insertion");
		countryData.sortWithInsertion();
		System.out.println("----------");
	}
}
