package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Classroom {

	private ObservableList<UserAccount> account;
	
	public Classroom() {
		
		account = FXCollections.observableArrayList();
	}
	
	public ObservableList<UserAccount> getData(){
		return account;
	}
	
	public boolean searchAccount(String user, String pass) {
		boolean logIn=false;
		boolean continuar=true;
		
		for(int i=0; i<account.size() && continuar; i++) {
			UserAccount a= account.get(i);
			if(a!=null) {
				if(a.getUsername().equals(user)) {
					if(a.getPassword().equals(pass)) {
						logIn=true;
						continuar=false;
					}
				}else {
					continuar=false;
				}
			}else {
				continuar=false;
			}
		}
		return logIn;
		
	}
}
