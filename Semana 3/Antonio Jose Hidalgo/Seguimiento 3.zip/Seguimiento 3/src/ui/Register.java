package ui;

import java.io.File;
import java.time.format.DateTimeFormatter;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Classroom;
import model.UserAccount;

public class Register extends Stage {
	 
	    private TextField userField;

	    private TextField passField;

	    private TextArea pfpField;
	    
	    private Button pfpBT;
	    
	    private RadioButton maleOP;

	    private RadioButton femaleOP;

	    private RadioButton otherOP;

	    private TextField careerField;

	    private DatePicker birthdayField;
	    
	    private TextField bowserField;
	    
	    private Button okBT;

	public Register() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Register.fxml"));
            Parent parent = loader.load();
            
            userField = (TextField) loader.getNamespace().get("userField");
            passField =(TextField) loader.getNamespace().get("passField");
            careerField =(TextField) loader.getNamespace().get("careerField");
            bowserField =(TextField) loader.getNamespace().get("bowserField");
            pfpField =(TextArea) loader.getNamespace().get("pfpField");
            
            pfpBT =(Button) loader.getNamespace().get("pfpBT");
            okBT =(Button) loader.getNamespace().get("okBT");
            
            maleOP =(RadioButton) loader.getNamespace().get("maleOP");
            femaleOP =(RadioButton) loader.getNamespace().get("femaleOP");
            otherOP =(RadioButton) loader.getNamespace().get("otherOP");
            
            final ToggleGroup group = new ToggleGroup();

            maleOP.setToggleGroup(group);
            maleOP.setSelected(true);

            femaleOP.setToggleGroup(group);
             
            otherOP.setToggleGroup(group);
            
            birthdayField = (DatePicker) loader.getNamespace().get("birthdayField");
            
            
            Scene scene = new Scene(parent, 300, 400);
            setScene(scene);

            init();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

	private void init() {
		
		
		pfpBT.setOnAction(event->{
			searchPfp();
		});
		
		okBT.setOnAction(event->{
			signIn();
		});
		
	}

	private void signIn() {
		
		String user="";
		String pass="";
		String pfp="";
		String gender="";
		String career="";
		String birth="";
		String browser="";
		
		user = userField.getText();
		if(passField.getText()!=null) {
			pass = passField.getText();
		}
		pfp = pfpField.getText();
		if(birthdayField.getValue()!=null) {
			birth = birthdayField.getValue().toString();
		}
		
		if(maleOP.selectedProperty()!=null) {
			
			gender="male";
			
		}else if(femaleOP.selectedProperty()!=null) {
			
			gender="female";
			
		}else if(otherOP.selectedProperty()!=null) {
			
			gender="other";
		}
		
		career = careerField.getText();
		
		browser = bowserField.getText();
		
		System.out.println(birth);
		
		if(user!=null && user!="" && pass!=null && pass!="" && pfp!=null&& pfp!="" && gender!="" && gender!=null && career!="" && career!=null && birth!="" && browser!="" && browser!=null) {
			System.out.println("el ajiaco");
			UserAccount account= new UserAccount(user, pass, pfp, gender, career, birth, browser);
			Main.classroom.getData().add(account);
			
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("registration complete");
			alert.setHeaderText(null);
			alert.setContentText("information saved correctly");

			alert.showAndWait();
			
			Stage stage = (Stage) okBT.getScene().getWindow();
		 
		    stage.close();
		}else {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("registration error");
			alert.setHeaderText(null);
			alert.setContentText("Pls fill all the fields");

			alert.showAndWait();
		}
		
	}

	private String searchPfp() {
		
		String image="";
		
		FileChooser fc = new FileChooser();
		fc.setTitle("Abrir imagen");
		fc.getExtensionFilters().addAll(
		
			new FileChooser.ExtensionFilter("PNG", "*.png"),
			new FileChooser.ExtensionFilter("JPG", "*.jpg"),
			new FileChooser.ExtensionFilter("JPEG", "*.jpeg")
			
		);
		
		File file = fc.showOpenDialog(this);
		System.out.println(file.exists());
		
		if(file != null) {
			image= file.getAbsolutePath();
			pfpField.setText(image);
		}
		
		return image;
	}

}
