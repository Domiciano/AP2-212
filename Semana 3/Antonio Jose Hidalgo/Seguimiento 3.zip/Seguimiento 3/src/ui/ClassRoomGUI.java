package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import model.Classroom;

public class ClassRoomGUI extends Stage {
	
	private Button logBT, signBT;
	private TextField userField;
	private PasswordField passField;
	
	public ClassRoomGUI() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("LogIn.fxml"));
            Parent parent = loader.load();
            
            logBT = (Button) loader.getNamespace().get("logBT");
            signBT = (Button) loader.getNamespace().get("signBT");
            
            userField =(TextField) loader.getNamespace().get("userField");
            passField =(PasswordField) loader.getNamespace().get("passField");

            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

	private void init() {
		
		logBT.setOnAction(event->{
			logIn();
		});
		
		signBT.setOnAction(event->{
			signIn();
		});
		
	}

	private void signIn() {
		Register window = new Register();
		window.show();
		
	}

	private void logIn() {
		String user=userField.getText();
		String pass= passField.getText();
		boolean check = Main.classroom.searchAccount(user, pass);
		
		if(check) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("log in");
			alert.setHeaderText(null);
			alert.setContentText("log in succesful");

			alert.showAndWait();
			
			Grafica window = new Grafica();
			window.show();
			
			Stage stage = (Stage) logBT.getScene().getWindow();
			 
		    stage.close();
			
		}else{
			System.out.println("a");
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle("log in error");
			alert.setHeaderText(null);
			alert.setContentText("User or password are wrong");

			alert.showAndWait();
		}
		
	}

}
