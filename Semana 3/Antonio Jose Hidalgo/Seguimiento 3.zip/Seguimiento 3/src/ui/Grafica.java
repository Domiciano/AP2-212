package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Classroom;
import model.UserAccount;

public class Grafica extends Stage{
	
	private TableView<UserAccount> tableV;
	Button closeBT;
	
	
	
	public Grafica(){
		try {
        	FXMLLoader loader = new FXMLLoader(getClass().getResource("Grafica.fxml"));
        	Parent parent = loader.load();
        	
        	tableV = (TableView) loader.getNamespace().get("tableV");
			closeBT = (Button) loader.getNamespace().get("closeBT");
			
			TableColumn<UserAccount, String> usercol = new TableColumn<>("username");
			TableColumn<UserAccount, String> gendercol = new TableColumn<>("gender");
			TableColumn<UserAccount, String> careercol = new TableColumn<>("career");
			TableColumn<UserAccount, String> birthdaycol = new TableColumn<>("birthday");
			TableColumn<UserAccount, String> browsercol = new TableColumn<>("browser");
			
			usercol.setCellValueFactory(new PropertyValueFactory<>("username"));
			gendercol.setCellValueFactory(new PropertyValueFactory<>("gender"));
			careercol.setCellValueFactory(new PropertyValueFactory<>("career"));
			birthdaycol.setCellValueFactory(new PropertyValueFactory<>("birthday"));
			browsercol.setCellValueFactory(new PropertyValueFactory<>("browser"));
			
			tableV.getColumns().addAll(usercol, gendercol, careercol, birthdaycol, browsercol);
			tableV.setItems(Main.classroom.getData());
        
        	Scene scene = new Scene(parent, 600, 400);
        	setScene(scene);

        	init();
    	} catch (Exception ex) {
        	ex.printStackTrace();
    	}
	}
	
	private void init() {
		
		closeBT.setOnAction(event->{
			ClassRoomGUI window = new ClassRoomGUI();
			window.show();
			
			Stage stage = (Stage) closeBT.getScene().getWindow();
			 
		    stage.close();
		});
		
	}
}
