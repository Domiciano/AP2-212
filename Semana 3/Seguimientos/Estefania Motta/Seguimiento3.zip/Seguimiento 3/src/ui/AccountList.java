package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import model.Classroom;
import model.UserAccount;

public class AccountList extends Stage{
	

	private TableView<UserAccount> tableTV;
	private Button logOutBtn;
	
	
	private Classroom accounts;
	
	public AccountList() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("AccountList.fxml"));
            Parent parent = loader.load();
            
            tableTV = (TableView) loader.getNamespace().get("tableTV");
            logOutBtn = (Button) loader.getNamespace().get("logOutBtn");

            accounts = new Classroom();
            
            TableColumn<UserAccount, String> usernameCol = new TableColumn<>("Username");
			TableColumn<UserAccount, String> genderCol = new TableColumn<>("Gender");
			TableColumn<UserAccount, String> careerCol = new TableColumn<>("Career");
			TableColumn<UserAccount, String> birthdayCol = new TableColumn<>("Birthday");
			TableColumn<UserAccount, String> browserCol = new TableColumn<>("Browser");
			
			usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
			genderCol.setCellValueFactory(new PropertyValueFactory<>("gender"));
			careerCol.setCellValueFactory(new PropertyValueFactory<>("career"));
			birthdayCol.setCellValueFactory(new PropertyValueFactory<>("birthday"));
			browserCol.setCellValueFactory(new PropertyValueFactory<>("favoriteBrowser"));
			
			
			tableTV.getColumns().addAll(usernameCol, genderCol, careerCol, birthdayCol, browserCol);
			tableTV.setItems(accounts.getData());
            
            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void init() {
		logOutBtn.setOnAction(event ->{
			System.exit(0);
    	});
		
    }
}