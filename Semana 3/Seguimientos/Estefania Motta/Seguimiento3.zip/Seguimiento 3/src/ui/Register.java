package ui;

import java.io.File;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.*;

public class Register extends Stage{
	
	private TextField userNameTF;
	private PasswordField passwordPF;
	private TextField photoTF;
	private Button browseBtn;
	private RadioButton maleRB;
	private RadioButton femaleRB;
	private RadioButton otherRB;
	private CheckBox sofwareCB;
	private CheckBox telematicCB;
	private CheckBox industrialCB;
	private DatePicker birthdayDP;
	private ChoiceBox browserChB;
	private Button signinBtn;
	private Button createBtn;
	
	
	public Register() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("Register.fxml"));
            Parent parent = loader.load();
            
            userNameTF = (TextField) loader.getNamespace().get("userNameTF");
            passwordPF = (PasswordField) loader.getNamespace().get("passwordPF");
            photoTF = (TextField) loader.getNamespace().get("photoTF");
            browseBtn = (Button) loader.getNamespace().get("browseBtn");
            maleRB = (RadioButton) loader.getNamespace().get("maleRB");
            femaleRB = (RadioButton) loader.getNamespace().get("femaleRB");
            otherRB = (RadioButton) loader.getNamespace().get("otherRB");
            sofwareCB = (CheckBox) loader.getNamespace().get("sofwareCB");
            telematicCB = (CheckBox) loader.getNamespace().get("telematicCB");
            industrialCB = (CheckBox) loader.getNamespace().get("industrialCB");
            birthdayDP = (DatePicker) loader.getNamespace().get("birthdayDP");
            browserChB = (ChoiceBox) loader.getNamespace().get("browserChB");
            signinBtn = (Button) loader.getNamespace().get("signinBtn");
            createBtn = (Button) loader.getNamespace().get("createBtn");

            Scene scene = new Scene(parent, 600, 400);
            setScene(scene);

            init();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void init() {
		browseBtn.setOnAction(event ->{
			doBrowseBtn();
    	});
    	
		signinBtn.setOnAction(event ->{
			doSigninBtn();
    	});
		createBtn.setOnAction(event ->{
			
			String userName = userNameTF.getText();
			String password = passwordPF.getText();
			String profilePhoto = photoTF.getText();
			String gender = "";
			if(maleRB.isSelected()) {
				gender = "Male";
			}
			else if(femaleRB.isSelected()) {
				gender = "Female";
			}
			else if(otherRB.isSelected()) {
				gender = "Other";
			}
			String career = "";
			if(sofwareCB.isSelected()) {
				career = "Sofware Engineering";
			}
			else if(telematicCB.isSelected()) {
				career = "Telematic Engineering";
			}
			else if(industrialCB.isSelected()) {
				career = "Industrial Engineering";
			}
			String birthday = birthdayDP.getValue().toString();
			String favoriteBrowser = browserChB.getValue().toString();
			
			UserAccount account = new UserAccount(userName, password, profilePhoto, gender, career, birthday, favoriteBrowser);
			
			Main.classroom.getData().add(account);
			
			System.out.println("Data:"+Main.classroom.getData().size());
    	});
    }
	private void doBrowseBtn() {
		FileChooser fc = new FileChooser();
    	fc.setTitle("Browse Image");
    	fc.getExtensionFilters().addAll(
    			new FileChooser.ExtensionFilter("PNG", "*.png"),
    			new FileChooser.ExtensionFilter("JPG", "*.jpg")
    	);	
    	File file = fc.showOpenDialog(this);
    	if(file != null) {
    		String image = new String("file:"+file.getAbsolutePath());
    		photoTF.setId(image);
    	}
	}
	private void doSigninBtn() {
		Login Login = new Login();
		Login.show();
	}
}