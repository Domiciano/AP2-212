package model;

import java.util.ArrayList;

import javafx.collections.ObservableList;

public class Classroom {

	private ArrayList <UserAccount> accounst;
	
	public Classroom() {
		accounst = new ArrayList<UserAccount>();
	}
	public UserAccount searchUser(String userName, String password) {
		UserAccount search = null;
		boolean find = false;
		for(int i=0;i<accounst.size()&&!find==false;i++) {
			UserAccount user = accounst.get(i);
			if(user.getUserName().equals(userName)){
				if(password.equals(user.getPassword())) {
					search = accounst.get(i);
				}
			}
		}
		return search;
	}
	public ObservableList<UserAccount> getData() {
		return (ObservableList<UserAccount>) accounst;
	}
}