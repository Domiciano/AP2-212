package model;

public class UserAccount {
	//Attributes
	private String userName = "";
	private String password = "";
	private String profilePhoto = "";
	private String gender = "";
	private String career = "";
	private String birthday;
	private String favoriteBrowser = "";
	//Constants
	public static final String GENDER1 = "Male";
	public static final String GENDER2 = "Female";
	public static final String GENDER3 = "Other";
	public static final String CAREER1 = "Sofware Engineering";
	public static final String CAREER2 = "Telematic Engineering";
	public static final String CAREER3 = "Industrial Engineering";
	public static final String BROWSER1 = "Chrome";
	public static final String BROWSER2 = "Explorer";
	public static final String BROWSER3 = "Firefox";
	public static final String BROWSER4 = "Edge";
	//Methods
	public UserAccount(String pUserName, String pPassword, String pProfilePhoto, String pGender, String pCareer, String pBirthday, String pFavoriteBrowser){
		userName = pUserName;
		password = pPassword;
		profilePhoto = pProfilePhoto;
		gender = pGender;
		career = pCareer;
		birthday = pBirthday;
		favoriteBrowser = pFavoriteBrowser;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getProfilePhoto() {
		return profilePhoto;
	}
	public void setProfilePhoto(String profilePhoto) {
		this.profilePhoto = profilePhoto;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCareer() {
		return career;
	}
	public void setCareer(String career) {
		this.career = career;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getFavoriteBrowser() {
		return favoriteBrowser;
	}
	public void setFavoriteBrowser(String favoriteBrowser) {
		this.favoriteBrowser = favoriteBrowser;
	}
}