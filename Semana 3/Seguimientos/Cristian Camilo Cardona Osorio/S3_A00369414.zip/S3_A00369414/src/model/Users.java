package model;

public class Users {

	private String userName;
	private String password;
	private String gender;
	private String career;
	private String birthday;
	private String photo;

	public Users() {

	}

	public Users(String userName,String password, String gender, String career, String birthday, String photo) {
		this.userName = userName;
		this.password = password;
		this.gender = gender;
		this.career = career;
		this.birthday = birthday;
		this.photo = photo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCareer() {
		return career;
	}

	public void setCareer(String career) {
		this.career = career;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	
	public String getPhoto() {
		return photo;
	}

	public void setPhoto(String photo) {
		this.photo = photo;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
