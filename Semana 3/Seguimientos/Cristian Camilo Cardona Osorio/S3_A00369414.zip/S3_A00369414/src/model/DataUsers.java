package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DataUsers {

	private static ObservableList<Users> users = FXCollections.observableArrayList();


	public static ObservableList<Users> getData() {
		return users;
	}
}
