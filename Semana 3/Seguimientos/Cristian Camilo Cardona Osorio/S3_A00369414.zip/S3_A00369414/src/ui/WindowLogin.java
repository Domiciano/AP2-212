package ui;

import java.io.File;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.DataUsers;
import model.Users;

public class WindowLogin extends Stage {

	/// Text Field Components

	private TextField usTF;
	private TextField passTF;
	private TextField photoTF;

	/// Radio Button gender

	private RadioButton maleRB;
	private RadioButton femaleRB;
	private RadioButton othRB;

	/// CheckBox Career

	private CheckBox softCHB;
	private CheckBox telCHB;
	private CheckBox indCHB;

	/// Buttons

	private Button browBTN;
	private Button singBTN;
	private Button createBTN;

	/// Calendar

	private DatePicker birthDT;

	//// favorite browser

	private ChoiceBox favbrowCB;

	public WindowLogin() {

		try {

			FXMLLoader loader = new FXMLLoader(getClass().getResource("WindowLogin.fxml"));
			Parent root = loader.load();

			Scene scene = new Scene(root, 600, 400);
			setScene(scene);

			///// Text Fields Components
			usTF = (TextField) loader.getNamespace().get("usTF");
			passTF = (TextField) loader.getNamespace().get("passTF");
			photoTF = (TextField) loader.getNamespace().get("photoTF");

			/// CheckBox gender

			maleRB = (RadioButton) loader.getNamespace().get("maleRB");
			femaleRB = (RadioButton) loader.getNamespace().get("femaleRB");
			othRB = (RadioButton) loader.getNamespace().get("othRB");

			/// CheckBox Career

			softCHB = (CheckBox) loader.getNamespace().get("softCHB");
			telCHB = (CheckBox) loader.getNamespace().get("telCHB");
			indCHB = (CheckBox) loader.getNamespace().get("indCHB");

			/// Buttons

			browBTN = (Button) loader.getNamespace().get("browBTN");
			singBTN = (Button) loader.getNamespace().get("singBTN");
			createBTN = (Button) loader.getNamespace().get("createBTN");

			/// Calendar

			birthDT = (DatePicker) loader.getNamespace().get("birthDT");

			/// favorite browser

			favbrowCB = (ChoiceBox) loader.getNamespace().get("favbrowCB");

			/// Data

			register();

		} catch (Exception ex) {
			ex.printStackTrace();

		}
	}

	public void register() {

		createBTN.setOnAction(event -> {

			if ((usTF.getText() != null) && (passTF.getText() != null) && (photoTF.getText() != null)
					&& ((maleRB.getText() != null) || (femaleRB.getText() != null) || (othRB.getText() != null))
					&& ((softCHB.getText() != null) || (telCHB.getText() != null) || (indCHB.getText() != null))
					&& (birthDT.getValue() != null)) {
				
				
				createAccount();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ERROR");
				alert.setHeaderText("Failed to create account");
				alert.setContentText("You must fill each field in the form");
				alert.showAndWait();
			}

		});

		browBTN.setOnAction(event -> {

			photoPath();

		});
	}

	public void photoPath() {
		FileChooser fc = new FileChooser();
		fc.setTitle("Abra una imagen");
		fc.getExtensionFilters().addAll(

				new FileChooser.ExtensionFilter("PNG", "*.png"), new FileChooser.ExtensionFilter("JPG", "*.jpg")

		);

		File file = fc.showOpenDialog(this);

		if (file != null) {
			Image image = new Image("file:" + file.getAbsolutePath());
			photoTF.setText(file.getAbsolutePath());

		}

	}

	public void createAccount() {

		String gender = "";

		String career = "";

		String userName = usTF.getText();

		if (maleRB.selectedProperty().get() == true) {
			gender = maleRB.getText();
		} else if (femaleRB.selectedProperty().get() == true) {
			gender = femaleRB.getText();
		} else if (othRB.selectedProperty().get() == true) {
			gender = othRB.getText();
		}
		////////
		if (softCHB.selectedProperty().get() == true) {
			career += softCHB.getText();
		} else if (telCHB.selectedProperty().get() == true) {
			career += telCHB.getText();
		} else if (indCHB.selectedProperty().get() == true) {
			career += indCHB.getText();
		}

		String pathPhoto = "";

		pathPhoto = photoTF.getText();
		
		
		

		String birthday = birthDT.getValue().toString();
		
		String password = passTF.getText();

		Users us = new Users(userName,password, gender, career, birthday, pathPhoto);
		DataUsers.getData().add(us);

		WindowTable table = new WindowTable();
		table.show();
	}

}
