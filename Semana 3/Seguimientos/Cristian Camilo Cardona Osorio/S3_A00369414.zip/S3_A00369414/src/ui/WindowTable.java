package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.Users;
import model.DataUsers;


public class WindowTable extends Stage {
	
	///
	
	private TableView<Users> usersTV;
	private Button outBTN;
	private Label usernameLB;
	private ImageView userphotoIMV;
	
	//Data
	
	public WindowTable() {
		
		try {
			
			
			FXMLLoader loader = new FXMLLoader(getClass().getResource("WindowTable.fxml"));
			Parent root = loader.load();
			
			Scene scene = new Scene(root, 600, 400);
			setScene(scene);
			
			usersTV = (TableView) loader.getNamespace().get("usersTV");
			outBTN = (Button) loader.getNamespace().get("outBTN");
			usernameLB = (Label) loader.getNamespace().get("usernameLB");
			userphotoIMV = (ImageView) loader.getNamespace().get("userphotoIMV");
			
			//////Crear columnas
			TableColumn<Users, String> name = new TableColumn<>("Username");
			TableColumn<Users, String> gender = new TableColumn<>("Gender");
			TableColumn<Users, String> career = new TableColumn<>("Career");
			TableColumn<Users, String> birthday = new TableColumn<>("Birthday");
			
			
			///// Enlaces a columnas
			
			name.setCellValueFactory(new PropertyValueFactory<>("UserName"));
			gender.setCellValueFactory(new PropertyValueFactory<>("Gender"));
			career.setCellValueFactory(new PropertyValueFactory<>("Career"));
			birthday.setCellValueFactory(new PropertyValueFactory<>("Birthday"));
			
			////////
			
			usersTV.getColumns().addAll(name,gender,career, birthday);
			
			usersTV.setItems(DataUsers.getData());
			
			
			
			init();
		
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		
	}

	public void init() {
		
		outBTN.setOnAction(event->{
			
			logOut();
		});
		
	}

	private void logOut() {
		
		MainWindow main = new MainWindow();
		main.show();
		
		
	}
}
