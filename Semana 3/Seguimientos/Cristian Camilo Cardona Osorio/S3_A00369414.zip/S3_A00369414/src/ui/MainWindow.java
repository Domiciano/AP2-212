package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import model.DataUsers;

public class MainWindow extends Stage {

	///
	private TextField usnTF;
	private TextField passTF;
	private Button singBTN;
	private Button logBTN;

	public MainWindow() {

		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("MainWindow.fxml"));
			Parent root = loader.load();

			Scene scene = new Scene(root, 600, 400);
			setScene(scene);

			usnTF = (TextField) loader.getNamespace().get("usnTF");
			passTF = (TextField) loader.getNamespace().get("passTF");
			singBTN = (Button) loader.getNamespace().get("singBTN");
			logBTN = (Button) loader.getNamespace().get("logBTN");

			init();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void init() {

		logBTN.setOnAction(event -> {

			WindowLogin login = new WindowLogin();
			login.show();
		});

		singBTN.setOnAction(event -> {

			openRegister();
		});

	}

	public void openRegister() {

		String userName = usnTF.getText();

		String password = passTF.getText();

		for (int i = 0; i < DataUsers.getData().size(); i++) {
			if ((DataUsers.getData().get(i).getUserName().equals(userName))
					&& (DataUsers.getData().get(i).getPassword().equals(password))) {

				WindowTable table = new WindowTable();
				table.show();

			}
			else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ERROR");
				alert.setHeaderText("Failed to sing up");
				alert.setContentText("Username or password");
				alert.showAndWait();
			}
		}
		

	}

}
