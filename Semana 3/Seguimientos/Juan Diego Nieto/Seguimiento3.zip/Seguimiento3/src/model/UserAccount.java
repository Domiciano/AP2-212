package model;

import javafx.scene.image.Image;

public class UserAccount {
	
	private String username;
	private Image profilePhoto;
	private String password;
	private String gender;
	private String carrer;
	private String birthday;
	private String favoriteBrowser;

	public UserAccount() {
		
	}
	
	public UserAccount(String username, Image profilePhoto, String password, String gender, String carrer, String birthday,
			String favoriteBrowser) {
		this.username = username;
		this.password = password;
		this.gender = gender;
		this.carrer = carrer;
		this.birthday = birthday;
		this.favoriteBrowser = favoriteBrowser;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCareer() {
		return carrer;
	}

	public void setCareer(String career) {
		this.carrer = career;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getFavoriteBrowser() {
		return favoriteBrowser;
	}

	public void setFavoriteBrowser(String favoriteBrowser) {
		this.favoriteBrowser = favoriteBrowser;
	}

	public Image getProfilePhoto() {
		return profilePhoto;
	}

	public void setProfilePhoto(Image profilePhoto) {
		this.profilePhoto = profilePhoto;
	}
	
}
