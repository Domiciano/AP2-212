package model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class UserAccountdata {
	
	private ObservableList<UserAccount> users;
	
	public UserAccountdata() {
		users = FXCollections.observableArrayList();
	}
	
	public ObservableList<UserAccount> getData() {
		return users;
	}
	
}
