package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.UserAccount;
import model.UserAccountdata;

public class AccountListPage extends Stage {
	
	//Ui components
	private Label userNameLbl;
	private Button logOutBtn;
	private TableView<UserAccount> userListTable;
	private ImageView profilePhotoIvw;
	
	//Data
	public static UserAccountdata users = new UserAccountdata();
	public static UserAccount userLogEd = new UserAccount();
	
	public AccountListPage() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("CreateAccountPage.fxml"));
			 Parent root = loader.load();
			 
			 userNameLbl = (Label) loader.getNamespace().get("userNameLbl");
			 logOutBtn = (Button) loader.getNamespace().get("userNameLbl");
			 userListTable = (TableView) loader.getNamespace().get("userListTable");
			 profilePhotoIvw = (ImageView) loader.getNamespace().get("profilePhotoIvw");
			 
			 users = new UserAccountdata();
			 
			//Creation of table columns
			 TableColumn<UserAccount, String> userNameCol = new TableColumn<>("USERNAME");
			 TableColumn<UserAccount, String> genderCol = new TableColumn<>("GENDER");
			 TableColumn<UserAccount, String> carrerCol = new TableColumn<>("CARRER");
			 TableColumn<UserAccount, String> birthdayCol = new TableColumn<>("BIRTHDAY");
			 TableColumn<UserAccount, String> browserCol = new TableColumn<>("BROWSER");
			 
			 userNameCol.setCellValueFactory(new PropertyValueFactory<>("username"));
			 genderCol.setCellValueFactory(new PropertyValueFactory<>("gender"));
			 carrerCol.setCellValueFactory(new PropertyValueFactory<>("gender"));
			 birthdayCol.setCellValueFactory(new PropertyValueFactory<>("birthday"));
			 browserCol.setCellValueFactory(new PropertyValueFactory<>("browser"));
			 
			 userListTable.getColumns().addAll(userNameCol, genderCol, carrerCol, birthdayCol,
					 browserCol);
			 userListTable.setItems(users.getData());
			 
			 Scene scene = new Scene(root, 555, 400);
			 setScene(scene);
			 
		} catch(Exception ex) {
			ex.printStackTrace();
	 }		
	}
	
	public void init() {
		logOutBtn.setOnAction(event-> {
			LogInPage logIn = new LogInPage();
			logIn.show();
			hide();
		});
		for(int i = 0; i< users.getData().size(); i++) {
			userNameLbl.setText(userLogEd.getUsername());
			profilePhotoIvw.setImage((userLogEd.getProfilePhoto()));
		}
	}
	
	public void setData(UserAccountdata data) {
		users = data;
	}
	
}
