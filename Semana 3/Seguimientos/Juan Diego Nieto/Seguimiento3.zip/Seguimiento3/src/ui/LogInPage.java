package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.UserAccount;

public class LogInPage extends Stage {
	
	//Ui components
	private TextField usernameFd;
	private PasswordField passwordFd;
	private Button signUpBtn;
	private Button logInBtn;
	
	public LogInPage() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("LogInPage.fxml"));
			Parent root = loader.load();
			
			usernameFd = (TextField) loader.getNamespace().get("usernameFd");
			passwordFd = (PasswordField) loader.getNamespace().get("passwordFd");
			signUpBtn = (Button) loader.getNamespace().get("signUpBtn");
			logInBtn = (Button) loader.getNamespace().get("logInBtn");
			
			Scene scene = new Scene(root, 555, 400);
			setScene(scene);
			
			init();
		} catch(Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void init() {
		signUpBtn.setOnAction(event-> {
			openSignUpPage();
		});
		logInBtn.setOnAction(event-> {
			openAccountListPage();
		});
	}

	private void openAccountListPage() {
		String username = usernameFd.getText();
		String password = passwordFd.getText();
		if(username.isEmpty() || password.isEmpty()) {
			Alert alert = new Alert(AlertType.ERROR);
			alert.setHeaderText(null);
			alert.setContentText("Complete los espacios requeridos");
			alert.showAndWait();
		} else {
			for(int i=0; i< AccountListPage.users.getData().size(); i++) {
				if(AccountListPage.users.getData().get(i).getUsername().equals(username) && 
						AccountListPage.users.getData().get(i).getPassword().equals(password)) {
					UserAccount userLog = new UserAccount();
					userLog = AccountListPage.users.getData().get(i);
					AccountListPage.userLogEd = userLog;
					AccountListPage accountListPage = new AccountListPage();
					accountListPage.show();
					hide();
				} else {
					Alert alert = new Alert(AlertType.ERROR);
					alert.setHeaderText(null);
					alert.setContentText("Usuario o contrase�a incorrectos");
					alert.showAndWait();
				}
			}
		}
		
		
	}

	private void openSignUpPage() {
		CreateAccountPage createAccount = new CreateAccountPage();
		createAccount.show();
		hide();
	}
}
