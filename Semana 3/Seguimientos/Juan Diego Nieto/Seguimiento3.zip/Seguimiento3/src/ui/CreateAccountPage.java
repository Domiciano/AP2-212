package ui;

import java.io.File;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.UserAccount;

public class CreateAccountPage extends Stage {
	
	//Ui components
	 private TextField usernameFd;
	 private PasswordField passwordFd;
	 private CheckBox maleCB;
	 private CheckBox femaleCB;
	 private CheckBox otherCB;
	 private CheckBox softwareCB;
	 private CheckBox telematicCB;
	 private CheckBox industrialCB;
	 private DatePicker birthdayDP;
	 private ChoiceBox<String> favoriteBrowserCB;
	 private Button signInBtn;
	 private Button createAccountBtn;
	 private Button browseBtn;
	 private Label messageLl;
	 
	 public CreateAccountPage() {
		 try {
			 FXMLLoader loader = new FXMLLoader(getClass().getResource("CreateAccountPage.fxml"));
			 Parent root = loader.load();
			 
			 usernameFd = (TextField) loader.getNamespace().get("usernameFd");
			 passwordFd = (PasswordField) loader.getNamespace().get("passwordFd");
			 maleCB = (CheckBox) loader.getNamespace().get("maleCB");
			 femaleCB = (CheckBox) loader.getNamespace().get("femaleCB");
			 otherCB = (CheckBox) loader.getNamespace().get("otherCB");
			 softwareCB = (CheckBox) loader.getNamespace().get("softwareCB");
			 telematicCB = (CheckBox) loader.getNamespace().get("telematicCB");
			 industrialCB = (CheckBox) loader.getNamespace().get("industrialCB");
			 birthdayDP = (DatePicker) loader.getNamespace().get("birthdayDP");
			 favoriteBrowserCB = (ChoiceBox) loader.getNamespace().get("favoriteBrowserCB");
			 signInBtn = (Button) loader.getNamespace().get("signInBtn");
			 createAccountBtn = (Button) loader.getNamespace().get("createAccountBtn");
			 browseBtn = (Button) loader.getNamespace().get("browseBtn");
			 messageLl = (Label) loader.getNamespace().get("messageLl");
			 
			 ChoiceBox<String> favoriteBrowserCB = new ChoiceBox<>();
			 favoriteBrowserCB.getItems().add("Google");
			 favoriteBrowserCB.getItems().add("Firefox");
			 favoriteBrowserCB.getItems().add("MicrosoftExplorer");
			 
			 Scene scene = new Scene(root, 535, 680);
			 setScene(scene);
			 
			 init();
			 
		 }catch(Exception ex) {
				ex.printStackTrace();
		 }
	 }

	private void init() {
		createAccountBtn.setOnAction(event-> {
			createAccount();
		});
		signInBtn.setOnAction(event-> {
			returnLogInPage();
		});
		browseBtn.setOnAction(event-> {
			openImage();
		});
		
	}

	private Image openImage() {
		FileChooser fc = new FileChooser();
    	fc.setTitle("Abra una imagen");
    	fc.getExtensionFilters().addAll(
    			new FileChooser.ExtensionFilter("ALL", "*.*")
    	);
    	File file = fc.showOpenDialog(this);
    	Image profilePhoto = null;
		if(file != null) {
    		System.out.println(file.getAbsolutePath());
    		Image image = new Image ("file: "+file.getAbsolutePath());    		
    		profilePhoto = image;
    	}
		return profilePhoto;
		
	}

	private void returnLogInPage() {
		LogInPage logIn = new LogInPage();
		logIn.show();
		hide();
		
	}

	private void createAccount() {
		String username = usernameFd.getText(); 
		String password = passwordFd.getText();		
		String gender = null;
		if(maleCB.isSelected()) {
			gender = "Male";
		} else if (femaleCB.isSelected()) {
			gender = "Female";
		} else if (otherCB.isSelected()) {
			gender = "Other";
		} else {
			gender = "";
		}
		String carrer = null;
		if(softwareCB.isSelected()) {
			carrer = "Software Engineering";
		} else if (telematicCB.isSelected()) {
			carrer = "Telemactic Engineering";
		} else if (industrialCB.isSelected()) {
			carrer = "Industrial Engineering";
		} else {
			carrer = "";
		}
		int day = birthdayDP.getValue().getDayOfYear();
		int month = birthdayDP.getValue().getDayOfMonth();
		int year = birthdayDP.getValue().getDayOfYear();
		String birthday = (day+"/"+month+"/"+year);
		String favoriteBrowser = (String) favoriteBrowserCB.getValue();
		Image profilePhoto = openImage();
		UserAccount user = new UserAccount(username, profilePhoto, password, gender, carrer, birthday, favoriteBrowser);
		AccountListPage.users.getData().add(user);
		
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Registro agregado");
		alert.setHeaderText("Nuevo registro");
		alert.setContentText("�Registro agegado exitosamente!");
		
		alert.showAndWait();
	}
	 
}
