package ui;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Classroom;
import model.UserAccount;

public class ClasroomGUI {

	private Classroom account;
	static ObservableList<UserAccount> observableList;


	//componentes de las ventanas
	@FXML
	private TableView<UserAccount> tabla;

	@FXML
	private TextField usernameR;

	@FXML
	private PasswordField PasswordR;

	@FXML
	private RadioButton male;

	@FXML
	private RadioButton female;

	@FXML
	private RadioButton other;

	@FXML
	private CheckBox sofware;

	@FXML
	private CheckBox telematica;

	@FXML
	private CheckBox industrial;

	@FXML
	private Button crear;

	@FXML
	private TextArea txtPhoto;

	@FXML
	private DatePicker cumple;

	@FXML
	private TextField navegador;

	@FXML
	private BorderPane mainPane;
	@FXML
	private Button newAccount;

	@FXML
	private Button entra;

	@FXML
	private TextField userLogin;

	@FXML
	private PasswordField passLogin;
	@FXML
	private TableColumn<UserAccount, String> usernameC;

	@FXML
	private TableColumn<UserAccount, String> genderC;

	@FXML
	private TableColumn<UserAccount, String> careerC;

	@FXML
	private TableColumn<UserAccount, String> birthdayC;

	@FXML
	private TableColumn<UserAccount, String> browserC;


	public ClasroomGUI() {

		account = new Classroom();

	}

	//mostrar pantalla de login
	@FXML
	public void loadLogin() throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));

		loader.setController(this);
		Parent addUser = loader.load();

		mainPane.setCenter(addUser);
		mainPane.getChildren().clear();
		mainPane.setTop(addUser);


	}


	//mostrar pantalla register
	@FXML
	void crearCuenta(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("register.fxml"));

		loader.setController(this);
		Parent addUser = loader.load();

		mainPane.setCenter(addUser);
		mainPane.getChildren().clear();
		mainPane.setTop(addUser);

	}

	@FXML
	void entrar(ActionEvent event) throws IOException {
		if(!userLogin.getText().equals("") && !passLogin.getText().equals("")) {
			boolean s=account.searchUser(userLogin.getText(), passLogin.getText());
			if(!s) {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("account-list.fxml"));

				loader.setController(this);
				Parent addUser = loader.load();

				mainPane.setCenter(addUser);
				mainPane.getChildren().clear();
				mainPane.setTop(addUser);

				tablasC();
			}
			else {
				Alert alert = new Alert(AlertType.ERROR);
				  alert.setTitle("ERROR");
				  alert.setHeaderText("Invalid User or Password");
				  alert.setContentText("Your Username or Password is incorrect, please try again ");
					  
				  alert.showAndWait();

			}

		}
		else {
			Alert alert = new Alert(AlertType.ERROR);
			 alert.setTitle("ERROR");
			 alert.setHeaderText("You must fill all the fields");
			 alert.setContentText(null);
			 alert.showAndWait();

		}



	}

	@FXML
	void register1(ActionEvent event) {

	}



	@FXML
	void showTable(ActionEvent event) throws IOException {


		//referenciar
		String photo="";
		String gender="";
		String career="";
		String username=usernameR.getText();
		String password=PasswordR.getText();
		String browser=navegador.getText();
		LocalDate birthday=cumple.getValue();

		if(male.isSelected()) {
			gender="male";
		}
		else if(female.isSelected()) {
			gender="female";
		}
		else {
			gender="other";
		}
		if(sofware.isSelected()) {
			career="Sofware Ingenieering";
		}
		else if(industrial.isSelected()) {
			career="industrial Ingenieering";
		}
		else {
			career="Telematic Ingenieering";
		}

	    if(!usernameR.getText().equals("") && !PasswordR.getText().equals("") && !navegador.getText().equals("") && cumple.getValue() != null) {
	    	UserAccount obj = new UserAccount(username,password,photo,browser,birthday.toString(),gender,career);
	    	
			FXMLLoader loader = new FXMLLoader(getClass().getResource("account-list.fxml"));

			loader.setController(this);
			Parent addUser = loader.load();

			mainPane.setCenter(addUser);
			mainPane.getChildren().clear();
			mainPane.setTop(addUser);

			account.getAccounts().add(obj);
			
			//alet
			Alert alert = new Alert(Alert.AlertType.INFORMATION);
			alert.setHeaderText(null);
			alert.setTitle("Account created");
			alert.setContentText("The new account has been created");
			alert.showAndWait();

			tablasC();
	    }
	    else {
	    	Alert alert1 = new Alert(AlertType.ERROR);
			 alert1.setTitle("ERROR");
			 alert1.setHeaderText("You must fill all the fields");
			 alert1.setContentText(null);
			 alert1.showAndWait();
	    }
	}   


	@FXML
	public void chooseImage(ActionEvent event)throws IOException {
		FileChooser fileChooser = new FileChooser();
		fileChooser.setTitle("Open Resource File");
		File file = fileChooser.showOpenDialog(null);
		txtPhoto.appendText(file.getAbsolutePath());
	}


	public void tablasC() {

		observableList = FXCollections.observableArrayList(account.getAccounts());

		tabla.setItems(observableList);

		//Enlaces con elementos de la tabla
		usernameC.setCellValueFactory(new PropertyValueFactory<UserAccount, String>("username"));
		genderC.setCellValueFactory(new PropertyValueFactory<UserAccount, String>("gender"));
		careerC.setCellValueFactory(new PropertyValueFactory<UserAccount, String>("career"));
		birthdayC.setCellValueFactory(new PropertyValueFactory<UserAccount, String>("birthday"));
		browserC.setCellValueFactory(new PropertyValueFactory<UserAccount, String>("browser"));

	}

}