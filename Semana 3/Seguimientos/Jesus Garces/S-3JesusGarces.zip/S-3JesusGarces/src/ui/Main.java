package ui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.Classroom;

public class Main extends Application{
	
	private ClasroomGUI classroomgui;
	private Classroom classroom;

	public static void main(String[] args) {
		launch(args);

	}
	
	public Main() {
		classroom = new Classroom();
		classroomgui = new ClasroomGUI();
	}

	@Override
	public void start(Stage primaryStage) throws Exception {		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("main-pane.fxml"));
		loader.setController(classroomgui);
		Parent root = loader.load();
		
		Scene scene = new Scene(root);
		primaryStage.setScene(scene);
		primaryStage.show();

		classroomgui.loadLogin();
	
		
	}

}
