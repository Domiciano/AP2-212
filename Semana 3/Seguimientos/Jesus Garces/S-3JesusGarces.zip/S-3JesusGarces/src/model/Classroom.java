package model;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Classroom {
	
	private ArrayList<UserAccount> accounts;

	//public static ObservableList<UserAccount> account;
	
	public Classroom() {
		//account = FXCollections.observableArrayList();
		accounts = new ArrayList<UserAccount>();

	}
	
	//public ObservableList<UserAccount> getData(){
	//	return account;
	//}

	public ArrayList<UserAccount> getAccounts() {
		return accounts;
	}

	public void setAccounts(ArrayList<UserAccount> accounts) {
		this.accounts = accounts;
	}
	
	public boolean searchUser(String name, String password) {
		boolean find = true;  
		
		for(int i = 0;i < accounts.size();i++) {
			if(accounts.get(i).getUsername().equalsIgnoreCase(name) && accounts.get(i).getPassword().equalsIgnoreCase(password)) {
				find = false;
			}
		}
		return find;
	}


}
