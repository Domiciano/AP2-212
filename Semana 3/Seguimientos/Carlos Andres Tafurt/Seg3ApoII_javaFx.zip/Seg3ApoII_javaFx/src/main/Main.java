package main;

import javafx.application.Application;
import javafx.stage.Stage;
import ui.InicioSesion;

public class Main extends Application {

	public static void main(String[] args) {
		launch(args);
		
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		InicioSesion p=new InicioSesion();
		System.out.println("entre voy ");
		p.show();
		
	}

}
