package ui;

public class TablaData {

}
