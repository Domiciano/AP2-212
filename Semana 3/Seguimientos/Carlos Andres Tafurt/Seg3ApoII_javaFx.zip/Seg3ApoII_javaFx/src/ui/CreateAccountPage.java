package ui;

import java.io.IOException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CreateAccountPage extends Stage {

		private ObservableList<String> BrowserCB=FXCollections.observableArrayList("Google Chrome","Safari","Microsoft Internet Explorer","Opera");
	    private TextField usernameFd;
	    private PasswordField passwordFd;
	    private TextField profilePhotoFd;
	    private CheckBox maleCB;
	    private CheckBox femaleCB;
	    private CheckBox otherCB;
	    private CheckBox softwareCB;
	    private CheckBox telematicCB;
	    private CheckBox industrialCB;
	    private DatePicker birthdayDP;
	    private ChoiceBox<String> favoriteBrowserCB;
	    private Button signInBtn;
	    private Button createAccountBtn;
	    private Label messageLbl;
	    private Button browseBtn;
		
		public CreateAccountPage() {
			
			
			System.out.println("aqui voy ");
			try {
				FXMLLoader loader=new FXMLLoader(getClass().getResource("CreateAccountPage.fxml"));
				Parent root=loader.load();
				
				usernameFd = (TextField)loader.getNamespace().get("usernameFd");
				passwordFd = (PasswordField)loader.getNamespace().get("passwordFd");
				profilePhotoFd = (TextField)loader.getNamespace().get("profilePhotoFd");
				maleCB = (CheckBox)loader.getNamespace().get("maleCB");
				femaleCB = (CheckBox)loader.getNamespace().get("femaleCB");
				otherCB = (CheckBox)loader.getNamespace().get("otherCB");
				softwareCB = (CheckBox)loader.getNamespace().get("softwareCB");
				telematicCB = (CheckBox)loader.getNamespace().get("telematicCB");
				industrialCB = (CheckBox)loader.getNamespace().get("industrialCB");
				birthdayDP = (DatePicker)loader.getNamespace().get("birthdayDP");
				favoriteBrowserCB = (ChoiceBox<String>)loader.getNamespace().get("favoriteBrowserCB");
				signInBtn = (Button)loader.getNamespace().get("signInBtn");
				createAccountBtn = (Button)loader.getNamespace().get("createAccountBtn");
				messageLbl = (Label)loader.getNamespace().get("messageLbl");
				browseBtn = (Button)loader.getNamespace().get("browseBtn");
				System.out.println("aqui voy entre");
				favoriteBrowserCB.setItems(BrowserCB);
				
				Scene scene=new Scene(root,500,600);
				setScene(scene);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	    
	    
	    
}
