package ui;

import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.passwords;

public class InicioSesion extends Stage {

	 private Button EnterFolder;
	 private PasswordField passwordData;
	 private TextField UserData;
	/**
	 * 
	 */
	public InicioSesion() {
		try {
			 FXMLLoader loader = new FXMLLoader(getClass().getResource("inicioSesion.fxml"));
	         Parent parent = loader.load();
			
			EnterFolder=(Button)loader.getNamespace().get("EnterFolder");
			passwordData=(PasswordField)loader.getNamespace().get("passwordData");
			UserData=(TextField)loader.getNamespace().get("UserData");
			
			Scene scene=new Scene(parent,600,400);
			setScene(scene);
			init();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void init() {
		
		//String passwordD=String.valueOf(passwordData.getText());
		System.out.println(passwordData.getText());
		//String UserD=String.valueOf(UserData);
		System.out.println(UserData.getText());
		EnterFolder.setOnAction(Event->{
			boolean validaPassword=validation(passwordData.getText());
			boolean validaUser=validation(UserData.getText());
			if (validaUser==true&&validaPassword==true ) {
				CreateAccountPage ct=new CreateAccountPage();
				ct.show();
			}else System.out.println("error");
		});
	}
	public boolean validation(String validar) {
		
		passwords ps=new passwords();
		
		boolean valido=false;
		if(validar.equalsIgnoreCase(ps.getPassword())|validar.equalsIgnoreCase(ps.getUser())) {
			valido=true;
		}else System.out.println("error no existe");
		
		return valido;
	}
	 
	 
	 
	 
}
