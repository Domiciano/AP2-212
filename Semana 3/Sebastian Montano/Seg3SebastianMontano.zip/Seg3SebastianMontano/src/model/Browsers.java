package model;

public class Browsers
{

}
