package model;


public class Student
{
	// Attributes
	private String username, password, photoPath;
	
	
	public Student()
	{
		
	}
}
