package ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static Scanner sn = new Scanner(System.in);

	public static void main(String[] args) {

		int libro = sn.nextInt();
		sn.nextLine();

		int[] prices = new int[libro];

		String pricesRaw = sn.nextLine();
		String[] parts = pricesRaw.split(" ");

		for(int i=0; i<parts.length;i++) {
			prices[i] = Integer.parseInt(parts[i]);
		}

		int dinero = Integer.parseInt(sn.nextLine());

		int libro1=0;
		int libro2=0;
		int diferencia=10000;

		//Ordenar Arreglo

		for (int x = 0; x < prices.length; x++) {
			for (int i = 0; i < prices.length-x-1; i++) {
				if(prices[i] > prices[i+1]){
					int tmp = prices[i+1];
					prices[i+1] = prices[i];
					prices[i] = tmp;
				}
			}
		}
		System.out.println(Arrays.toString(prices));
		//Busqueda binaria
		for (int i = 0; i < prices.length; i++) {
			if(prices[i] < dinero){
				int goal=dinero-prices[i];
				libro1=prices[i];

				int contador=0;
				int start = 0;
				int end = prices.length-1;
				while (start <= end) {
					int half = (start+end)/2;
					if(prices[half] == goal) {
						
							System.out.println("peter debe comprar los libros cuyos precios son: "+libro1+" y "+goal);
						
						break;
					}else if(prices[half] > goal) {
						end = half-1;
					}else {
						start = half+1;
					}
					contador++;
				}

			}
			break;
		}

		long tic = System.currentTimeMillis();
		long toc1 = System.currentTimeMillis() - tic;
		
		System.out.println("Binario "+toc1);

	}
}

