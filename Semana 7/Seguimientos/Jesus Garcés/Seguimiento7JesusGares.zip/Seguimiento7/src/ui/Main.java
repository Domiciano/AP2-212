package ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

	public static Scanner sn = new Scanner(System.in);

	public static void main(String[] args) {

		int libro = sn.nextInt();
		sn.nextLine();

		int[] prices = new int[libro];

		String pricesRaw = sn.nextLine();
		String[] parts = pricesRaw.split(" ");

		for(int i=0; i<parts.length;i++) {
			prices[i] = Integer.parseInt(parts[i]);
		}

		int dinero = Integer.parseInt(sn.nextLine());

		int libro1=0;
		int libro2=0;
		int diferencia=10000;

		//Algoritmo de seleccion
		for(int i=0;i<prices.length;i++) {

			if(prices[i]<=dinero) {
				for(int j=0;j<prices.length;j++) {
					if(prices[i]+prices[j]==dinero && prices[i]-prices[j]<diferencia) {
						libro1 =prices[i];
						libro2 =prices[j];
						if(libro1>libro2) {
							diferencia=libro1-libro2;
						}
						else {
							diferencia=libro2-libro1;
						}
					}

				}

			}

		}
		if(libro1>0 && libro2>0) {

			System.out.println("peter debe comprar los libros cuyos precios son: "+libro1+" y "+libro2);
		}

		long tic = System.currentTimeMillis();
		long toc1 = System.currentTimeMillis() - tic;
		
		System.out.println("Secuencial "+toc1);
		
	}

}

