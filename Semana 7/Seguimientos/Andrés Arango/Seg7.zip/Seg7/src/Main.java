import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

	public final static int libros=2;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner= new Scanner(System.in);
		
		System.out.println("Hello peter");
		System.out.println("N�mero de procesos");
		int numProcesos= Integer.parseInt(scanner.nextLine());
		for(int d=0; d<numProcesos; d++) {
		int numLibros= Integer.parseInt(scanner.nextLine());
		if(2> numLibros) {
			if(numLibros<10000) {
			System.out.println("Numero incorrecto");
			}
		}
		int [] prices = new int[numLibros];
		String precios= scanner.nextLine();
		String[] partes= precios.split(" ");
		for(int i=0; i<partes.length;i++) {
			prices[i]= Integer.parseInt(partes[i]);
			
		}
		int budget= Integer.parseInt(scanner.nextLine());
		
		long tic= System.currentTimeMillis();
		int[] res= sequencialSearch(prices, budget);
		System.out.println("Peter deber�a comprar libros con precios entre "+ res[0]+ " y "+ res[1]);
		long tac=System.currentTimeMillis()-tic;
		System.out.println("Duraci�n secuencial "+ tac );
		
		
		
		Arrays.sort(prices);
		long tic1= System.currentTimeMillis();
		int[] res1=binarialSearch(prices, budget);
		System.out.println("Peter deber�a comprar libros con precios entre "+ res1[0]+ " y "+ res1[1]);
		long tac1= System.currentTimeMillis()-tic1;
		System.out.println("Duracion binario " +tac1);
		
		crearArchivo(budget, precios, budget, res1, res1);
	}}
	
	public static int[] sequencialSearch(int[] prices, int budget) {
		int[] libross=  new int[libros];
		for(int i=0; i< prices.length; i++) {
			int numBuscado= budget-prices[i];
			
			if(numBuscado+prices[i]==budget) {
				if(numBuscado<prices[i]) {
					if(numBuscado!=0) {
						
						if(prices[i]>prices[i-1]) {
						int[] resultados= {numBuscado, prices[i]};
						return resultados;
						}
					}
					
				}else if(numBuscado==prices[i]) {
					int[] resultados= {numBuscado, prices[i]};
					return resultados;
				}
				
							
			}
		}
		return libross;
		}
	
	public static int[] binarialSearch(int[] prices, int budget) {
	int[] libross=  new int[libros];
	int start= 0;
	int end = prices.length-1;
	if(prices.length>2) {
		while(start<=end){
			int half= (start+end)/2;
			if(prices[half]+prices[half-1]==budget) {
				int[] resultados= {prices[half-1],prices[half]};
				return resultados;
			}else if(prices[half] > budget) {
				end = half-1;
			}else {
				start = half+1;
			}
			
		}
	}else {
		if(prices[start]+prices[end]==budget) {
			int[] resultados= {prices[start],prices[end]};
			return resultados;
		}
	}
	return libross;
	
	}
	public static void  crearArchivo(int numLibros,String precios, int budget, int[] res, int[] res1) {
		try {
		File file = new File("src\\test.txt");
		String output= precios.length()+"\n"+
		precios+"\n"+
		budget+"\n"+
		"Peter deber�a comprar libros con precios entre "+ res[0]+ " y "+ res[1]+"\n"+
		"Peter deber�a comprar libros con precios entre "+ res1[0]+ " y "+ res1[1]+"\n";
		if(!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
			file.createNewFile();
			
		}
		FileWriter fw= new FileWriter(file.getAbsoluteFile(), true);
		BufferedWriter bw= new BufferedWriter(fw);
		bw.write(output);
		bw.close();
		}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
		
	
		
		
		
		
		
	


