package main;

import java.util.ArrayList;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int N = Integer.parseInt(scan.nextLine());
		int[]prices = new int[N];
		String pricesraw = scan.nextLine();
		String[] parts = pricesraw.split(" ");
		int M = Integer.parseInt(scan.nextLine());
		
		ArrayList<String> sum = new ArrayList<String>();
		
		for(int i=0;i<parts.length;i++) {
			prices[i] = Integer.parseInt(parts[i]);
			for(int j=i;j<parts.length;j++) {
				prices[j] = Integer.parseInt(parts[j]);
					if(prices[i]+prices[j]==M) {
						if(prices[i]<=prices[j]) {
							sum.add(parts[i]+"-"+parts[j]);
						}
					}
			}
		}
		int numI=Integer.parseInt(sum.get(0).split("-")[0]);
	    int numJ= Integer.parseInt(sum.get(0).split("-")[1]);
	    int less=Math.abs(numI-numJ);
	    int index=0;
	    
	    for (int i = 1; i < sum.size(); i++) {

	        numI=Integer.parseInt(sum.get(i).split("-")[0]);
	        numJ= Integer.parseInt(sum.get(i).split("-")[1]);
	        int distance= Math.abs(numI-numJ);
	        if(distance<less){
	            less=distance;
	            index=i;
	          }
	    }
	    String[] bookIndexes= sum.get(index).split("-");
	    System.out.println("Peter should buy books whose prices are "+bookIndexes[0]+" and "+ bookIndexes[1]);
	}
}