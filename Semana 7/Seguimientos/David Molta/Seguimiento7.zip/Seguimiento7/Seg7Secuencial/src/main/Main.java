package main;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {

    Scanner sc;
    ArrayList<Integer> priceOfEachBook;
    String[] prices;
    ArrayList<Integer> solutions;
    public static void main(String[] args) {

        Main m = new Main();
        m.mainMenu();


    }



    public Main(){
        sc = new Scanner(System.in);
        priceOfEachBook = new ArrayList<Integer>();
        solutions = new ArrayList<Integer>();
    }
    private void mainMenu() {
        int option=0;
        do{
            System.out.println("Select an option: " +
                    "\n1. Search manually for data" +
                    "\n2. Use the predetermined test");
            option = sc.nextInt();
            sc.nextLine();
            switch (option){
                case 1:
                    readInformation();
                    break;
                case 2:
                    long tic = System.nanoTime();
                    loadData();
                    System.out.println(System.nanoTime() - tic);
                    break;
                case 0:
                    break;
            }

        }while(option!=0);


    }
    private void readInformation() {
        solutions.clear();
        priceOfEachBook.clear();
        int numberOfBooks = Integer.parseInt(sc.nextLine());
        String pricesPart = sc.nextLine();

        prices = pricesPart.split(" ");
        for (String price : prices) {
            priceOfEachBook.add(Integer.parseInt(price));
        }
        int moneyAvailable = Integer.parseInt(sc.nextLine());

        Collections.sort(priceOfEachBook);

        String answer = searchSecuential(moneyAvailable,priceOfEachBook);
        System.out.println(answer);
    }

    private String searchSecuential(int moneyAvailable,ArrayList<Integer> priceOfBooks) {
        String answer ="";
        for(int i=0;i<priceOfBooks.size()-1;i++){

            for(int b=i+1;b<priceOfBooks.size();b++){

                if(priceOfBooks.get(i)+ priceOfBooks.get(b) == moneyAvailable){
                    int subs=priceOfBooks.get(i)-priceOfBooks.get(b);
                    if(subs<0){
                        subs = priceOfBooks.get(b)- priceOfBooks.get(i);
                    }else if(subs>0){
                        subs = subs;
                    }else subs=0;


                    if(solutions.isEmpty()){
                        solutions.add(priceOfBooks.get(i));
                        solutions.add(priceOfBooks.get(b));

                    }else if(!solutions.isEmpty()){
                        if(solutions.get(1)-solutions.get(0)>subs){
                            solutions.clear();
                            solutions.add(priceOfBooks.get(i));
                            solutions.add(priceOfBooks.get(b));
                            Collections.sort(solutions);
                        }
                    }


                }

            }


        }

        answer += "Peter should buy books whose prices are " + solutions.get(0) + " and " + solutions.get(1);
        solutions.clear();
        return answer;
    }

    private void loadData(){
        priceOfEachBook.clear();
        solutions.clear();
        try {
            File file = new File("data/casosdeprueba.txt");
            FileInputStream fis = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String text ="";
            String line = reader.readLine();

            while(line!=null){
                prices = line.split("\\|");
                int numberOfBooks = Integer.parseInt(prices[0]);
                for(int i=1;i<=numberOfBooks;i++){
                    priceOfEachBook.add(Integer.parseInt(prices[i]));
                }

                int amountOfMoney = Integer.parseInt(prices[prices.length-1]);
                text += searchSecuential(amountOfMoney,priceOfEachBook) + "\n";

                line = reader.readLine();

            }
            reader.close();
            System.out.println(text);
        }catch (IOException ex){
            ex.printStackTrace();
        }


    }
}
