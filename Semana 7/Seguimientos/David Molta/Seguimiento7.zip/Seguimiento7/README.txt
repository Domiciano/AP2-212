Después de analizar la búsqueda secuencial y binaria, me di cuenta que la binaria es mucho más óptima para los programas debido a que mientras que la secuencial
se demoró aproximadamente 0.0092326 segundos, la binaria se demoró 0.0025743 segundos en leer la misma cantidad de datos y con el mismo formato. Esta diferencia
por ahora es mínima pero con una mayor cantidad de datos se hará mucho más notable.




ADJUNTO ARCHIVO DE PRUEBA EN LA CARPETA DATA , QUE YA SE CARGA SÓLO.