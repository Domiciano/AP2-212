package main;



import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    Scanner sc = new Scanner(System.in);
    ArrayList<Integer> priceOfEachBook;
    String[] prices;
    ArrayList<Integer> solutions;


    public static void main(String[] args) {

        Main m = new Main();
        m.mainMenu();


    }

    private void mainMenu() {
        int option=0;
        do{
            System.out.println("Select an option: " +
                    "\n1. Search manually for data" +
                    "\n2. Use the predetermined test");
            option = sc.nextInt();
            sc.nextLine();
            switch (option){
                case 1:
                    readInfo();
                    break;
                case 2:
                    loadData();
                    break;
                case 0:
                    break;
            }

        }while(option!=0);


    }

    public Main() {
        priceOfEachBook = new ArrayList<Integer>();
        solutions = new ArrayList<Integer>();

    }

    public void readInfo() {
        priceOfEachBook.clear();
        solutions.clear();
        int amountOfBooks = Integer.parseInt(sc.nextLine());
        String pricesPart = sc.nextLine();
        prices = pricesPart.split(" ");
        for (String price : prices) {
            priceOfEachBook.add(Integer.parseInt(price));
        }
        int moneyAvailable = Integer.parseInt(sc.nextLine());
        int goal = 0;
        Collections.sort(priceOfEachBook);
        for(int i=0;i<priceOfEachBook.size();i++){
            goal = moneyAvailable - priceOfEachBook.get(i);
            binarySearch(priceOfEachBook,goal,priceOfEachBook.get(i),i);
        }

        System.out.println("Peter should buy books whose prices are "+ solutions.get(0) + " and " + solutions.get(1));



    }

    private void binarySearch(ArrayList<Integer> pricesOfBook, int goal, int complement, int pos) {
       Integer [] priceOfBookArray =  pricesOfBook.toArray(new Integer[0]);
        priceOfBookArray[pos] = -1;
        int start = 0;
        int finish = pricesOfBook.size()-1;
        int numberMed;

        while (start <= finish) {
                 numberMed = (start + finish)/2;
                if ((priceOfBookArray[numberMed])==goal) {

                    int subs;
                    if(goal-complement>0){
                        subs = goal - complement;
                    }else if(goal-complement<0){
                        subs = complement - goal;
                    }else subs =0;

                    if(!solutions.isEmpty()){

                        if((solutions.get(1)-solutions.get(0)> subs)){
                            solutions.clear();
                            solutions.add(complement);
                            solutions.add(goal);
                            Collections.sort(solutions);
                            priceOfBookArray[pos] = priceOfEachBook.get(pos);

                        }
                    }else if (solutions.isEmpty()){
                        solutions.add(complement);
                        solutions.add(goal);
                        Collections.sort(solutions);
                        priceOfBookArray[pos] = priceOfEachBook.get(pos);

                    }

                    break;


                } else if ((priceOfBookArray[numberMed])<goal) {
                    start = numberMed + 1;
                } else if ((priceOfBookArray[numberMed])>goal) {
                    finish = numberMed-1;
               }
        }




    }


    private void loadData(){
        priceOfEachBook.clear();
        solutions.clear();
        try {
            File file = new File("data/casosdeprueba.txt");
            FileInputStream fis = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String text ="";
            String line = reader.readLine();

            while(line!=null){

                prices = line.split("\\|");
                int numberOfBooks = Integer.parseInt(prices[0]);
                for(int i=1;i<=numberOfBooks;i++){
                    priceOfEachBook.add(Integer.parseInt(prices[i]));
                }

                int moneyAvailable = Integer.parseInt(prices[prices.length-1]);
                int goal;
                Collections.sort(priceOfEachBook);
                for(int i=0;i<priceOfEachBook.size();i++){
                    goal = moneyAvailable - priceOfEachBook.get(i);
                    binarySearch(priceOfEachBook,goal,priceOfEachBook.get(i),i);
                }

                text += "Peter should buy books whose prices are "+ solutions.get(0) + " and " + solutions.get(1) + "\n";
                priceOfEachBook.clear();
                solutions.clear();
                line = reader.readLine();

            }
            reader.close();
            System.out.println(text);

        }catch (IOException ex){
            ex.printStackTrace();
        }


    }


}