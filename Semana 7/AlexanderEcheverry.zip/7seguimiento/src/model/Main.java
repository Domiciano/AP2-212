package model;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private Scanner sc;
    private double money;
    private ArrayList<Integer> prices;

    public Main() {
        sc = new Scanner(System.in);
        money = 0;
        prices = new ArrayList<>();
    }

    public static void main(String[] args) {
        Main principal = new Main();
        principal.doCase();
    }

    public void doCase(){
        int numBooks = Integer.parseInt(sc.nextLine());
        String sPrices = sc.nextLine();
        String [] arrPrices = sPrices.split(" ");

        for(int a = 0; a < numBooks; a++){
            prices.add(Integer.parseInt(arrPrices[a]));
        }

        bubbleMethod();

        int money = Integer.parseInt(sc.nextLine());

        int i = 0;
        int j = 0;
        int rest2 = 0;

        for(int a = 0; a <= findHalf(money/2); a++){
            int initial = prices.get(a);
            int rest = money - initial;
            for(int b = 0; b < prices.size(); b++){
                if(prices.get(b) == rest){
                    if(prices.get(b) < rest2){
                        i = initial;
                        j = prices.get(b);
                    }
                }
            }
            rest2 = rest;
        }

        System.out.println("The prices are: " + i + " " + j);
    }

    public void bubbleMethod(){
        Integer auxiliar;
        for(int i = 0; i < prices.size(); i++){
            for(int j = 0; j < prices.size()-1; j++){
                if(prices.get(j) > prices.get(j+1)){
                    auxiliar = prices.get(j);
                    prices.set(j, prices.get(j+1));
                    prices.set(j+1, auxiliar);
                }
            }
        }
    }

    public int findHalf(int half){
        for(int i = 0; i < prices.size(); i++){
            if(half-prices.get(i) < 0){
                return i-1;
            }
        }

        return 0;
    }
}
