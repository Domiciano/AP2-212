package binarySearch;

import java.io.*;

public class Main {

    public static void main(String[] args) throws Exception {
        Main test = new Main();

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        String books = "";
        String line = "";
        int i = 0;
        do{
            if(i < 3 && i > 0) {
                books += line + "-";
                i++;
            } else if(i == 3){
                books += line + "|";
                i = 0;
            } else if(i == 0){
                books += line;
                i++;
            }
            line = in.readLine();
        }while(!line.equals("end-of-file"));

        test.execute(books);
    }

    public void execute(String books) {
        String [] eachCase = books.split("\\|");

        for(int i = 0; i < eachCase.length; i++){
            String [] thisCase = eachCase[i].split("-");

            int numOfBooks = Integer.parseInt(thisCase[0]);
            String [] priceEachBook = thisCase[1].split(" ");
            int money = Integer.parseInt(thisCase[2]);
            int [] prices = new int[numOfBooks];
            for(int j = 0; j < priceEachBook.length; j++){
                prices[j] = Integer.parseInt(priceEachBook[j]);
            }

            prices = bubbleMethod(prices);
            findSum(money, prices);
        }
    }

    public void findSum(int money, int [] prices){
        int i = 0;
        int j = 0;

        for(int a = 0; a <= findHalf(money/2, prices); a++){
            int tempI = prices[a];
            int [] tempPrices = prices.clone();
            tempPrices[a] = 0;
            int tempJ = money - tempI;
            if(binarySearch(tempJ, tempPrices) != -1){
                i = tempI;
                j = tempJ;
            }
        }

        System.out.println("Peter should buy books whose prices are " + i + " and " + j +".");
        System.out.println("");
    }

    public int binarySearch(int j, int [] prices){
        int start = 0;
        int end = prices.length-1;
        while(start <= end){
            int half = (start+end)/2;

            if(prices[half] == j){
                return half;
            } else if(j < prices[half]){
                end = half-1;
            } else if(j > prices[half]){
                start = half+1;
            }
        }

        return -1;
    }

    public int findHalf(int num, int [] prices){
        int start = 0;
        int end = prices.length-1;
        while(true){
            int half = (start+end)/2;

            if(prices[half] == num){
                return half;
            } else if(num < prices[half]){
                end = half-1;
            } else if(num > prices[half]){
                start = half+1;
            }

            if(start > end){
                return end;
            }
        }
    }

    public int [] bubbleMethod(int [] prices){
        int auxiliar;
        for(int i = 0; i < prices.length; i++){
            for(int j = 0; j < prices.length-1; j++){
                if(prices[j] > prices[j+1]){
                    auxiliar = prices[j];
                    prices[j] = prices[j+1];
                    prices[j+1] = auxiliar;
                }
            }
        }

        return prices;
    }
}
