package control;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class FormWindow extends Stage{
	
	private TextArea contenidoAT;
	private Button cambiarPassBTN;
	private Button cerrarCajaBTN;
	
public FormWindow() {
	
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("FormWindow.fxml"));
			Parent root = loader.load();
			
			Scene scene = new Scene(root,600,400);
			setScene(scene);
			
			contenidoAT = (TextArea) loader.getNamespace().get("contenidoAT");
			cambiarPassBTN = (Button) loader.getNamespace().get("cambiarPassBTN");
			cerrarCajaBTN = (Button) loader.getNamespace().get("cerrarCajaBTN");
			
		}catch(Exception ex){
			ex.printStackTrace();
			
		}
	}

}
