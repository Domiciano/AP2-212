package control;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FormWindowII extends Stage {
	
	//Clave Antigua
	private TextField passA1TF;
	private TextField passA2TF;
	private TextField passA3TF;
	private TextField passA4TF;
	private TextField passA5TF;
	private TextField passA6TF;
	
	//Clave Nueva
	
	private TextField NpassTF1;
	private TextField NpassTF2;
	private TextField NpassTF3;
	private TextField NpassTF4;
	private TextField NpassTF5;
	private TextField NpassTF6;
	
	//Botones
	private Button chPassBTN;
	private Button closeCBTN;
	
	

public FormWindowII() {
		
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("FormWindowII.fxml"));
			Parent root = loader.load();
			
			Scene scene = new Scene(root,600,400);
			setScene(scene);
			
			//Before
			passA1TF = (TextField) loader.getNamespace().get("passA1TF");
			passA2TF = (TextField) loader.getNamespace().get("passA2TF");
			passA3TF = (TextField) loader.getNamespace().get("passA3TF");
			passA4TF = (TextField) loader.getNamespace().get("passA4TF");
			passA5TF = (TextField) loader.getNamespace().get("passA5TF");
			passA6TF = (TextField) loader.getNamespace().get("passA6TF");
			
			//New
			NpassTF1 = (TextField) loader.getNamespace().get("NpassTF1");
			NpassTF2 = (TextField) loader.getNamespace().get("NpassTF2");
			NpassTF3 = (TextField) loader.getNamespace().get("NpassTF3");
			NpassTF4 = (TextField) loader.getNamespace().get("NpassTF4");
			NpassTF5 = (TextField) loader.getNamespace().get("NpassTF5");
			NpassTF6 = (TextField) loader.getNamespace().get("NpassTF6");
			
			//Buttons
			
			chPassBTN = (Button) loader.getNamespace().get("chPassBTN");
			closeCBTN = (Button) loader.getNamespace().get("closeCBTN");
			
		}catch(Exception ex){
			ex.printStackTrace();
			
		}
	}
	

}
