
package control;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MainWindow extends Stage implements Initializable {
	
	//Components
	
	private TextField pass1TF;
	private TextField pass2TF;
	private TextField pass3TF;
	private TextField pass4TF;
	private TextField pass5TF;
	private TextField pass6TF;
	private Button openBTN;
	
	
	
	//////////
	private String pass;
	
	public MainWindow() {
		
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("MainWindow.fxml"));
			Parent root = loader.load();
			
			Scene scene = new Scene(root,600,400);
			setScene(scene);
			
			pass1TF = (TextField) loader.getNamespace().get("pass1TF");
			pass2TF = (TextField) loader.getNamespace().get("pass2TF");
			pass3TF = (TextField) loader.getNamespace().get("pass3TF");
			pass4TF = (TextField) loader.getNamespace().get("pass4TF");
			pass5TF = (TextField) loader.getNamespace().get("pass5TF");
			pass6TF = (TextField) loader.getNamespace().get("pass6TF");
			openBTN = (Button) loader.getNamespace().get("openBTN");
			
			
		}catch(Exception ex){
			ex.printStackTrace();
			
		}
		
		
	}
	
	public void nextWindow() {
		pass=pass1TF.getText();
		if(pass.equals()) {
			
		}
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		pass = "";
	}
	
	
	

}
