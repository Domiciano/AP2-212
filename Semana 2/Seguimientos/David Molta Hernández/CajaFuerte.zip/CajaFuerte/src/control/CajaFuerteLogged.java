package control;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;

import javafx.stage.Stage;

public class CajaFuerteLogged {


	
	
	public Stage build() {
		
		
		try {
			Parent root = FXMLLoader.load(getClass().getResource("CajaFuerteLogged.fxml"));
			Scene scene = new Scene(root, 600, 400);
			Stage stage = new Stage();
			stage.setScene(scene);
			return stage;
		} catch (IOException e) {

			e.printStackTrace();
			return null;
		}
		
		
		
	}
	
	
	public void changePass() {
		
		ChangePass cp = new ChangePass();
		cp.build().show();
		
		
		
		
	}
	
	
	public void closeCF(ActionEvent event) {
		
		Node source = (Node) event.getSource();		
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
		
		
	}
	
	
	
}
