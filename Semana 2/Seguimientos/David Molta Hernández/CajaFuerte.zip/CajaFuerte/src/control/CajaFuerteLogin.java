package control;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

public class CajaFuerteLogin {

	public static String pass = "000000";

	@FXML
	PasswordField pass1;
	@FXML
	PasswordField pass2;
	@FXML
	PasswordField pass3;
	@FXML
	PasswordField pass4;
	@FXML
	PasswordField pass5;
	@FXML
	PasswordField pass6;
	@FXML
	Label result;

	public Stage build() {

		try {
			Parent root = FXMLLoader.load(getClass().getResource("CajaFuerteLogin.fxml"));
			Scene scene = new Scene(root, 600, 400);
			Stage stage = new Stage();
			stage.setScene(scene);
			return stage;
		} catch (IOException e) {

			e.printStackTrace();
			return null;
		}
	}


	@FXML
	public void nextCF() {
		
		String password = pass1.getText() + pass2.getText() +pass3.getText() +pass4.getText() +pass5.getText() +pass6.getText();
		if (password.equals(pass)) {
			CajaFuerteLogged cjf2 = new CajaFuerteLogged();
			cjf2.build().show();
		} else {
			result.setText("WRONG PASSWORD");
			pass1.setText("");
			pass2.setText("");
			pass3.setText("");
			pass4.setText("");
			pass5.setText("");
			pass6.setText("");
		}
	}



}
