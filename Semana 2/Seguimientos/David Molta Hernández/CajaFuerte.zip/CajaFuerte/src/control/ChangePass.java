package control;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ChangePass {
	
	
	@FXML
	 TextField c1,c2,c3,c4,c5,c6,pas1,pas2,pas3,pas4,pas5,pas6;
	@FXML
	 Label message;
	
	
	
	public Stage build() {

		
		
		try {
			Parent root = FXMLLoader.load(getClass().getResource("ChangePass.fxml"));
			Scene scene = new Scene(root, 600, 400);
			Stage stage = new Stage();
			stage.setScene(scene);
			return stage;
		} catch (IOException e) {

			e.printStackTrace();
			return null;
		}
		
		
		
	}
	
	
	
	public void cambiarPass() {
		
		String pass1= c1.getText() + c2.getText() + c3.getText() + c4.getText() +c5.getText() +c6.getText();
		String pass2= pas1.getText() + pas2.getText() + pas3.getText() + pas4.getText() + pas5.getText() + pas6.getText();
		if(pass1.equals(pass2)) {
			CajaFuerteLogin.pass = pass1;
			message.setText("Contrase�a cambiada");
			
		}else {
			message.setText("Las contrase�as no coinciden");
		}
		
		
		
		
		
	}

	
	public void closeCF2(ActionEvent event) {
		Node source = (Node) event.getSource();		
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
		
		
	}
	
	
}

