package model;

public class Password
{
	public static String I1 = "0000";
}
