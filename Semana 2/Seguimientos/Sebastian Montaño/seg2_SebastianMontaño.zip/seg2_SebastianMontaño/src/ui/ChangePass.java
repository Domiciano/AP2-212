package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Password;

public class ChangePass extends Stage
{
	// UI Components
	private Button confirmBtn, closeBoxBtn;
	private TextField passwInput1, passwInput2;
	private Label info;
	
	public ChangePass()
	{
		
		try
		{
			FXMLLoader loader = new FXMLLoader(getClass().getResource("ChangePass.FXML"));
			Parent root = loader.load();
			
			confirmBtn = (Button) loader.getNamespace().get("confirmBtn");
			closeBoxBtn = (Button) loader.getNamespace().get("closeBoxBtn");
			passwInput1 = (TextField) loader.getNamespace().get("passwInput1");
			passwInput2 = (TextField) loader.getNamespace().get("passwInput2");
			info = (Label) loader.getNamespace().get("info");
			
			Scene scene = new Scene(root, 600, 400);
			setScene(scene);
			
			init();
		}catch(Exception ex)
		{
			System.out.println(ex.getStackTrace());
		}
		
	}
	
	public void init()
	{
		confirmBtn.setOnAction(event->
		{
			String input1 = passwInput1.getText();
			String input2 = passwInput2.getText();
			if(input1.equals(input2))
			{
				Password.I1 = input1;
				info.setText("Contrase�a cambiada satisfactoriamente!");
			}else
				info.setText("Ambas contrase�as no coinciden, intentelo de nuevo");
		});
		
		closeBoxBtn.setOnAction(event->
		{	
			Stage stage = (Stage) closeBoxBtn.getScene().getWindow();
			MainWindow window = new MainWindow();
			window.show();
			stage.close();
		});
	}
}
