package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Password;

public class MainWindow extends Stage
{
	
	// UI Components
	
	private Button openBtn;
	private TextField passwInput;
	private Label info;
	
	
	public MainWindow()
	{
		try
		{
			FXMLLoader loader = new FXMLLoader(getClass().getResource("MainWindow.FXML"));
			Parent root = loader.load();
			
			openBtn = (Button) loader.getNamespace().get("openBtn");
			passwInput = (TextField) loader.getNamespace().get("passwInput");
			info = (Label) loader.getNamespace().get("info");
			
			Scene scene = new Scene(root, 600, 400);
			setScene(scene);
			
			init();
		}catch(Exception ex)
		{
			
		}
	}
	
	public void init()
	{
		openBtn.setOnAction(event->
		{	
			String input = passwInput.getText();
			if(input.contentEquals(Password.I1))
			{
				SecondWindow openBox = new SecondWindow();
				Stage stage = (Stage) openBtn.getScene().getWindow();
				openBox.show();
				stage.hide();
			}
			else
				info.setText("Contrase�a Incorrecta!");
		});
	}
}
