package ui;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class SecondWindow extends Stage
{
	// UI Components
	
	private Button changePassBtn;
	private Button closeBoxBtn;
	
	public SecondWindow()
	{
		
		try
		{
			FXMLLoader loader = new FXMLLoader(getClass().getResource("OpenBox.FXML"));
			Parent root = loader.load();
			
			changePassBtn = (Button) loader.getNamespace().get("changePassBtn");
			closeBoxBtn = (Button) loader.getNamespace().get("closeBoxBtn");
			
			Scene scene = new Scene(root, 600, 400);
			setScene(scene);
			
			init();
		}catch(Exception ex)
		{
			ex.setStackTrace(null);
		}
		
	}
	
	public void init()
	{
		changePassBtn.setOnAction(event->
		{	
			Stage stage = (Stage) changePassBtn.getScene().getWindow();
			ChangePass thirdWindow = new ChangePass();
			thirdWindow.show();
			stage.close();
		});
		closeBoxBtn.setOnAction(event->
		{	
			Stage stage = (Stage) closeBoxBtn.getScene().getWindow();
			MainWindow window = new MainWindow();
			window.show();
			stage.close();
		});
	}
}
