package main;

public class Ventana1 {
	
	
	public Ventana1() {
		
		System.out.println("Contraseña inicial");
		System.out.println(Password.C1+Password.C2+Password.C3);
		
		Password.C1 = "A";
		Password.C2 = "B";
		Password.C3 = "C";
		
		
	}
	

}
