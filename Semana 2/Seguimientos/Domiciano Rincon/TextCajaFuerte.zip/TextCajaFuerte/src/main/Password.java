package main;

public class Password {

	
	public static String C1 = "1";
	public static String C2 = "2";
	public static String C3 = "3";
	
	
}
