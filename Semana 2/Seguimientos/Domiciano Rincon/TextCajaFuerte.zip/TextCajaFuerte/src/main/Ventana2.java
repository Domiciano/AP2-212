package main;

public class Ventana2 {
	
	
	public Ventana2() {
		
		System.out.println("Desde ventana 2");
		System.out.println(Password.C1+Password.C2+Password.C3);
		
	}
	

}
