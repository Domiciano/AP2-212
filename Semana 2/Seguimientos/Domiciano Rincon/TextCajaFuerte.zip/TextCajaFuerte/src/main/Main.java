package main;

public class Main {

	public static void main(String[] args) {
		
		Ventana1 v1 = new Ventana1();
		
		Ventana2 v2 = new Ventana2();

	}

}
