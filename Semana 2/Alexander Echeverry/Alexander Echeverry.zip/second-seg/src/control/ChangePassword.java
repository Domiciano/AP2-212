package control;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ChangePassword {

    public Stage build(){
        try {
            Parent root = FXMLLoader.load(getClass().getResource("ChangePassword.fxml"));
            Scene scene = new Scene(root, 600, 400);
            Stage stage = new Stage();
            stage.setScene(scene);

            return stage;
        } catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    @FXML
    TextField ta1,ta2,ta3,ta4,ta5,ta6,ta11,ta21,ta31,ta41,ta51,ta61;

    @FXML
    private void changePassword(){

        String inputOldPassword = ta11.getText() + ta21.getText() + ta31.getText() + ta41.getText() + ta51.getText() + ta61.getText();

        String inputNewPassword = ta1.getText() + ta2.getText() + ta3.getText() + ta4.getText() + ta5.getText() + ta6.getText();

        if(inputOldPassword.equals(MainWindow.password)){

            MainWindow.password = inputNewPassword;

        } else {
            System.out.println("entro");
        }
    }

    @FXML
    private void openWindow(ActionEvent event){
        MainWindow mainWindow = new MainWindow();

        mainWindow.build().show();
        closeWindow(event);
    }

    @FXML
    private void closeWindow(ActionEvent event){
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }

    private void warningAlert(){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setContentText("Contraseña incorrecta");
    }
}
