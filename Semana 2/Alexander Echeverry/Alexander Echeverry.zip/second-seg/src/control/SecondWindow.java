package control;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class SecondWindow implements Initializable {

    //changePassword is the button for executing the change of password
    @FXML Button changePassword, closeBox;

    @FXML TextArea textArea;

    public static String text = "";

    public Stage build(){
        try {
            Parent root = FXMLLoader.load(getClass().getResource("SecondWindow.fxml"));
            Scene scene = new Scene(root, 600, 400);
            Stage stage = new Stage();
            stage.setScene(scene);

            return stage;
        } catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    @FXML
    private void openWindow(ActionEvent event){
        text = textArea.getText();

        Button button = (Button)event.getSource();

        if(button == changePassword){
            ChangePassword changePassword = new ChangePassword();
            changePassword.build().show();
        } else {
            MainWindow mainWindow = new MainWindow();
            mainWindow.build().show();
        }

        closeWindow(event);
    }

    @FXML
    private void closeWindow(ActionEvent event){
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        textArea.setText(text);
    }
}
