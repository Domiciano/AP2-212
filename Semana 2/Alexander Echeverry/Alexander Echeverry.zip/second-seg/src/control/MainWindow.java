package control;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



public class MainWindow implements EventHandler<ActionEvent> {

    //This variable contains the password global
    public static String password = "000000";

    @FXML
    TextField ta1,ta2,ta3,ta4,ta5,ta6;

    @FXML
    Label labelError;

    public Stage build(){
        try {
            Parent root = FXMLLoader.load(getClass().getResource("MainWindow.fxml"));
            Scene scene = new Scene(root, 600, 400);
            Stage stage = new Stage();
            stage.setScene(scene);

            return stage;
        } catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    @FXML
    private void check(ActionEvent event) {
        String passwordInput = ta1.getText() + ta2.getText() + ta3.getText() + ta4.getText() + ta5.getText()
                + ta6.getText();

        //if the conditional is true, the user can enter into box and it close the window,
        //if the conditional is false, the user can't enter into box and it show a message
        if(passwordInput.equals(password)){
            openWindow();
            closeWindow(event);
        } else {
            AlertBox.display("Alert", "la contraseña es incorrecta");
        }
    }

    private void openWindow() {
        SecondWindow secondWindow = new SecondWindow();
        secondWindow.build().show();
    }

    //it close the window
    @FXML
    private void closeWindow(ActionEvent event){
        Node source = (Node) event.getSource();
        Stage stage = (Stage) source.getScene().getWindow();
        stage.close();
    }

    private void warningAlert(){
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setContentText("Contraseña incorrecta");
    }

    @Override
    public void handle(ActionEvent event) {
        Button btn = (Button) event.getSource();
    }
}
