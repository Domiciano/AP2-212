package ui;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import model.InfrastructureDepartement;

public class Main {

	public static Scanner sn = new Scanner(System.in);
	public static InfrastructureDepartement departament = new InfrastructureDepartement();

	public static void main(String[] args) {
		
		departament.loadBillboard();

		//Main menu
		int i=0;
		while (i==0){

			int opcion=menu();

			switch(opcion){

			case 1:
				System.out.println("Enter the width of the billboard");
				double w=sn.nextDouble();
				sn.nextLine();
				
				System.out.println("Enter the heigth of the billboard");
				double h=sn.nextDouble();
				sn.nextLine();
				
				boolean iu=true;
				
				System.out.println("Enter the brand of the billboard");
				String b=sn.nextLine();
				
				departament.addBillboard(w,h,iu,b);
				break;

			case 2: 
				String mensaje=departament.loadBillboard();
				
				System.out.println(mensaje);
				break;

			case 3:
				departament.exportReport();
				break;

			case 4: i=1;
			System.out.println("He has exited the program.");
				break;

			}
		}

	}

	public static int menu() {
		int choose=0;
		int b=0;

		System.out.println("      \n                MAIN MENU                             ");
		System.out.println("\n please choose an option: \n");
		System.out.println("--------------------------------------------------------------");
		System.out.println("1: add a billboard ");
		System.out.println("2: show a list of billboard");
		System.out.println("3: export report of dangerous ");
		System.out.println("4: out of the program ");
		System.out.println("--------------------------------------------------------------");

		while (b==0){

			choose=sn.nextInt();
			sn.nextLine();

			if (choose>10){
				System.out.println("The option entered is not valid, try again ");
			}
			else  
				b=1;
		}

		return choose;
	}

}
