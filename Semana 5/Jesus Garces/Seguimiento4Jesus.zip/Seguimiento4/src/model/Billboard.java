package model;

import java.io.Serializable;

public class Billboard implements Serializable {
	
	private double windt;
	private double heigth;
	private boolean inUse;
	private String brand;
	
	public Billboard(double w,double h, boolean iu,String b) {
		windt=w;
		heigth=h;
		inUse=iu;
		brand=b;
		
	}

	public double getWindt() {
		return windt;
	}

	public void setWindt(double windt) {
		this.windt = windt;
	}

	public double getHeigth() {
		return heigth;
	}

	public void setHeigth(double heigth) {
		this.heigth = heigth;
	}

	public boolean isInUse() {
		return inUse;
	}

	public void setInUse(boolean inUse) {
		this.inUse = inUse;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public double calculateArea() {
		double area=0;
		
		area=windt*heigth;
		
		return area;
	}
	
	public String toString() {
		String mensaje="";
		
		mensaje=windt+" "+heigth+" "+inUse+ " "+brand;
		
		return mensaje;
		
	}

}
