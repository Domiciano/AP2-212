package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class InfrastructureDepartement {

	//constante
	public static final double dangerous=265;
	ArrayList<Billboard> billboard;

	public InfrastructureDepartement() {
		billboard = new ArrayList<Billboard>();
	}

	public void addBillboard(double w,double h, boolean iu,String b) {
		billboard.add(new Billboard(w,h,iu,b));
	}

	public String loadBillboard() {
		String mensaje="";

		try {
			File file = new File("data/data.csv");
			FileInputStream fis = new FileInputStream(file);
			ByteArrayOutputStream baos = new ByteArrayOutputStream(); 

			int leidos = 0;
			byte[] buffer = new byte[1024];

			while(  (leidos = fis.read(buffer)) != -1  ) {
				baos.write(buffer, 0, leidos);
			}
			fis.close();
			baos.close();

			String csv = baos.toString();

			int contador=0;
			double windt=0;
			double heigth=0;
			boolean use=false;
			
			String[] lines = csv.split("\\|");
			for(int i=4 ; i<lines.length ; i++) {
				
				if(lines[i].substring(0,1).equals(null)) {
					
					if(contador==0) {
						windt=Double.parseDouble(lines[i]);
					}
					else if(contador==1) {
						heigth=Double.parseDouble(lines[i]);
					}

					else if(contador==2) {

						if(lines[i].equalsIgnoreCase("true")) {
							use=true;
						}

					}
					else if(contador==3) {
						String brand=lines[i];

						billboard.add(new Billboard(windt,heigth,use,brand));
						contador=0;
					}

					if(contador!=0) {
						contador++;
					}
					else if(i==4) {
						contador++;
					}
				}

			}
			String m2="La cantidad de anuncios es "+billboard.size();
			mensaje=billboard.toString()+"\n"+m2;

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return mensaje;
	}

	public String exportReport() {
		String report="";

		try {
			String ruta = "/ruta/filename.txt";
			String contenido = billboard.toString();
			File file = new File("D:\\Jesus\\Seguimiento4/report.txt");
			// Si el archivo no existe es creado
			if (!file.exists()) {
				file.createNewFile();
			}
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(contenido);
			bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return report;
	}


}
