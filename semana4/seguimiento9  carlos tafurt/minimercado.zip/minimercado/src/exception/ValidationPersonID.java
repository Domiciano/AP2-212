package exception;

public class ValidationPersonID extends Exception {

	public ValidationPersonID(String tipDoc) {
		super("la persona su con id tipo:"+tipDoc+" no puede ingresar por se menor de edad");
		
	}
	

}
