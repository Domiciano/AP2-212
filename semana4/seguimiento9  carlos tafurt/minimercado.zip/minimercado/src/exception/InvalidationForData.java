package exception;

public class InvalidationForData  extends Exception{

	public InvalidationForData(String idPerson,int dato2) {
		super("la persona su con id :"+idPerson+" no puede ingresar porq su num de documento no correponde a el dia asignado");
		
	}
}
