package model;

import javax.xml.bind.ValidationException;

public class person {
	private String tipDocument;
	private String idPerson;
	private int EnterMINImarker;
	
	
	
	
	/**
	 * @param tipDocument
	 * @param idPerson
	 */
	public person(String tipDocument, String idPerson){
		super();
		this.tipDocument = tipDocument;
		this.idPerson = idPerson;
		EnterMINImarker=0;
		
	}
	
	
	


	public String getTipDocument() {
		return tipDocument;
	}
	public void setTipDocument(String tipDocument) {
		this.tipDocument = tipDocument;
	}
	public String getIdPerson() {
		return idPerson;
	}
	public void setIdPerson(String idPerson) {
		this.idPerson = idPerson;
	}


	public int getEnterMINImarker() {
		return EnterMINImarker;
	}

	public void setEnterMINImarker(int enterMINImarker) {
		EnterMINImarker = enterMINImarker;
	}
	
	
	

}
