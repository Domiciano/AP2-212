package model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.xml.bind.ValidationException;

import exception.InvalidationForData;
import exception.ValidationPersonID;

public class control {

	private String fecha;
	private String name;
	private ArrayList<person> persons;
	private int notEntertheMIni;
	
	
	public control(String name) {
		this.name=name;
		notEntertheMIni=0;
		
	}
	
	public void DataAtual() {
		
		Calendar date= Calendar.getInstance();
		Date dt= date.getTime();
		SimpleDateFormat format=new SimpleDateFormat("dd");
		fecha = format.format(dt);
	 
	}
	
	public person validationForData(String tipDocument,String  idPerson)throws  InvalidationForData{
		int cant=idPerson. length()-1;
		int id=idPerson.charAt(cant);
		int dia= Integer.parseInt(fecha);
		if((id % 2==0&&dia%2!=0)) {
			person P=new person( tipDocument,  idPerson);
			return P;
		}else {
			throw new InvalidationForData(idPerson,id);
		}
		
	}
	
	public void ValidationForTipDoc(String tipDocument,String  idPerson) throws  ValidationPersonID, InvalidationForData{
		
		person p=validationForData(tipDocument, idPerson);
		if(tipDocument.equalsIgnoreCase("Id")) {
			throw new ValidationPersonID(idPerson);
		}else {
			p.setEnterMINImarker(1);
		}
		addArraylistPerson(p);
		
	}
	
	public void addArraylistPerson(person p) {
		if(p.getEnterMINImarker()==1&&p!=null) {
			persons.add(p);
		}else {
			notEntertheMIni++;
		}
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<person> getPersons() {
		return persons;
	}

	public void setPersons(ArrayList<person> persons) {
		this.persons = persons;
	}

	public int getNotEntertheMIni() {
		return notEntertheMIni;
	}

	public void setNotEntertheMIni(int notEntertheMIni) {
		this.notEntertheMIni = notEntertheMIni;
	}
	
	
	
	
	
	
	
	
	
}
