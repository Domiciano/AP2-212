package UI;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

import exception.InvalidationForData;
import exception.ValidationPersonID;
import model.control;

public class Main {

	private Scanner sc=new Scanner(System.in);
	public static void main(String...args) {
		Main m=new Main();
		m.menu();
	}
	
	public void menu() {
		String exit="";
		control controll=new control("mi Tienda");
		controll.DataAtual();
		do {
			System.out.println("1. enter the person to miniMarker "
					+ "2. consultation of people who could not enter "
					+ "3. exit the program");
			int option=sc.nextInt();
			sc.nextLine();
			String tipo="";
			switch (option) {
			case 1:
				System.out.println("what is the type of documen  "
						+ "\n 1. T.i"
						+ "\n 2. C.C"
						+ "\n 3. P.P"
						+ "\n 4. C.E");
				int type=sc.nextInt();
				sc.nextLine();
				switch (type) {
				case 1:
					tipo="ti";
					break;
				case 2:
					tipo="cc";
					break;
				case 3:
					tipo="pp";
					break;
				case 4:
					tipo="ce";
					break;

				}
				
				System.out.println("what is the numer of id");
				String id=sc.nextLine();
				
				try {
					controll.ValidationForTipDoc( tipo,  id);
				} catch (ValidationPersonID | InvalidationForData e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;

			case 2:
				System.out.println("el numero de personas que no puede entrar es: "+controll.getNotEntertheMIni()); 
				break;
			case 3:
				exit="salir";
				break;
			}
		} while (exit.equals("salir"));
	}
	
	
}
