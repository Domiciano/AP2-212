package control;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class SecondWindow {
	
	@FXML TextArea output1;
	public Stage build() {
		// TODO Auto-generated method stub
		try {
			Parent root = FXMLLoader.load(getClass().getResource("SecondWindow.fxml"));
			Scene scene = new Scene(root, 800, 600 );
			Stage stage= new Stage();
			stage.setScene(scene);
			return stage;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public void backWindow() {
		MainWindow main1 = new MainWindow();
		main1.build().show();
	}
	
	public void erase() {
		output1.setText(null);
	}
	
	public void nextWindow() {
		ThirdWindow main2 = new ThirdWindow();
		main2.build().show();
	}
	

}